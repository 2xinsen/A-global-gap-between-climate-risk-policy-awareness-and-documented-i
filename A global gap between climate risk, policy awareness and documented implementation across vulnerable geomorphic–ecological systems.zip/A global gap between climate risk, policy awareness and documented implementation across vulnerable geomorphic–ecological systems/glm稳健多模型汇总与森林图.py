# -*- coding: utf-8 -*-
from __future__ import annotations

import argparse
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import numpy as np
import pandas as pd
import statsmodels.api as sm
from pandas.api.types import CategoricalDtype

SCRIPT_PATH = Path(__file__).resolve()
TEMPLATE_DIR = SCRIPT_PATH.parent / "模板"
if str(TEMPLATE_DIR) not in sys.path:
    sys.path.insert(0, str(TEMPLATE_DIR))

from forest_regression import multi_model_forest  # type: ignore


TARGETS: Sequence[Tuple[str, str]] = [
    ("Scores_R1_Hazard", "R1 Hazard"),
    ("Scores_R2_Exposure", "R2 Exposure"),
    ("Scores_R3_Vulnerability", "R3 Vulnerability"),
    ("Scores_R4_Data_Gap", "R4 Data gap"),
    ("Scores_R5_Eco_Impact", "R5 Eco impact"),
    ("Scores_action_minus_risk_score", "Action–Risk gap"),
]


NUMERIC_FEATURES: Sequence[str] = [
    "Metadata_GDP_pc",
    "Metadata_Agri_Pct",
    "Metadata_Industrial_Pct",
    "Metadata_ND_Vul_Index",
    "Metadata_Pct_FullText_Description",
    "Metadata_A_Doc_Year",
    "Metadata_Act_Doc_Year",
    "Scores_A1_Diagnostic",
    "Scores_A2_Integration",
    "Scores_A3_Stakeholder",
    "Scores_A4_Planning",
    "Scores_A5_Finance",
    "Scores_Ac1_Implementation",
    "Scores_Ac2_Governance",
    "Scores_Ac3_Finance",
    "Scores_Ac4_Monitoring",
    "Scores_Ac5_Capacity",
    "Deep_Metrics_TSI_Score",
    "Deep_Metrics_PCS_Score",
    "Deep_Metrics_FGI_Pct",
    "Deep_Metrics_Time_Horizon_Yrs",
    "Deep_Metrics_Budget_Commit_USD",
    "Deep_Metrics_Inv_Gap_USD",
    "Deep_Metrics_Risk_GDP_Loss_Pct",
    "Barrier_Weights_Financial",
    "Barrier_Weights_Institutional",
    "Barrier_Weights_Technical",
    "Barrier_Weights_Political",
    "Barrier_Weights_Regulatory",
]


LOG1P_FEATURES: Sequence[str] = [
    "Metadata_GDP_pc",
    "Deep_Metrics_Budget_Commit_USD",
    "Deep_Metrics_Inv_Gap_USD",
]


CATEGORICAL_COLS: Sequence[str] = [
    "Metadata_Region",
    "Metadata_Climate_Zone",
    "Metadata_Doc_Language",
]


def _clean_text(series: pd.Series) -> pd.Series:
    s = series.astype("string").str.strip()
    s = s.replace(r"\s+", " ", regex=True)
    s = s.mask(s.str.lower() == "nan")
    return s


def _collapse_rare(series: pd.Series, *, min_count: int, other_label: str = "Other") -> pd.Series:
    s = _clean_text(series)
    s = s.fillna("Unknown")
    counts = s.value_counts(dropna=False)
    rare = counts[counts < min_count].index
    return s.where(~s.isin(rare), other_label)


def _encode_income_group(raw: pd.Series) -> pd.Series:
    s = _clean_text(raw).str.lower()

    def encode_one(val: str | None) -> float:
        if val is pd.NA:
            return np.nan
        text = str(val)
        if "least developed" in text:
            return 1.0
        if "high" in text and "middle" not in text:
            return 4.0
        if "upper" in text and "middle" in text:
            return 3.0
        if "lower" in text and "middle" in text:
            return 2.0
        if text.startswith("low") or "low income" in text:
            return 1.0
        return np.nan

    return s.map(encode_one)


_NUM_RE = re.compile(r"(-?\d+(?:\.\d+)?)")


def _encode_wgi_gov(raw: pd.Series) -> pd.Series:
    s = _clean_text(raw).str.lower()

    def encode_one(val: str | None) -> float:
        if val is pd.NA:
            return np.nan
        text = str(val)
        m = _NUM_RE.search(text)
        if m:
            num = float(m.group(1))
            if num <= -0.5:
                return 1.0
            if num <= 0.5:
                return 2.0
            if num <= 1.5:
                return 3.0
            return 4.0
        if "very high" in text:
            return 4.0
        if "medium-high" in text or "medium high" in text:
            return 3.0
        if "high" in text and "very high" not in text:
            return 3.0
        if text in {"med", "moderate"} or "medium" in text:
            return 2.0
        if "weak" in text:
            return 1.0
        if "strong" in text:
            return 3.0
        if "low" in text:
            return 1.0
        return np.nan

    return s.map(encode_one)


def _to_numeric(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series, errors="coerce")


def _zscore(series: pd.Series) -> pd.Series:
    values = series.astype(float)
    sd = values.std()
    if not np.isfinite(sd) or sd == 0:
        return pd.Series(np.zeros(len(values), dtype=float), index=series.index)
    return (values - values.mean()) / sd


def _maybe_set_paper_category_order(col_name: str, series: pd.Series) -> pd.Series:
    values = series.astype("string").fillna("Unknown")

    if col_name == "Metadata_Region":
        allowed = {"R1", "R2", "R3", "R4", "R5", "Other", "Unknown"}
        observed = set(values.dropna().unique().tolist())
        if observed.issubset(allowed):
            cat = CategoricalDtype(
                categories=["R5", "R1", "R2", "R3", "R4", "Other", "Unknown"],
                ordered=True,
            )
            return values.astype(cat)

    if col_name == "Metadata_Climate_Zone":
        allowed = {"Z1", "Z2", "Z3", "Z4", "Z5", "Other", "Unknown"}
        observed = set(values.dropna().unique().tolist())
        if observed.issubset(allowed):
            cat = CategoricalDtype(
                categories=["Z5", "Z1", "Z2", "Z3", "Z4", "Other", "Unknown"],
                ordered=True,
            )
            return values.astype(cat)

    return series


@dataclass(frozen=True)
class PreparedData:
    df: pd.DataFrame
    x_cols: List[str]


def _read_category_map(path: str | Path) -> Dict[str, str]:
    p = Path(path)
    frame = pd.read_csv(p)
    cols = {c.strip().lower(): c for c in frame.columns}
    raw_col = cols.get("raw_value") or cols.get("raw") or cols.get("value") or cols.get("rawvalue")
    mapped_col = cols.get("mapped_value") or cols.get("mapped") or cols.get("group") or cols.get("mappedvalue")
    if not raw_col or not mapped_col:
        raise ValueError(f"Mapping file must have columns raw_value,mapped_value: {p}")

    raw = _clean_text(frame[raw_col]).fillna("Unknown")
    mapped = _clean_text(frame[mapped_col])
    mapping: Dict[str, str] = {}
    for r, m in zip(raw.tolist(), mapped.tolist()):
        if r in mapping:
            continue
        if m is pd.NA or m is None or (isinstance(m, str) and not m.strip()):
            continue
        mapping[str(r)] = str(m)
    return mapping


def _apply_category_map(series: pd.Series, mapping: Dict[str, str] | None) -> pd.Series:
    s = _clean_text(series).fillna("Unknown")
    if not mapping:
        return s
    return s.map(lambda v: mapping.get(str(v), "Other"))


def _suggest_climate_koppen5_paper(value: str) -> str | None:
    v = str(value).strip()
    if not v:
        return None
    lower = v.lower()
    # Some sources include a non-standard "H" (highland) zone; map it to continental.
    if lower in {"h", "highland"} or "mountain" in lower or "alpine" in lower or "montane" in lower or "highland" in lower or "sub-alpine" in lower:
        return "Z3"
    if "variable" in lower or "varies" in lower or "varied" in lower:
        return None
    # Paper mapping: Z1=arid, Z2=temperate, Z3=continental, Z4=tropical, Z5=polar
    if "polar" in lower or "arctic" in lower or "tundra" in lower or re.search(r"\bet\b|\bef\b", lower):
        return "Z5"
    if "tropical" in lower or re.search(r"\baf\b|\bam\b|\baw\b", lower):
        return "Z4"
    if "arid" in lower or "semi-arid" in lower or "desert" in lower or re.search(r"\bbw|\bbs", lower):
        return "Z1"
    if "continental" in lower or re.search(r"\bdf\b|\bdw\b", lower):
        return "Z3"
    if "mediterranean" in lower or "temperate" in lower or "oceanic" in lower or "subtropical" in lower or re.search(r"\bcf\b|\bcs\b|\bcw\b", lower):
        return "Z2"
    # Köppen first-letter heuristic if present
    m = re.search(r"\b([ABCDE])", v)
    if not m:
        return None
    letter = m.group(1)
    if letter == "A":
        return "Z4"
    if letter == "B":
        return "Z1"
    if letter == "C":
        return "Z2"
    if letter == "D":
        return "Z3"
    if letter == "E":
        return "Z5"
    return None


def _suggest_region_unesco5_paper(value: str) -> str | None:
    v = str(value).strip()
    if not v:
        return None
    lower = v.lower()

    # Paper mapping: R1 Arab States; R2 Asia & Pacific; R3 Europe & North America; R4 Africa; R5 Latin America & Caribbean.
    if "latin america" in lower or "caribbean" in lower:
        return "R5"
    if "north america" in lower:
        return "R3"
    if "europe" in lower or "balkans" in lower:
        return "R3"
    # Treat North Africa + Western Asia as Arab States proxy
    if "arab" in lower or "western asia" in lower or "middle east" in lower or "northern africa" in lower:
        return "R1"
    if "oceania" in lower or "pacific" in lower or "east asia" in lower or "south-east asia" in lower or "southeast asia" in lower or "south asia" in lower or "asia" in lower:
        return "R2"
    if "africa" in lower:
        return "R4"
    return None


def export_mapping_templates(
    raw: pd.DataFrame,
    output_dir: Path,
    *,
    region_col: str = "Metadata_Region",
    climate_col: str = "Metadata_Climate_Zone",
    language_col: str = "Metadata_Doc_Language",
    suggest_climate: str = "none",
    suggest_region: str = "none",
) -> List[Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    written: List[Path] = []

    def write_template(col: str, *, suggester=None) -> None:
        if col not in raw.columns:
            return
        values = _clean_text(raw[col]).fillna("Unknown").value_counts(dropna=False)
        frame = pd.DataFrame({"raw_value": values.index.astype(str), "count": values.values})
        if suggester is None:
            frame["mapped_value"] = ""
        else:
            frame["mapped_value"] = [suggester(v) or "" for v in frame["raw_value"].tolist()]
        out_path = output_dir / f"mapping_template_{col}.csv"
        frame.to_csv(out_path, index=False, encoding="utf-8-sig")
        written.append(out_path)

    if suggest_region == "unesco5":
        write_template(region_col, suggester=_suggest_region_unesco5_paper)
    else:
        write_template(region_col, suggester=None)
    write_template(language_col, suggester=None)
    if suggest_climate == "koppen5":
        write_template(climate_col, suggester=_suggest_climate_koppen5_paper)
    else:
        write_template(climate_col, suggester=None)

    return written


def prepare_data(
    raw: pd.DataFrame,
    *,
    min_category_count: int,
    category_maps: Dict[str, Dict[str, str]] | None = None,
) -> PreparedData:
    df = raw.copy()

    if "Metadata_Income_Group" in df.columns:
        df["Income_Level"] = _encode_income_group(df["Metadata_Income_Group"])
    else:
        df["Income_Level"] = np.nan

    if "Metadata_WGI_Gov" in df.columns:
        df["Gov_Level"] = _encode_wgi_gov(df["Metadata_WGI_Gov"])
    else:
        df["Gov_Level"] = np.nan

    numeric_cols = [c for c in NUMERIC_FEATURES if c in df.columns]
    target_cols = [c for c, _ in TARGETS if c in df.columns]
    for col in numeric_cols + target_cols + ["Income_Level", "Gov_Level"]:
        if col not in df.columns:
            continue
        df[col] = _to_numeric(df[col])

    for col in LOG1P_FEATURES:
        if col not in df.columns:
            continue
        values = df[col].copy()
        values = values.clip(lower=0)
        df[f"{col}_log1p"] = np.log1p(values)

    base_numeric = [c for c in numeric_cols if c not in LOG1P_FEATURES]
    transformed_numeric = [f"{c}_log1p" for c in LOG1P_FEATURES if f"{c}_log1p" in df.columns]
    all_numeric_for_model = base_numeric + transformed_numeric + ["Income_Level", "Gov_Level"]

    for col in all_numeric_for_model:
        if col not in df.columns:
            continue
        df[col] = df[col].fillna(df[col].median())
        df[col] = _zscore(df[col])

    for col in CATEGORICAL_COLS:
        if col not in df.columns:
            continue
        mapped = _apply_category_map(df[col], (category_maps or {}).get(col))
        df[col] = _collapse_rare(mapped, min_count=min_category_count, other_label="Other")
        df[col] = _maybe_set_paper_category_order(col, df[col])

    df_final = pd.get_dummies(df, columns=[c for c in CATEGORICAL_COLS if c in df.columns], drop_first=True)

    dummy_prefixes = tuple(f"{c}_" for c in CATEGORICAL_COLS)
    dummy_cols = [c for c in df_final.columns if c.startswith(dummy_prefixes)]
    x_cols = all_numeric_for_model + dummy_cols
    x_cols = [c for c in x_cols if c in df_final.columns]

    return PreparedData(df=df_final, x_cols=x_cols)


def _sigstars(p: float) -> str:
    """显著性标注，采用论文标准：P<0.10标*, P<0.05标**, P<0.01标***"""
    if not np.isfinite(p):
        return ""
    if p < 0.01:
        return "***"
    if p < 0.05:
        return "**"
    if p < 0.10:
        return "*"
    return ""


def _compute_bic(result) -> float:
    llf = float(getattr(result, "llf", np.nan))
    nobs = float(getattr(result, "nobs", np.nan))
    k = float(len(getattr(result, "params", [])))
    if not np.isfinite(llf) or not np.isfinite(nobs) or nobs <= 0 or not np.isfinite(k) or k <= 0:
        return float("nan")
    return float(-2.0 * llf + k * np.log(nobs))


def _paper_p_value_str(p: float) -> str:
    """格式化p值输出，采用论文标准"""
    if not np.isfinite(p):
        return ""
    if p < 0.001:
        return f"0{_sigstars(p)}"
    return f"{p:.3f}{_sigstars(p)}"


def _paper_estimate_str(value: float) -> str:
    if not np.isfinite(value):
        return ""
    return f"{value:.3f}"

def _fit_glm(
    y: pd.Series,
    X: pd.DataFrame,
    *,
    cov_type: str,
    groups: pd.Series | None,
) -> sm.GLM:
    X_mat = sm.add_constant(X.astype(float), has_constant="add")
    model = sm.GLM(y.astype(float), X_mat, family=sm.families.Gaussian())

    if cov_type == "cluster" and groups is not None:
        return model.fit(cov_type="cluster", cov_kwds={"groups": groups}, use_t=True)
    if cov_type.lower().startswith("hc"):
        return model.fit(cov_type=cov_type, use_t=True)
    return model.fit()


def bivariate_screen(
    X: pd.DataFrame,
    y: pd.Series,
    *,
    p_threshold: float = 0.20,
) -> Tuple[List[str], pd.DataFrame]:
    """
    双变量相关筛选，与论文方法一致。
    保留与因变量有显著双变量关联的变量（p < p_threshold）。
    
    返回：(保留的变量列表, 筛选统计表)
    """
    results: List[Dict[str, object]] = []
    keep: List[str] = []
    
    for col in X.columns:
        x1 = sm.add_constant(X[[col]].astype(float), has_constant="add")
        try:
            res = sm.OLS(y.astype(float), x1).fit()
            p = float(res.pvalues.get(col, np.nan))
            coef = float(res.params.get(col, np.nan))
        except Exception:
            p = np.nan
            coef = np.nan
        
        results.append({
            "term": col,
            "coef": coef,
            "p_value": p,
            "keep": p < p_threshold if np.isfinite(p) else False,
        })
        
        if np.isfinite(p) and p < p_threshold:
            keep.append(col)
    
    screen_df = pd.DataFrame(results)
    # 按p值排序
    screen_df = screen_df.sort_values("p_value", key=lambda s: s.fillna(1.0))
    return keep, screen_df


def _prefilter_candidates(X: pd.DataFrame, y: pd.Series, *, max_candidates: int) -> List[str]:
    if max_candidates <= 0 or X.shape[1] <= max_candidates:
        return list(X.columns)

    pvals = []
    for col in X.columns:
        x1 = sm.add_constant(X[[col]].astype(float), has_constant="add")
        res = sm.OLS(y.astype(float), x1).fit()
        p = float(res.pvalues.get(col, np.nan))
        pvals.append((p, col))
    pvals.sort(key=lambda t: (np.isnan(t[0]), t[0]))
    keep = [col for _, col in pvals[:max_candidates]]
    return keep


def stepwise_selection(
    X: pd.DataFrame,
    y: pd.Series,
    *,
    threshold_in: float = 0.05,
    threshold_out: float = 0.10,
    max_steps: int = 200,
    max_features: int = 35,
) -> List[str]:
    included: List[str] = []
    X = X.astype(float)
    y = y.astype(float)

    for _ in range(max_steps):
        changed = False

        excluded = [c for c in X.columns if c not in included]
        new_pval = pd.Series(index=excluded, dtype="float64")
        for new_col in excluded:
            res = sm.OLS(y, sm.add_constant(X[included + [new_col]], has_constant="add")).fit()
            new_pval[new_col] = res.pvalues.get(new_col, np.nan)
        best_pval = float(new_pval.min()) if len(new_pval) else np.nan

        if np.isfinite(best_pval) and best_pval < threshold_in and len(included) < max_features:
            included.append(str(new_pval.idxmin()))
            changed = True

        if included:
            res = sm.OLS(y, sm.add_constant(X[included], has_constant="add")).fit()
            pvalues = res.pvalues.drop(labels="const", errors="ignore")
            worst_pval = float(pvalues.max()) if len(pvalues) else np.nan
            if np.isfinite(worst_pval) and worst_pval > threshold_out:
                included.remove(str(pvalues.idxmax()))
                changed = True

        if not changed:
            break

    return included


def run_models(
    prepared: PreparedData,
    *,
    selection: str,
    cov_type: str,
    cluster_col: str | None,
    max_candidates: int,
    step_in: float,
    step_out: float,
    max_steps: int,
    max_features: int,
) -> Tuple[List[sm.GLM], pd.DataFrame, pd.DataFrame]:
    df = prepared.df
    models: List[sm.GLM] = []
    rows: List[Dict[str, object]] = []
    model_info: List[Dict[str, object]] = []

    for target_col, target_label in TARGETS:
        if target_col not in df.columns:
            continue

        y = _to_numeric(df[target_col])
        valid = y.notna()
        if valid.sum() < 30:
            continue

        X = df.loc[valid, prepared.x_cols]
        # Drop constant columns (e.g., dummies for unobserved categories)
        nunique = X.nunique(dropna=False)
        keep_cols = nunique[nunique > 1].index.tolist()
        X = X[keep_cols]
        y = y.loc[valid]

        groups = None
        if cov_type == "cluster" and cluster_col and cluster_col in df.columns:
            groups = df.loc[valid, cluster_col].astype("string").fillna("Unknown")

        selected_cols = list(X.columns)
        if selection == "stepwise":
            selected_cols = _prefilter_candidates(X, y, max_candidates=max_candidates)
            selected_cols = stepwise_selection(
                X[selected_cols],
                y,
                threshold_in=step_in,
                threshold_out=step_out,
                max_steps=max_steps,
                max_features=max_features,
            )
            if not selected_cols:
                selected_cols = _prefilter_candidates(X, y, max_candidates=min(max_candidates, 25))

        used_cov_type = cov_type
        try:
            res = _fit_glm(y, X[selected_cols], cov_type=used_cov_type, groups=groups)
        except np.linalg.LinAlgError:
            # Fallback when robust cluster covariance fails due to singular Hessian
            used_cov_type = "HC3"
            res = _fit_glm(y, X[selected_cols], cov_type=used_cov_type, groups=None)
        models.append(res)

        model_aic = float(getattr(res, "aic", np.nan))
        model_bic = _compute_bic(res)
        model_k = int(len(res.params))
        model_llf = float(getattr(res, "llf", np.nan))
        model_n = int(res.nobs)
        model_info.append(
            {
                "outcome": target_label,
                "outcome_col": target_col,
                "nobs": model_n,
                "n_params": model_k,
                "llf": model_llf,
                "aic": model_aic,
                "bic": model_bic,
                "cov_type": used_cov_type,
                "selection": selection,
                "selected_features": len(selected_cols),
            }
        )

        ci = res.conf_int()
        for term in res.params.index:
            if term == "const":
                continue
            p = float(res.pvalues.get(term, np.nan))
            rows.append(
                {
                    "outcome": target_label,
                    "outcome_col": target_col,
                    "term": term,
                    "estimate": float(res.params[term]),
                    "std_err": float(res.bse[term]),
                    "p_value": p,
                    "ci_low": float(ci.loc[term, 0]),
                    "ci_high": float(ci.loc[term, 1]),
                    "stars": _sigstars(p),
                    "nobs": int(res.nobs),
                    "aic": float(getattr(res, "aic", np.nan)),
                    "bic": model_bic,
                    "n_params": model_k,
                    "cov_type": used_cov_type,
                    "selection": selection,
                }
            )

    long_df = pd.DataFrame(rows)
    model_info_df = pd.DataFrame(model_info)
    return models, long_df, model_info_df


def _to_wide(long_df: pd.DataFrame) -> pd.DataFrame:
    if long_df.empty:
        return long_df

    fmt = long_df.copy()
    fmt["cell"] = fmt.apply(
        lambda r: f"{r['estimate']:.3f}{r['stars']} ({r['ci_low']:.3f}, {r['ci_high']:.3f})",
        axis=1,
    )
    wide = fmt.pivot_table(index="term", columns="outcome", values="cell", aggfunc="first")
    wide = wide.reset_index()
    return wide


def _format_p_value(value: float | None) -> str:
    if value is None or pd.isna(value):
        return ""
    if value < 0.001:
        return "<0.001"
    if value < 0.01:
        return f"{value:.3f}".rstrip("0").rstrip(".")
    return f"{value:.3f}"


def _to_wide_with_p(long_df: pd.DataFrame) -> pd.DataFrame:
    if long_df.empty:
        return long_df

    fmt = long_df.copy()
    fmt["Estimate"] = fmt.apply(lambda r: f"{r['estimate']:.3f}{r['stars']}", axis=1)
    fmt["P"] = fmt["p_value"].map(_format_p_value)
    wide_est = fmt.pivot_table(index="term", columns="outcome", values="Estimate", aggfunc="first")
    wide_p = fmt.pivot_table(index="term", columns="outcome", values="P", aggfunc="first")

    wide = pd.DataFrame(index=wide_est.index)
    for outcome in wide_est.columns:
        wide[f"{outcome} Estimate"] = wide_est[outcome]
        wide[f"{outcome} P"] = wide_p.get(outcome)

    wide = wide.reset_index()
    return wide


def _term_label(term: str) -> str:
    labels = {
        "Barrier_Weights_Institutional": "Institutional barrier",
        "Barrier_Weights_Technical": "Technical barrier",
        "Barrier_Weights_Political": "Political barrier",
        "Deep_Metrics_Risk_GDP_Loss_Pct": "Proj. GDP loss (%)",
        "Metadata_GDP_pc_log1p": "GDP per capita (log1p)",
        "Gov_Level": "Governance level",
    }
    if term in labels:
        return labels[term]

    if term.startswith("Metadata_Region_R"):
        return term.replace("Metadata_Region_", "")
    if term.startswith("Metadata_Climate_Zone_Z"):
        return term.replace("Metadata_Climate_Zone_", "")

    if term.startswith("Barrier_Weights_"):
        return term.replace("Barrier_Weights_", "Barrier: ").replace("_", " ")
    if term.startswith("Deep_Metrics_"):
        return term.replace("Deep_Metrics_", "").replace("_", " ")
    if term.startswith("Metadata_"):
        return term.replace("Metadata_", "").replace("_", " ")
    if term.startswith("Scores_"):
        return term.replace("Scores_", "").replace("_", " ")
    return term.replace("_", " ")


def _build_paper_table(
    *,
    outcomes: Sequence[str],
    models: List[sm.GLM],
    long_df: pd.DataFrame,
    model_info_df: pd.DataFrame,
    row_blocks: Sequence[tuple[str, Sequence[str]]],
    title: str,
) -> pd.DataFrame:
    """
    Return a 'paper-style' table with header rows and per-outcome Estimate/Pr(>|z|) columns.

    row_blocks: [(block_title, [term1, term2, ...])]
    """
    by_term_outcome: Dict[tuple[str, str], tuple[float, float]] = {}
    for _, r in long_df.iterrows():
        by_term_outcome[(str(r["term"]), str(r["outcome"]))] = (float(r["estimate"]), float(r["p_value"]))

    intercept_by_outcome: Dict[str, tuple[float, float]] = {}
    for model, outcome in zip(models, outcomes):
        params = getattr(model, "params", None)
        pvalues = getattr(model, "pvalues", None)
        if params is None or pvalues is None or "const" not in params.index:
            continue
        intercept_by_outcome[str(outcome)] = (float(params["const"]), float(pvalues["const"]))

    rows: List[Dict[str, object]] = []
    rows.append({"Variable": title})

    def add_row(label: str, term: str | None = None) -> None:
        row: Dict[str, object] = {"Variable": label}
        for outcome in outcomes:
            if term is None:
                row[f"{outcome} Estimate"] = ""
                row[f"{outcome} Pr(>|z|)"] = ""
                continue
            if term == "__INTERCEPT__":
                est, p = intercept_by_outcome.get(str(outcome), (float("nan"), float("nan")))
            else:
                est, p = by_term_outcome.get((term, str(outcome)), (float("nan"), float("nan")))
            row[f"{outcome} Estimate"] = _paper_estimate_str(est)
            row[f"{outcome} Pr(>|z|)"] = _paper_p_value_str(p)
        rows.append(row)

    add_row("(Intercept)", "__INTERCEPT__")

    for block_title, terms in row_blocks:
        rows.append({"Variable": block_title})
        for term in terms:
            add_row(f"  {_term_label(term)}", term)

    # n / BIC rows
    n_lookup = dict(zip(model_info_df["outcome"].astype(str), model_info_df["nobs"]))
    bic_lookup = dict(zip(model_info_df["outcome"].astype(str), model_info_df["bic"]))
    n_row: Dict[str, object] = {"Variable": "n"}
    bic_row: Dict[str, object] = {"Variable": "BIC"}
    for outcome in outcomes:
        n_row[f"{outcome} Estimate"] = int(n_lookup.get(str(outcome), 0)) or ""
        n_row[f"{outcome} Pr(>|z|)"] = ""
        bic_val = bic_lookup.get(str(outcome), float("nan"))
        bic_row[f"{outcome} Estimate"] = f"{float(bic_val):.1f}" if np.isfinite(bic_val) else ""
        bic_row[f"{outcome} Pr(>|z|)"] = ""
    rows.append(n_row)
    rows.append(bic_row)

    frame = pd.DataFrame(rows)
    # Ensure all expected columns exist
    cols = ["Variable"]
    for outcome in outcomes:
        cols += [f"{outcome} Estimate", f"{outcome} Pr(>|z|)"]
    for c in cols:
        if c not in frame.columns:
            frame[c] = ""
    return frame[cols]


def _export_paper_tables(
    *,
    output_dir: Path,
    outcomes: Sequence[str],
    main_models: List[sm.GLM],
    main_long: pd.DataFrame,
    main_info: pd.DataFrame,
    full_models: List[sm.GLM],
    full_long: pd.DataFrame,
    full_info: pd.DataFrame,
) -> None:
    # Main 8 (conceptual) terms
    main_terms = [
        "Barrier_Weights_Institutional",
        "Barrier_Weights_Technical",
        "Barrier_Weights_Political",
        "Deep_Metrics_Risk_GDP_Loss_Pct",
        "Metadata_GDP_pc_log1p",
        "Gov_Level",
        "Metadata_Region_R1",
        "Metadata_Region_R2",
        "Metadata_Region_R3",
        "Metadata_Region_R4",
        "Metadata_Climate_Zone_Z1",
        "Metadata_Climate_Zone_Z2",
        "Metadata_Climate_Zone_Z3",
        "Metadata_Climate_Zone_Z4",
    ]
    main_row_blocks = [
        ("Implementation barriers", main_terms[:3]),
        ("Risk pressure", [main_terms[3]]),
        ("Socioeconomic", main_terms[4:6]),
        ("Geographical region", main_terms[6:10]),
        ("Climate zone", main_terms[10:14]),
    ]
    main_table = _build_paper_table(
        outcomes=outcomes,
        models=main_models,
        long_df=main_long,
        model_info_df=main_info,
        row_blocks=main_row_blocks,
        title="Main-table predictors (8 conceptual variables)",
    )
    main_csv = output_dir / "paper_table_main8.csv"
    main_txt = output_dir / "paper_table_main8.txt"
    main_table.to_csv(main_csv, index=False, encoding="utf-8-sig")
    main_txt.write_text(main_table.to_string(index=False), encoding="utf-8")

    # Supplementary: everything in full model excluding main-table terms and intercept
    main_term_set = set(main_terms)
    remaining_terms = [t for t in sorted(full_long["term"].unique()) if t not in main_term_set]

    blocks: Dict[str, List[str]] = {"Other predictors": []}
    for term in remaining_terms:
        group, _ = _split_predictor_term(term)
        blocks.setdefault(group, []).append(term)

    # Keep a stable order for supplementary blocks
    ordered_groups = [
        "Barrier weights",
        "Deep metrics",
        "Doc language",
        "Socioeconomic",
        "Region",
        "Climate zone",
        "Other",
        "Other predictors",
    ]
    supp_row_blocks = [(g, blocks[g]) for g in ordered_groups if g in blocks and blocks[g]]

    supp_table = _build_paper_table(
        outcomes=outcomes,
        models=full_models,
        long_df=full_long,
        model_info_df=full_info,
        row_blocks=supp_row_blocks,
        title="Supplementary predictors (remaining variables)",
    )
    supp_csv = output_dir / "paper_table_supplement_remaining.csv"
    supp_txt = output_dir / "paper_table_supplement_remaining.txt"
    supp_table.to_csv(supp_csv, index=False, encoding="utf-8-sig")
    supp_txt.write_text(supp_table.to_string(index=False), encoding="utf-8")


def _forest_terms(long_df: pd.DataFrame) -> List[str]:
    if long_df.empty:
        return []
    keep_prefixes = (
        "Barrier_Weights_",
        "Metadata_Region_",
        "Metadata_Climate_Zone_",
        "Metadata_Doc_Language_",
        "Deep_Metrics_TSI_Score",
        "Deep_Metrics_PCS_Score",
        "Deep_Metrics_FGI_Pct",
        "Income_Level",
        "Gov_Level",
    )
    keep = []
    for term in sorted(long_df["term"].unique()):
        if term.startswith(keep_prefixes):
            keep.append(term)
    return keep


def _split_predictor_term(term: str) -> tuple[str, str]:
    prefixes = [
        ("Barrier_Weights_", "Barrier weights"),
        ("Metadata_Region_", "Region"),
        ("Metadata_Climate_Zone_", "Climate zone"),
        ("Metadata_Doc_Language_", "Doc language"),
        ("Deep_Metrics_", "Deep metrics"),
    ]
    for prefix, group in prefixes:
        if term.startswith(prefix):
            level = term[len(prefix):] or term
            return group, level.replace("_", " ")
    if term == "Income_Level":
        return "Socioeconomic", "Income level"
    if term == "Gov_Level":
        return "Socioeconomic", "Governance level"
    return "Other", term.replace("_", " ")


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="稳健清洗 + 6个GLM模型汇总 + 森林图（按真实数据）")
    parser.add_argument("--csv-path", default="all_l_dimensions.csv")
    parser.add_argument("--min-category-count", type=int, default=10)
    parser.add_argument("--selection", choices=["none", "stepwise"], default="none")
    parser.add_argument("--cov-type", choices=["cluster", "HC3", "HC1", "nonrobust"], default="cluster")
    parser.add_argument("--cluster-col", default="Country")
    parser.add_argument("--region-map", default=None, help="CSV mapping: raw_value,mapped_value for Metadata_Region")
    parser.add_argument("--climate-map", default=None, help="CSV mapping: raw_value,mapped_value for Metadata_Climate_Zone")
    parser.add_argument("--language-map", default=None, help="CSV mapping: raw_value,mapped_value for Metadata_Doc_Language")
    parser.add_argument("--export-mapping-templates", action="store_true", help="Export mapping templates and exit")
    parser.add_argument("--template-suggest-climate", choices=["none", "koppen5"], default="none")
    parser.add_argument("--template-suggest-region", choices=["none", "unesco5"], default="none")
    parser.add_argument("--max-candidates", type=int, default=60, help="stepwise预筛选的最大候选数")
    parser.add_argument("--step-in", type=float, default=0.05)
    parser.add_argument("--step-out", type=float, default=0.10)
    parser.add_argument("--max-steps", type=int, default=200)
    parser.add_argument("--max-features", type=int, default=35)
    args = parser.parse_args(list(argv) if argv is not None else None)

    csv_path = args.csv_path
    df_raw = pd.read_csv(csv_path)

    # Keep outputs next to the script for this project
    output_dir = SCRIPT_PATH.parent / "outputs"

    if args.export_mapping_templates:
        written = export_mapping_templates(
            df_raw,
            output_dir,
            suggest_climate=args.template_suggest_climate,
            suggest_region=args.template_suggest_region,
        )
        for p in written:
            print(f"Template: {p}")
        return 0

    # 默认映射文件路径（如果存在则自动加载）
    default_region_map = output_dir / "mapping_template_Metadata_Region.csv"
    default_climate_map = output_dir / "mapping_template_Metadata_Climate_Zone.csv"

    category_maps: Dict[str, Dict[str, str]] = {}
    # Region 映射
    region_map_path = args.region_map or (str(default_region_map) if default_region_map.exists() else None)
    if region_map_path:
        category_maps["Metadata_Region"] = _read_category_map(region_map_path)
        print(f"[info] Loaded region map: {region_map_path}")
    # Climate 映射
    climate_map_path = args.climate_map or (str(default_climate_map) if default_climate_map.exists() else None)
    if climate_map_path:
        category_maps["Metadata_Climate_Zone"] = _read_category_map(climate_map_path)
        print(f"[info] Loaded climate map: {climate_map_path}")
    # Language 映射
    if args.language_map:
        category_maps["Metadata_Doc_Language"] = _read_category_map(args.language_map)

    prepared = prepare_data(
        df_raw,
        min_category_count=args.min_category_count,
        category_maps=category_maps or None,
    )

    cov_type = args.cov_type
    if cov_type == "cluster" and args.cluster_col not in prepared.df.columns:
        cov_type = "HC3"

    output_dir.mkdir(parents=True, exist_ok=True)

    full_models, full_long_df, full_model_info_df = run_models(
        prepared,
        selection=args.selection,
        cov_type=cov_type,
        cluster_col=args.cluster_col,
        max_candidates=args.max_candidates,
        step_in=args.step_in,
        step_out=args.step_out,
        max_steps=args.max_steps,
        max_features=args.max_features,
    )

    long_out = output_dir / "all_l_dimensions_glm_multi_summary_long.csv"
    wide_out = output_dir / "all_l_dimensions_glm_multi_summary_wide.csv"
    wide_p_out = output_dir / "all_l_dimensions_glm_multi_summary_wide_with_p.csv"
    info_out = output_dir / "all_l_dimensions_glm_multi_model_info.csv"
    full_long_df.to_csv(long_out, index=False, encoding="utf-8-sig")
    _to_wide(full_long_df).to_csv(wide_out, index=False, encoding="utf-8-sig")
    _to_wide_with_p(full_long_df).to_csv(wide_p_out, index=False, encoding="utf-8-sig")
    full_model_info_df.to_csv(info_out, index=False, encoding="utf-8-sig")

    # Main table: refit restricted models with the eight conceptual predictors (plus Region/Climate levels)
    main8_cols = [
        "Barrier_Weights_Institutional",
        "Barrier_Weights_Technical",
        "Barrier_Weights_Political",
        "Deep_Metrics_Risk_GDP_Loss_Pct",
        "Metadata_GDP_pc_log1p",
        "Gov_Level",
        "Metadata_Region_R1",
        "Metadata_Region_R2",
        "Metadata_Region_R3",
        "Metadata_Region_R4",
        "Metadata_Climate_Zone_Z1",
        "Metadata_Climate_Zone_Z2",
        "Metadata_Climate_Zone_Z3",
        "Metadata_Climate_Zone_Z4",
    ]
    restricted = PreparedData(df=prepared.df, x_cols=[c for c in main8_cols if c in prepared.df.columns])
    main_models, main_long_df, main_info_df = run_models(
        restricted,
        selection="none",
        cov_type=cov_type,
        cluster_col=args.cluster_col,
        max_candidates=0,
        step_in=args.step_in,
        step_out=args.step_out,
        max_steps=args.max_steps,
        max_features=args.max_features,
    )
    main_info_out = output_dir / "all_l_dimensions_glm_main8_model_info.csv"
    main_info_df.to_csv(main_info_out, index=False, encoding="utf-8-sig")

    outcomes_order = [label for _, label in TARGETS]
    _export_paper_tables(
        output_dir=output_dir,
        outcomes=outcomes_order,
        main_models=main_models,
        main_long=main_long_df,
        main_info=main_info_df,
        full_models=full_models,
        full_long=full_long_df,
        full_info=full_model_info_df,
    )

    forest_terms = _forest_terms(full_long_df)
    if forest_terms:
        forest_df = full_long_df[full_long_df["term"].isin(forest_terms)].copy()
        forest_df = forest_df.rename(columns={"outcome": "Outcome", "term": "Predictor"})
        split = forest_df["Predictor"].map(_split_predictor_term)
        forest_df["Predictor_Group"] = split.map(lambda t: t[0])
        forest_df["Predictor_Level"] = split.map(lambda t: t[1])
        save_path = output_dir / "all_l_dimensions_glm_multi_forest"
        multi_model_forest(
            forest_df,
            model="Outcome",
            group="Predictor_Group",
            subgroup="Predictor_Level",
            estimate="estimate",
            ci_low="ci_low",
            ci_high="ci_high",
            p_value="p_value",
            reference=0.0,
            decimals=2,
            hr_label="β (95% CI)",
            model_order=[label for _, label in TARGETS],
            group_order=[
                "Barrier weights",
                "Region",
                "Climate zone",
                "Doc language",
                "Deep metrics",
                "Socioeconomic",
                "Other",
            ],
            per_model_width=2.35,
            left_margin=0.34,
            save_path=str(save_path),
            output_formats=("png", "svg"),
        )

    print(f"Done. Models: {len(full_models)}")
    print(f"Long summary: {long_out}")
    print(f"Wide summary: {wide_out}")
    print(f"Wide+P summary: {wide_p_out}")
    print(f"Model info: {info_out}")
    print(f"Main8 model info: {main_info_out}")
    print(f"Paper table (main8): {output_dir / 'paper_table_main8.csv'}")
    print(f"Paper table (supp): {output_dir / 'paper_table_supplement_remaining.csv'}")
    if forest_terms:
        print(f"Forest plot: {output_dir / 'all_l_dimensions_glm_multi_forest.svg'}")
        print(f"Forest plot: {output_dir / 'all_l_dimensions_glm_multi_forest.png'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
