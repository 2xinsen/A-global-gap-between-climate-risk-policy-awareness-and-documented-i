"""三元地图可视化模块 - 高精度国家边界版本

根据每个国家的三个维度数据，映射到RGB颜色空间，按国家边界多边形绘制。
输出字体可编辑的SVG格式。

特点：
- 高分辨率国家边界（50m或10m Natural Earth数据）
- 精细边界线和阴影效果
- 专业级图例设计
- 可编辑SVG输出
- 整合config.py统一配置
- 支持交互式模式选择

运行模式：
1. 模拟数据模式：生成示例数据，保存图片和CSV
2. 自定义数据模式：交互式输入国家数据
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
import matplotlib.patheffects as path_effects
from matplotlib.patches import Polygon as MplPolygon, Circle
from matplotlib.collections import PolyCollection
from typing import Tuple, Optional, Dict, List
import warnings
import os
import json
import pandas as pd  # 添加pandas用于数据读取

# 导入配置模块
try:
    from config import (
        MapStyleManager, MapColorConfig, MapTypographyConfig,
        MapAxesConfig, MapFigureConfig, get_default_style, apply_default_style,
        TERNARY_COLORS
    )
    HAS_CONFIG = True
except ImportError:
    HAS_CONFIG = False
    TERNARY_COLORS = {
        # 更柔和的三元锚点（避免默认过于鲜艳）
        "red": "#c44e52",
        "green": "#55a868",
        "blue": "#4c72b0",
    }

# 尝试导入geopandas
try:
    import geopandas as gpd
    from shapely.geometry import Polygon, MultiPolygon
    HAS_GEOPANDAS = True
except ImportError:
    HAS_GEOPANDAS = False
    warnings.warn("geopandas未安装，请运行: pip install geopandas")


# ==================== 数据加载与处理函数 ====================

def load_actual_data(csv_file='all_l_dimensions.csv'):
    """
    加载实际的地貌数据文件
    
    参数:
        csv_file: CSV文件路径
        
    返回:
        DataFrame: 包含所有地貌数据的DataFrame
    """
    try:
        df = pd.read_csv(csv_file)
        print(f"[SUCCESS] 成功加载数据文件: {csv_file}")
        print(f"   数据总记录数: {len(df)}")
        print(f"   国家数量: {df['Country'].nunique()}")
        print(f"   地貌类型: {df['Sub_Theme'].nunique()}")
        return df
    except FileNotFoundError:
        print(f"[ERROR] 错误: 找不到数据文件 {csv_file}")
        print("   请确保文件存在于当前目录中")
        return None
    except Exception as e:
        print(f"[ERROR] 读取数据时出错: {e}")
        return None

def aggregate_data_by_country(df):
    """
    按国家聚合R、A、Ac得分数据
    
    参数:
        df: 原始DataFrame
        
    返回:
        DataFrame: 按国家聚合后的数据
    """
    # 按国家分组，计算平均得分
    country_agg = df.groupby('Country').agg({
        'Scores_R_total_score': 'mean',      # 风险得分
        'Scores_A_total_score': 'mean',      # 意识得分  
        'Scores_Ac_total_score': 'mean',     # 行动得分
        'Metadata_Income_Group': 'first',    # 收入组
        'Metadata_Region': 'first',          # 地区
        'Unit_ID': 'count'                   # 记录数量
    }).reset_index()
    
    # 重命名记录数量列
    country_agg.rename(columns={'Unit_ID': 'Record_Count'}, inplace=True)
    
    # 标准化到0-1范围（用于RGB映射）
    max_score = 15  # 根据你的数据，最高分为15
    country_agg['R_normalized'] = country_agg['Scores_R_total_score'] / max_score
    country_agg['A_normalized'] = country_agg['Scores_A_total_score'] / max_score
    country_agg['Ac_normalized'] = country_agg['Scores_Ac_total_score'] / max_score
    
    print(f"[SUCCESS] 国家数据聚合完成，共{len(country_agg)}个国家")
    return country_agg

def aggregate_data_by_landform(df):
    """
    按地貌类型聚合R、A、Ac得分数据
    
    参数:
        df: 原始DataFrame
        
    返回:
        DataFrame: 按地貌类型聚合后的数据
    """
    # 按地貌类型分组，计算平均得分
    landform_agg = df.groupby('Sub_Theme').agg({
        'Scores_R_total_score': 'mean',      # 风险得分
        'Scores_A_total_score': 'mean',      # 意识得分
        'Scores_Ac_total_score': 'mean',     # 行动得分
        'Unit_ID': 'count'                   # 记录数量
    }).reset_index()
    
    # 标准化到0-1范围
    max_score = 15
    landform_agg['R_normalized'] = landform_agg['Scores_R_total_score'] / max_score
    landform_agg['A_normalized'] = landform_agg['Scores_A_total_score'] / max_score
    landform_agg['Ac_normalized'] = landform_agg['Scores_Ac_total_score'] / max_score
    
    print(f"[SUCCESS] 地貌数据聚合完成，共{len(landform_agg)}类地貌")
    return landform_agg

def prepare_data_for_ternary_map(agg_data, data_type='country'):
    """
    为三元图准备数据格式
    
    参数:
        agg_data: 聚合后的数据
        data_type: 数据类型 ('country' 或 'landform')
        
    返回:
        dict: 格式化的数据字典（元组格式，兼容原有函数）
    """
    if data_type == 'country':
        # 国家数据格式 - 返回元组(R, A, Ac)
        ternary_data = {}
        for _, row in agg_data.iterrows():
            country_name = row['Country']
            ternary_data[country_name] = (
                row['R_normalized'],
                row['A_normalized'], 
                row['Ac_normalized']
            )
    else:
        # 地貌数据格式 - 返回元组(R, A, Ac)
        ternary_data = {}
        for _, row in agg_data.iterrows():
            landform_name = row['Sub_Theme']
            ternary_data[landform_name] = (
                row['R_normalized'],
                row['A_normalized'],
                row['Ac_normalized']
            )
    
    print(f"[SUCCESS] {data_type}数据格式化完成，共{len(ternary_data)}个单元")
    return ternary_data

# ==================== 言行不一差距（行动-意识） ====================

def compute_country_awareness_action_gap(df: 'pd.DataFrame') -> 'pd.DataFrame':
    """
    基于原始数据，按国家计算“言行不一”差距：行动(Ac)均值 - 意识(A)均值。

    同时计算每国地貌数量（Sub_Theme 的去重数量），用于散点大小。
    """
    required = ["Country", "Sub_Theme", "Scores_A_total_score", "Scores_Ac_total_score"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"原始数据缺少必要列: {missing}")

    g = df.groupby("Country", dropna=False)
    out = g.agg(
        A_mean=("Scores_A_total_score", "mean"),
        Ac_mean=("Scores_Ac_total_score", "mean"),
        Landform_Count=("Sub_Theme", lambda s: s.dropna().nunique()),
        Record_Count=("Unit_ID", "count") if "Unit_ID" in df.columns else ("Sub_Theme", "size"),
        Metadata_Region=("Metadata_Region", "first") if "Metadata_Region" in df.columns else ("Country", "first"),
        Metadata_Income_Group=("Metadata_Income_Group", "first") if "Metadata_Income_Group" in df.columns else ("Country", "first"),
    ).reset_index()

    # 主指标：行动-意识（Ac - A）。为兼容既有分析，也保留意识-行动（A - Ac）。
    out["Gap_Ac_minus_A"] = out["Ac_mean"] - out["A_mean"]
    out["Gap_A_minus_Ac"] = out["A_mean"] - out["Ac_mean"]
    return out


def create_country_gap_scatter_map(
    gap_df: 'pd.DataFrame',
    resolution: str = "50m",
    extent: Optional[Tuple[float, float, float, float]] = None,
    title: str = "Country action-awareness gap (Ac - A)",
    ocean_color: Optional[str] = None,
    land_color: str = "#f2f2f2",
    border_color: str = "#9a9a9a",
    border_lw: float = 0.25,
    min_dot_size: float = 10.0,
    max_dot_size: float = 60.0,
    cmap: str = "RdBu_r",
    gap_col: str = "Gap_Ac_minus_A",
) -> Tuple[plt.Figure, plt.Axes]:
    """世界地图：散点颜色=差距(Ac-A)，散点大小=地貌数量（带上限），附带图例。"""
    if not HAS_GEOPANDAS:
        raise ImportError("需要安装geopandas: pip install geopandas")

    config = get_config()
    config.apply()

    if ocean_color is None:
        ocean_color = config.ocean_color

    world_gdf = get_natural_earth_countries(resolution)
    fig, ax = plt.subplots(figsize=config.figsize, facecolor="white")
    if ocean_color != "none":
        ax.set_facecolor(ocean_color)

    if extent:
        ax.set_xlim(extent[0], extent[1])
        ax.set_ylim(extent[2], extent[3])
    else:
        ax.set_xlim(-180, 180)
        ax.set_ylim(-60, 85)

    _add_graticules(ax, extent)
    _add_coordinate_frame(ax, extent)

    # 画底图（浅灰陆地）
    for _, row in world_gdf.iterrows():
        geom = row.geometry
        if geom is None or geom.is_empty:
            continue
        patches = geometry_to_patches(geom, facecolor=land_color, edgecolor=border_color, linewidth=border_lw, alpha=1.0)
        for p in patches:
            ax.add_patch(p)

    # 准备映射（国家名 -> gap/size）
    gap_df = gap_df.copy()
    gap_df["Country"] = gap_df["Country"].astype(str)
    if gap_col not in gap_df.columns:
        gap_col = "Gap_A_minus_Ac" if "Gap_A_minus_Ac" in gap_df.columns else gap_col
    gap_map = dict(zip(gap_df["Country"], gap_df[gap_col].astype(float)))
    size_map = dict(zip(gap_df["Country"], gap_df["Landform_Count"].astype(float)))

    # alias 扩展（处理 Natural Earth 名称差异）
    gap_map, alias_to_source = _expand_country_data_aliases({k: (v, 0.0, 0.0) for k, v in gap_map.items()})
    # 还原成单值映射
    gap_map = {k: float(v[0]) for k, v in gap_map.items()}
    size_map, _alias2 = _expand_country_data_aliases({k: (v, 0.0, 0.0) for k, v in size_map.items()})
    size_map = {k: float(v[0]) for k, v in size_map.items()}

    xs, ys, gaps, sizes = [], [], [], []
    matched = set()

    for _, row in world_gdf.iterrows():
        geom = row.geometry
        if geom is None or geom.is_empty:
            continue

        key = None
        for col in ["iso_a3", "ISO_A3", "ADM0_A3", "SOV_A3", "name", "NAME", "ADMIN", "NAME_EN", "NAME_LONG", "FORMAL_EN", "NAME_CIAWF", "NAME_SORT", "SUBUNIT", "BRK_NAME", "NAME_TR"]:
            if col in row.index:
                v = row[col]
                if v and v != "-99" and v in gap_map:
                    key = v
                    break
        if key is None:
            continue

        try:
            pt = geom.representative_point()
        except Exception:
            continue

        src = alias_to_source.get(key, key)
        matched.add(src)
        xs.append(float(pt.x))
        ys.append(float(pt.y))
        gaps.append(float(gap_map[key]))
        sizes.append(float(size_map.get(key, 0.0)))

    if not gaps:
        raise RuntimeError("没有匹配到任何国家的差距数据，无法绘图")

    gaps_arr = np.asarray(gaps, dtype=float)
    sizes_arr = np.asarray(sizes, dtype=float)
    # 大小映射（限制上限，避免过大遮挡）
    smin, smax = float(np.nanmin(sizes_arr)), float(np.nanmax(sizes_arr))
    if smax - smin < 1e-9:
        scaled = np.full_like(sizes_arr, (min_dot_size + max_dot_size) / 2.0)
    else:
        scaled = min_dot_size + (sizes_arr - smin) / (smax - smin) * (max_dot_size - min_dot_size)
    scaled = np.clip(scaled, min_dot_size, max_dot_size)

    # 颜色归一化：以 0 为中心的发散色带
    try:
        from matplotlib.colors import TwoSlopeNorm
        v = float(np.nanmax(np.abs(gaps_arr)))
        norm = TwoSlopeNorm(vmin=-v, vcenter=0.0, vmax=v)
    except Exception:
        norm = None

    sc = ax.scatter(
        xs,
        ys,
        s=scaled,
        c=gaps_arr,
        cmap=cmap,
        norm=norm,
        alpha=0.9,
        edgecolors="white",
        linewidths=0.35,
        zorder=10,
    )

    # 颜色图例（colorbar）
    cbar = fig.colorbar(sc, ax=ax, fraction=0.03, pad=0.02)
    cbar.set_label("Gap (Ac - A)", fontsize=8)
    cbar.ax.tick_params(labelsize=7)

    # 大小图例（选 3 个参考值）
    q = np.nanpercentile(sizes_arr, [25, 50, 75]).tolist()
    ref_vals = sorted(set(int(round(x)) for x in q if np.isfinite(x)))
    if len(ref_vals) < 3:
        ref_vals = sorted(set([int(round(smin)), int(round((smin + smax) / 2)), int(round(smax))]))
    ref_vals = [v for v in ref_vals if v >= 0][:3]
    if not ref_vals:
        ref_vals = [1, 4, 8]

    def _size_for(vv: float) -> float:
        if smax - smin < 1e-9:
            return (min_dot_size + max_dot_size) / 2.0
        ss = min_dot_size + (vv - smin) / (smax - smin) * (max_dot_size - min_dot_size)
        return float(np.clip(ss, min_dot_size, max_dot_size))

    handles = [
        plt.scatter([], [], s=_size_for(vv), c="#666666", alpha=0.9, edgecolors="white", linewidths=0.35, label=f"{vv}")
        for vv in ref_vals
    ]
    ax.legend(
        handles=handles,
        title="Landform count",
        loc="lower right",
        fontsize=7,
        title_fontsize=8,
        frameon=True,
        framealpha=0.92,
        borderpad=0.6,
        labelspacing=0.35,
        handletextpad=0.6,
    )

    ax.set_title(title, fontsize=config.title_size, fontweight="normal", pad=12, color="#222222")
    plt.tight_layout()
    return fig, ax


def add_gap_scatter_overlay(
    fig: plt.Figure,
    ax: plt.Axes,
    world_gdf: 'gpd.GeoDataFrame',
    gap_df: 'pd.DataFrame',
    extent: Optional[Tuple[float, float, float, float]] = None,
    min_dot_size: float = 8.0,
    max_dot_size: float = 45.0,
    cmap: str = "RdBu_r",
    gap_col: str = "Gap_Ac_minus_A",
):
    """在已有底图（例如三元国家底色）上叠加差距散点与“分格”图例。"""
    gap_df = gap_df.copy()
    gap_df["Country"] = gap_df["Country"].astype(str)
    if gap_col not in gap_df.columns:
        gap_col = "Gap_A_minus_Ac" if "Gap_A_minus_Ac" in gap_df.columns else gap_col
    gap_map = dict(zip(gap_df["Country"], gap_df[gap_col].astype(float)))
    size_map = dict(zip(gap_df["Country"], gap_df["Landform_Count"].astype(float)))

    # alias 扩展（处理 Natural Earth 名称差异）
    gap_map, alias_to_source = _expand_country_data_aliases({k: (v, 0.0, 0.0) for k, v in gap_map.items()})
    gap_map = {k: float(v[0]) for k, v in gap_map.items()}
    size_map, _ = _expand_country_data_aliases({k: (v, 0.0, 0.0) for k, v in size_map.items()})
    size_map = {k: float(v[0]) for k, v in size_map.items()}

    xs, ys, gaps, sizes = [], [], [], []
    matched = set()

    for _, row in world_gdf.iterrows():
        geom = row.geometry
        if geom is None or geom.is_empty:
            continue

        key = None
        for col in [
            "name",
            "NAME",
            "ADMIN",
            "NAME_EN",
            "NAME_LONG",
            "FORMAL_EN",
            "NAME_CIAWF",
            "NAME_SORT",
            "SUBUNIT",
            "BRK_NAME",
            "NAME_TR",
            "iso_a3",
            "ISO_A3",
            "ADM0_A3",
            "SOV_A3",
        ]:
            if col in row.index:
                v = row[col]
                if v and v != "-99" and v in gap_map:
                    key = v
                    break
        if key is None:
            continue

        try:
            pt = geom.representative_point()
        except Exception:
            continue

        src = alias_to_source.get(key, key)
        matched.add(src)
        xs.append(float(pt.x))
        ys.append(float(pt.y))
        gaps.append(float(gap_map[key]))
        sizes.append(float(size_map.get(key, 0.0)))

    if not gaps:
        raise RuntimeError("没有匹配到任何国家的差距数据，无法叠加散点")

    gaps_arr = np.asarray(gaps, dtype=float)
    sizes_arr = np.asarray(sizes, dtype=float)

    smin, smax = float(np.nanmin(sizes_arr)), float(np.nanmax(sizes_arr))
    if smax - smin < 1e-9:
        scaled = np.full_like(sizes_arr, (min_dot_size + max_dot_size) / 2.0)
    else:
        scaled = min_dot_size + (sizes_arr - smin) / (smax - smin) * (max_dot_size - min_dot_size)
    scaled = np.clip(scaled, min_dot_size, max_dot_size)

    # 分格离散色带（参考 gap_world_map.py 的 Nature 风格）
    v_abs = float(np.nanmax(np.abs(gaps_arr)))
    if not np.isfinite(v_abs) or v_abs <= 0:
        v_abs = 1.0

    def _choose_step(max_abs: float) -> float:
        if max_abs <= 2:
            return 0.5
        if max_abs <= 5:
            return 1.0
        if max_abs <= 12:
            return 2.0
        if max_abs <= 25:
            return 5.0
        return 10.0

    step = _choose_step(v_abs)
    bound_max = float(np.ceil(v_abs / step) * step)
    half_step = step / 2.0
    midpoints = np.arange(-bound_max, bound_max + step * 0.5, step, dtype=float)
    boundaries = np.concatenate([midpoints - half_step, [midpoints[-1] + half_step]])

    cmap_obj = plt.get_cmap(cmap)
    try:
        continuous_norm = mpl.colors.TwoSlopeNorm(vmin=-bound_max, vcenter=0.0, vmax=bound_max)
        colors = [cmap_obj(continuous_norm(v)) for v in midpoints]
    except Exception:
        colors = [cmap_obj((v + bound_max) / (2 * bound_max)) for v in midpoints]

    discrete_cmap = mpl.colors.ListedColormap(colors, name=f"{cmap}_discrete")
    discrete_norm = mpl.colors.BoundaryNorm(boundaries, ncolors=discrete_cmap.N, clip=True)

    sc = ax.scatter(
        xs,
        ys,
        s=scaled,
        c=gaps_arr,
        cmap=discrete_cmap,
        norm=discrete_norm,
        alpha=0.9,
        edgecolors="white",
        linewidths=0.35,
        zorder=12,
    )

    # 颜色图例（分格 colorbar，带边框）
    from matplotlib.ticker import FuncFormatter

    sm = mpl.cm.ScalarMappable(cmap=discrete_cmap, norm=discrete_norm)
    sm.set_array([])
    cbar = fig.colorbar(
        sm,
        ax=ax,
        orientation="vertical",
        ticks=midpoints,
        boundaries=boundaries,
        drawedges=True,
        spacing="proportional",
        fraction=0.03,
        pad=0.02,
    )
    cbar.set_label("Gap (Ac - A)", fontsize=8, fontweight="normal", rotation=90)
    cbar.ax.tick_params(labelsize=7, width=0.6, length=4)
    cbar.ax.yaxis.set_major_formatter(
        FuncFormatter(lambda x, pos: "0" if abs(x) < 1e-10 else f"{x:.2f}".rstrip("0").rstrip("."))
    )
    if hasattr(cbar, "solids") and cbar.solids is not None:
        cbar.solids.set_edgecolor("white")
        cbar.solids.set_linewidth(0.6)
    if hasattr(cbar, "outline") and cbar.outline is not None:
        cbar.outline.set_linewidth(0.6)

    # 大小图例
    q = np.nanpercentile(sizes_arr, [25, 50, 75]).tolist()
    ref_vals = sorted(set(int(round(x)) for x in q if np.isfinite(x)))
    if len(ref_vals) < 3:
        ref_vals = sorted(set([int(round(smin)), int(round((smin + smax) / 2)), int(round(smax))]))
    ref_vals = [v for v in ref_vals if v >= 0][:3]
    if not ref_vals:
        ref_vals = [1, 4, 8]

    def _size_for(vv: float) -> float:
        if smax - smin < 1e-9:
            return (min_dot_size + max_dot_size) / 2.0
        ss = min_dot_size + (vv - smin) / (smax - smin) * (max_dot_size - min_dot_size)
        return float(np.clip(ss, min_dot_size, max_dot_size))

    handles = [
        plt.scatter([], [], s=_size_for(vv), c="#666666", alpha=0.9, edgecolors="white", linewidths=0.35, label=f"{vv}")
        for vv in ref_vals
    ]
    ax.legend(
        handles=handles,
        title="Landform count",
        loc="lower right",
        fontsize=7,
        title_fontsize=8,
        frameon=True,
        framealpha=0.92,
        borderpad=0.6,
        labelspacing=0.35,
        handletextpad=0.6,
    )

    if extent:
        ax.set_xlim(extent[0], extent[1])
        ax.set_ylim(extent[2], extent[3])

# ==================== 国家聚类（实际数据模式） ====================

def _zscore_3cols(values: np.ndarray, eps: float = 1e-12) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """对 (N,3) 数组做 z-score，返回标准化值、均值、标准差。"""
    values = np.asarray(values, dtype=float)
    mean = values.mean(axis=0)
    std = values.std(axis=0)
    std = np.where(std < eps, 1.0, std)
    return (values - mean) / std, mean, std


def _infer_cluster_name(center: np.ndarray, global_mean: np.ndarray, global_std: np.ndarray, lang: str = "zh") -> str:
    """基于聚类中心的相对高低与主导维度，生成可读的聚类名称。"""
    dims = ["风险(R)", "意识(A)", "行动(Ac)"]
    center = np.asarray(center, dtype=float)

    def level(v, m, s):
        if v >= m + 0.5 * s:
            return "高" if lang == "zh" else "High"
        if v <= m - 0.5 * s:
            return "低" if lang == "zh" else "Low"
        return "中" if lang == "zh" else "Mid"

    lv = [level(center[i], global_mean[i], global_std[i]) for i in range(3)]
    dom = int(np.argmax(center))
    gap_ac_r = center[2] - center[0]

    if lv == ["高", "高", "高"]:
        return "高三维高水平型" if lang == "zh" else "High across R/A/Ac"
    if lv == ["低", "低", "低"]:
        return "低三维低水平型" if lang == "zh" else "Low across R/A/Ac"

    if dom == 0 and (lv[2] == "低" or gap_ac_r < -0.6 * global_std[0]):
        return f"{lv[0]}风险-{lv[1]}意识-{lv[2]}行动（行动不足）" if lang == "zh" else "Risk-dominant (action lag)"
    if dom == 2 and (lv[0] != "高" or gap_ac_r > 0.3 * global_std[0]):
        return f"{lv[0]}风险-{lv[1]}意识-{lv[2]}行动（行动领先）" if lang == "zh" else "Action-dominant (action lead)"
    if dom == 1:
        return f"{lv[0]}风险-{lv[1]}意识-{lv[2]}行动（意识主导）" if lang == "zh" else "Awareness-dominant"

    if lang == "zh":
        dom_txt = dims[dom]
        return f"{lv[0]}风险-{lv[1]}意识-{lv[2]}行动（{dom_txt}偏高）"
    dom_txt_en = ["Risk (R)", "Awareness (A)", "Action (Ac)"][dom]
    return f"{lv[0]}R-{lv[1]}A-{lv[2]}Ac (dominant: {dom_txt_en})"


def cluster_countries_by_scores(
    country_agg: 'pd.DataFrame',
    n_clusters: int = 4,
    random_state: int = 42,
    n_init: int = 15,
) -> 'pd.DataFrame':
    """
    对国家的 (R,A,Ac) 三维得分做 K-Means 聚类，并生成聚类名称/颜色/三元坐标。

    返回的 DataFrame 会新增：
    - Cluster_ID, Cluster_Name, Cluster_Color
    - Ternary_Rw/Aw/Acw, Ternary_X, Ternary_Y
    """
    required = ["Country", "Scores_R_total_score", "Scores_A_total_score", "Scores_Ac_total_score"]
    missing = [c for c in required if c not in country_agg.columns]
    if missing:
        raise ValueError(f"country_agg 缺少必要列: {missing}")

    df = country_agg.copy()
    X = df[["Scores_R_total_score", "Scores_A_total_score", "Scores_Ac_total_score"]].to_numpy(dtype=float)

    ok = np.isfinite(X).all(axis=1)
    df = df.loc[ok].reset_index(drop=True)
    X = X[ok]
    if len(df) == 0:
        raise ValueError("没有可用于聚类的国家记录（全为缺失/非数值）")

    Xz, mean, std = _zscore_3cols(X)

    try:
        from scipy.cluster.vq import kmeans2
    except Exception as e:
        raise ImportError("需要 scipy 才能进行聚类 (scipy.cluster.vq.kmeans2)") from e

    best = None
    best_inertia = float("inf")
    rng = np.random.RandomState(random_state)
    for _ in range(max(1, int(n_init))):
        seed = int(rng.randint(0, 2**31 - 1))
        np.random.seed(seed)
        centroids_z, labels = kmeans2(Xz, k=n_clusters, iter=80, minit="++")
        d2 = np.sum((Xz - centroids_z[labels]) ** 2, axis=1)
        inertia = float(d2.sum())
        if inertia < best_inertia:
            best_inertia = inertia
            best = (centroids_z, labels)

    if best is None:
        raise RuntimeError("聚类失败：未得到有效结果")

    centroids_z, labels = best
    centroids = centroids_z * std + mean

    # 稳定排序：先按主导维度(行动/意识/风险)再按总体均值降序
    dom = np.argmax(centroids, axis=1)
    order = sorted(range(n_clusters), key=lambda i: (-(dom[i]), -float(centroids[i].mean())))
    remap = {old: new for new, old in enumerate(order)}
    labels_remap = np.array([remap[int(i)] for i in labels], dtype=int)
    centroids_remap = np.vstack([centroids[order[i]] for i in range(n_clusters)])

    base_colors = ["#4C72B0", "#55A868", "#C44E52", "#8172B2", "#CCB974", "#64B5CD"]
    colors = [base_colors[i % len(base_colors)] for i in range(n_clusters)]
    names_zh = [_infer_cluster_name(centroids_remap[i], mean, std, lang="zh") for i in range(n_clusters)]
    names_en = [_infer_cluster_name(centroids_remap[i], mean, std, lang="en") for i in range(n_clusters)]

    def ensure_unique(names: List[str], prefix: str) -> List[str]:
        counts: Dict[str, int] = {}
        for n in names:
            counts[n] = counts.get(n, 0) + 1
        out = []
        for i, n in enumerate(names):
            if counts.get(n, 0) > 1:
                out.append(f"{n} ({prefix}{i+1})")
            else:
                out.append(n)
        return out

    names_zh = ensure_unique(names_zh, "类")
    names_en = ensure_unique(names_en, "C")

    df["Cluster_ID"] = labels_remap
    df["Cluster_Name"] = df["Cluster_ID"].map({i: names_zh[i] for i in range(n_clusters)})
    df["Cluster_Name_EN"] = df["Cluster_ID"].map({i: names_en[i] for i in range(n_clusters)})
    df["Cluster_Color"] = df["Cluster_ID"].map({i: colors[i] for i in range(n_clusters)})

    # 三元权重与坐标（用于散点与圈选）
    vals = df[["Scores_R_total_score", "Scores_A_total_score", "Scores_Ac_total_score"]].to_numpy(dtype=float)
    s = vals.sum(axis=1, keepdims=True)
    s = np.where(s <= 0, 1.0, s)
    w = vals / s
    df["Ternary_Rw"] = w[:, 0]
    df["Ternary_Aw"] = w[:, 1]
    df["Ternary_Acw"] = w[:, 2]
    h = np.sqrt(3) / 2
    df["Ternary_X"] = df["Ternary_Aw"] + 0.5 * df["Ternary_Acw"]
    df["Ternary_Y"] = df["Ternary_Acw"] * h

    return df

# ==================== 配置管理 ====================

class TernaryMapConfig:
    """三元地图配置类 - 整合config.py"""

    def __init__(self, style_manager: Optional['MapStyleManager'] = None):
        if HAS_CONFIG and style_manager is None:
            self.style = get_default_style()
        elif style_manager:
            self.style = style_manager
        else:
            self.style = None

        # 从config获取或使用默认值
        if self.style:
            colors = self.style.colors
            # 使用CMY高对比度配色
            self.ternary_colors = (
                (1.0, 1.0, 0.0),      # 左下角 - 亮黄
                (0.1176, 0.5647, 1.0),# 右下角 - 道奇蓝
                (1.0, 0.0, 0.498),    # 顶点 - 艳粉
            )
            self.ocean_color = colors.ocean_color
            self.border_color = colors.border_color
            self.figsize = (self.style.figure.default_width, self.style.figure.default_height)
            self.dpi = self.style.figure.dpi
            self.title_size = self.style.typography.title_size
            self.label_size = self.style.typography.label_size
            self.tick_size = self.style.typography.tick_size
            self.legend_size = self.style.typography.legend_size
            self.frame_color = self.style.axes.spine_color
            self.frame_linewidth = self.style.axes.spine_linewidth
            self.grid_color = self.style.axes.grid_color
            self.grid_alpha = self.style.axes.grid_alpha
        else:
            # 默认配置 - 使用CMY高对比度配色
            self.ternary_colors = (
                (1.0, 1.0, 0.0),      # 左下角 - 亮黄
                (0.1176, 0.5647, 1.0),# 右下角 - 道奇蓝
                (1.0, 0.0, 0.498),    # 顶点 - 艳粉
            )
            self.ocean_color = "none"
            self.border_color = "#404040"
            self.figsize = (16, 10)
            self.dpi = 300
            self.title_size = 14
            self.label_size = 10
            self.tick_size = 8
            self.legend_size = 9
            self.frame_color = "#333333"
            self.frame_linewidth = 1.0
            self.grid_color = "#cccccc"
            self.grid_alpha = 0.4

    def apply(self):
        """应用样式配置"""
        if self.style:
            self.style.apply()
        else:
            plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'Arial']
            plt.rcParams['axes.unicode_minus'] = False
        # 确保SVG文字可编辑 - 必须在创建图形前设置
        mpl.rcParams['svg.fonttype'] = 'none'
        mpl.rcParams['pdf.fonttype'] = 42


# 全局配置实例
_config = None

def get_config() -> TernaryMapConfig:
    """获取全局配置"""
    global _config
    if _config is None:
        _config = TernaryMapConfig()
    return _config

def set_config(config: TernaryMapConfig):
    """设置全局配置"""
    global _config
    _config = config


# ==================== 颜色映射 ====================

class TernaryColorMapper:
    """三元颜色映射器 - 完全离散，每个小三角形使用固定色板（无需颜色计算/混合）"""

    def __init__(self, colors: Optional[Tuple[Tuple[float, ...], ...]] = None,
                 white_mix: float = 0.0, gamma: float = 1.0):
        """
        colors: 可选自定义顶点三色 (bottom-left, bottom-right, top)，仅用于覆盖顶点色。
        white_mix/gamma: 保留旧参数，不做默认白化/渐变。
        """
        # 参考色板（按行从顶到底、从左到右）
        palette_rows_hex = [
            ["#FF1493"],  # 顶端
            ["#FF4081", "#FF69B4", "#D500F9"],
            ["#FF7043", "#FF8A80", "#E1BEE7", "#B39DDB", "#7C4DFF"],
            ["#FFFF00", "#CDDC39", "#9CCC65", "#4DD0E1", "#4FC3F7", "#2196F3", "#2962FF"],
        ]

        # 顶点覆盖
        if colors is not None:
            palette_rows_hex[0][0] = self._rgb_to_hex(colors[2])  # 顶点
            palette_rows_hex[3][0] = self._rgb_to_hex(colors[0])  # 左底
            palette_rows_hex[3][-1] = self._rgb_to_hex(colors[1]) # 右底

        # 预生成 16 个小三角形的几何与颜色（边长划分 n=4）
        self.triangles = self._build_discrete_triangles(palette_rows_hex, n=4)
        self.white_mix = max(0.0, min(1.0, float(white_mix)))
        self.gamma = float(gamma)
        self.white_point = np.array([1.0, 1.0, 1.0], dtype=float)

    @staticmethod
    def _hex_to_rgb(hex_color: str) -> np.ndarray:
        hex_color = hex_color.lstrip('#')
        return np.array([int(hex_color[i:i+2], 16) for i in (0, 2, 4)], dtype=float) / 255.0

    @staticmethod
    def _rgb_to_hex(rgb: Tuple[float, ...]) -> str:
        r, g, b = [max(0, min(1, c)) for c in rgb]
        return "#{:02X}{:02X}{:02X}".format(int(r * 255), int(g * 255), int(b * 255))

    @staticmethod
    def _to_xy(r: float, a: float, ac: float) -> Tuple[float, float]:
        """三元坐标 -> 平面坐标"""
        h = np.sqrt(3) / 2
        x = a + ac * 0.5
        y = ac * h
        return x, y

    def _build_discrete_triangles(self, palette_rows_hex: List[List[str]], n: int = 4):
        """生成 16 个小三角形的顶点和颜色（不做插值）"""
        triangles = []

        # 生成所有小三角形的几何（基于等分 n=4 的标准网格）
        def add_triangle(verts, key):
            cx = sum(p[0] for p in verts) / 3
            cy = sum(p[1] for p in verts) / 3
            triangles.append({"verts": verts, "key": key, "centroid": (cx, cy)})

        # 上向三角形
        for i in range(n):
            for j in range(n - i):
                k = n - i - j
                if k <= 0:
                    continue
                p1 = self._to_xy((i + 1) / n, j / n, (k - 1) / n)
                p2 = self._to_xy(i / n, (j + 1) / n, (k - 1) / n)
                p3 = self._to_xy(i / n, j / n, k / n)
                add_triangle([p1, p2, p3], (i, j, k, "up"))

        # 下向三角形
        for i in range(n):
            for j in range(n - i - 1):
                k = n - i - j
                if k <= 1:
                    continue
                p1 = self._to_xy((i + 1) / n, j / n, (k - 1) / n)
                p2 = self._to_xy((i + 1) / n, (j + 1) / n, (k - 2) / n)
                p3 = self._to_xy(i / n, (j + 1) / n, (k - 1) / n)
                add_triangle([p1, p2, p3], (i, j, k - 1, "down"))

        # 按行（k 值）从上到下，行内按 x 从左到右分配色板
        row_colors = palette_rows_hex
        triangles_by_k: Dict[int, List[Dict]] = {}
        for tri in triangles:
            k_val = tri["key"][2]  # k 对应顶点权重的整数份数
            triangles_by_k.setdefault(k_val, []).append(tri)

        colored = []
        for k_val, colors in zip([4, 3, 2, 1], row_colors):
            tris = sorted(triangles_by_k.get(k_val, []), key=lambda t: t["centroid"][0])
            if len(tris) != len(colors):
                raise ValueError("离散三角数量与色板长度不匹配")
            for tri, color_hex in zip(tris, colors):
                tri["color"] = self._hex_to_rgb(color_hex)
                colored.append(tri)

        # 按 y 从高到低排序，便于后续绘制
        colored.sort(key=lambda t: (-t["centroid"][1], t["centroid"][0]))
        return colored

    @staticmethod
    def _point_in_triangle(pt: Tuple[float, float], tri: List[Tuple[float, float]], eps: float = 1e-9) -> bool:
        """判断点是否在三角形内（含边界）"""
        (x, y) = pt
        (x1, y1), (x2, y2), (x3, y3) = tri
        denom = (y2 - y3) * (x1 - x3) + (x3 - x2) * (y1 - y3)
        if abs(denom) < eps:
            return False
        a = ((y2 - y3) * (x - x3) + (x3 - x2) * (y - y3)) / denom
        b = ((y3 - y1) * (x - x3) + (x1 - x3) * (y - y3)) / denom
        c = 1 - a - b
        return (a >= -eps) and (b >= -eps) and (c >= -eps)

    def map_single(self, v1: float, v2: float, v3: float,
                   intensity: float = 1.0) -> Tuple[float, float, float, float]:
        """将单个国家的三个变量值映射到RGBA颜色（直接落到固定色块，无渐变）"""
        values = np.clip(np.array([v1, v2, v3], dtype=float), 0, None)
        total = values.sum()
        if total <= 0:
            return (0.9, 0.9, 0.9, 1.0)  # 无数据时显示浅灰

        weights = values / total
        # 三元坐标 -> 平面点
        x, y = self._to_xy(weights[1], weights[0], weights[2])  # 使用现有 to_ternary_coords 规则

        # 找到所在小三角形
        chosen = None
        for tri in self.triangles:
            if self._point_in_triangle((x, y), tri["verts"]):
                chosen = tri
                break

        # 边界情况下未命中则选最近质心
        if chosen is None:
            d2 = [ ( (x - t["centroid"][0])**2 + (y - t["centroid"][1])**2, t) for t in self.triangles ]
            chosen = min(d2, key=lambda p: p[0])[1]

        color = chosen["color"]
        if self.white_mix > 0:
            dominance = weights.max()
            white_ratio = self.white_mix * (1 - dominance)
            color = color * (1 - white_ratio) + self.white_point * white_ratio

        if self.gamma != 1.0:
            color = np.clip(color, 0, 1) ** (1 / self.gamma)

        rgb = np.clip(color * intensity, 0, 1)
        return tuple(rgb) + (1.0,)

    def map_batch(self, v1_arr: np.ndarray, v2_arr: np.ndarray,
                  v3_arr: np.ndarray, normalize: bool = True) -> np.ndarray:
        """批量处理颜色（直接调用 map_single，确保与离散色块一致）"""
        v1 = np.asarray(v1_arr, dtype=np.float64)
        v2 = np.asarray(v2_arr, dtype=np.float64)
        v3 = np.asarray(v3_arr, dtype=np.float64)
        if normalize:
            total = v1 + v2 + v3
            total = np.where(total == 0, 1, total)
            v1, v2, v3 = v1 / total, v2 / total, v3 / total

        colors = [self.map_single(a, b, c)[:3] for a, b, c in zip(v1, v2, v3)]
        return np.array(colors)


# ==================== 图例生成 ====================

class ProfessionalTernaryLegend:
    """专业级三角形图例生成器 - 参考科学期刊标准样式"""

    def __init__(self, mapper: TernaryColorMapper, resolution: int = 80):
        self.mapper = mapper
        self.resolution = resolution
        self.config = get_config()

    def plot(self, ax: plt.Axes, labels: Tuple[str, str, str] = ('Var1', 'Var2', 'Var3'),
             fontsize: Optional[int] = None, title: Optional[str] = None,
             show_ticks: bool = True, show_grid: bool = True, discrete: bool = False):
        """
        绑制三角形图例，样式参考科学期刊标准

        参数:
            labels: 三个变量的标签 (左下角, 右下角, 顶点)
            fontsize: 字体大小
            show_ticks: 是否显示刻度
            show_grid: 是否显示格线
            discrete: 是否使用离散配色（默认False，使用连续渐变）
        """
        if fontsize is None:
            fontsize = self.config.legend_size // 2  # 字体缩小一倍

        h = np.sqrt(3) / 2  # 等边三角形高度
        tick_values = [0, 0.25, 0.5, 0.75, 1.0]
        grid_values = [0.25, 0.5, 0.75]

        # 直接使用 mapper 预生成的 16 个小三角形，确保颜色与地图一致
        triangles = [tri["verts"] for tri in self.mapper.triangles]
        colors = [tri["color"] for tri in self.mapper.triangles]
        collection = PolyCollection(triangles, facecolors=colors,
                                    edgecolors='black', linewidths=0.4,
                                    antialiaseds=True)
        ax.add_collection(collection)

        # === 绘制格线 (在边框之前绘制) ===
        if show_grid:
            grid_color = '#666666'
            grid_lw = 0.4
            grid_alpha = 0.6

            for t in grid_values:
                # 平行于底边的格线 (固定 w3 = t)
                x1 = 0.5 * t  # 左边上的点
                y1 = h * t
                x2 = 1 - 0.5 * t  # 右边上的点
                y2 = h * t
                ax.plot([x1, x2], [y1, y2], color=grid_color, lw=grid_lw,
                       alpha=grid_alpha, zorder=5)

                # 平行于左边的格线 (固定 w2 = t)
                x1 = t  # 底边上的点
                y1 = 0
                x2 = 0.5 + 0.5 * t  # 右边上的点
                y2 = h * (1 - t)
                ax.plot([x1, x2], [y1, y2], color=grid_color, lw=grid_lw,
                       alpha=grid_alpha, zorder=5)

                # 平行于右边的格线 (固定 w1 = t)
                x1 = 1 - t  # 底边上的点
                y1 = 0
                x2 = 0.5 - 0.5 * t  # 左边上的点
                y2 = h * (1 - t)
                ax.plot([x1, x2], [y1, y2], color=grid_color, lw=grid_lw,
                       alpha=grid_alpha, zorder=5)

        # 绘制三角形边框
        outline = np.array([[0, 0], [1, 0], [0.5, h], [0, 0]])
        ax.plot(outline[:, 0], outline[:, 1], color='black',
                linewidth=0.8, solid_capstyle='round', zorder=10)

        # 刻度值 (不加粗)
        tick_len = 0.03
        tick_style = {'fontsize': fontsize - 1, 'color': 'black'}  # 不加粗

        if show_ticks:
            # === 底边刻度 (左下 -> 右下, 对应 labels[0] 的变量) ===
            for t in tick_values:
                x = t
                y = 0
                # 刻度线向下 (不加粗)
                ax.plot([x, x], [y, y - tick_len], 'k-', lw=0.6, zorder=10)
                # 刻度标签
                ax.text(x, y - tick_len - 0.02, f'{1 - t:.1f}',
                       ha='center', va='top', **tick_style)

            # === 左边刻度 (左下 -> 顶点, 对应 labels[2] 的变量) ===
            # 跳过 t=0，避免在左下角重复“0”
            for t in tick_values[1:]:
                # 从左下角(0,0)到顶点(0.5, h)的参数化
                x = 0.5 * t
                y = h * t
                # 刻度线向左 (不加粗)
                dx = -tick_len * np.cos(np.pi/6)
                dy = -tick_len * np.sin(np.pi/6)
                ax.plot([x, x + dx], [y, y + dy], 'k-', lw=0.6, zorder=10)
                # 刻度标签
                ax.text(x + dx * 1.8, y + dy * 1.8, f'{t:.1f}' if t > 0 else '0',
                       ha='right', va='center', **tick_style)

            # === 右边刻度 (顶点 -> 右下, 对应 labels[1] 的变量) ===
            # 跳过 t=0，避免在右下角重复“0”
            for t in tick_values[1:]:
                # 从顶点(0.5, h)到右下角(1, 0)的参数化
                x = 0.5 + 0.5 * t
                y = h * (1 - t)
                # 刻度线向右 (不加粗)
                dx = tick_len * np.cos(np.pi/6)
                dy = -tick_len * np.sin(np.pi/6)
                ax.plot([x, x + dx], [y, y + dy], 'k-', lw=0.6, zorder=10)
                # 刻度标签
                ax.text(x + dx * 1.8, y + dy * 1.8, f'{t:.1f}' if t > 0 else '0',
                       ha='left', va='center', **tick_style)

        # === 标签和箭头 (不加粗，箭头在刻度外侧) ===
        label_style = {'fontsize': fontsize, 'color': 'black'}  # 移除 fontweight='bold'
        arrow_lw = 0.6  # 箭头线宽，不加粗

        # 底边标签和箭头 (labels[0]) - 箭头在刻度更外侧
        arrow_y = -0.12  # 在刻度标签外侧
        ax.annotate('', xy=(0.18, arrow_y), xytext=(0.82, arrow_y),
                   arrowprops=dict(arrowstyle='->', color='black', lw=arrow_lw))
        ax.text(0.5, -0.16, labels[0], ha='center', va='top', **label_style)

        # 左边标签和箭头 (labels[2]) - 从底部向顶部，箭头在刻度更外侧
        # 箭头平行于左边，但在刻度标签外侧
        arrow_start = (-0.12, -0.04)
        arrow_end = (0.10, 0.34)
        ax.annotate('', xy=arrow_end, xytext=arrow_start,
                   arrowprops=dict(arrowstyle='->', color='black', lw=arrow_lw))
        # 标签放在左边外侧，旋转60度
        ax.text(-0.18, h/2 - 0.08, labels[2], ha='right', va='center',
               rotation=60, **label_style)

        # 右边标签和箭头 (labels[1]) - 从顶部向底部，箭头在刻度更外侧
        # 箭头平行于右边，但在刻度标签外侧
        arrow_start = (0.90, 0.34)
        arrow_end = (1.12, -0.04)
        ax.annotate('', xy=arrow_end, xytext=arrow_start,
                   arrowprops=dict(arrowstyle='->', color='black', lw=arrow_lw))
        # 标签放在右边外侧，旋转-60度
        ax.text(1.18, h/2 - 0.08, labels[1], ha='left', va='center',
               rotation=-60, **label_style)

        # 标题 (不加粗)
        if title:
            ax.text(0.5, h + 0.10, title, ha='center', va='bottom',
                    fontsize=fontsize, color='black')  # 移除 fontweight='bold'

        # 设置显示范围
        ax.set_xlim(-0.38, 1.38)
        ax.set_ylim(-0.24, h + 0.15)
        ax.set_aspect('equal')
        ax.axis('off')


# ==================== 地图数据加载 ====================

COUNTRY_NAME_ALIASES: Dict[str, str] = {
    # Common name mismatches between project CSV and Natural Earth fields.
    "Brunei Darussalam": "Brunei",
    "Democratic People's Republic of Korea": "North Korea",
    "Kyrgyz Republic": "Kyrgyzstan",
    "Lao People's Democratic Republic": "Laos",
    "Republic of Congo": "Republic of the Congo",
    "Republic of Fiji": "Fiji",
    "Republic of San Marino": "San Marino",
    "Republic of the Marshall Islands": "Marshall Islands",
    "Russian Federation": "Russia",
    "State of Palestine": "Palestine",
    "Syrian Arab Republic": "Syria",
    "Türkiye": "Turkey",
    "United States": "United States of America",
    "Vatican City (Holy See)": "Vatican",
}


def _expand_country_data_aliases(
    country_data: Dict[str, Tuple[float, float, float]],
    aliases: Optional[Dict[str, str]] = None,
) -> Tuple[Dict[str, Tuple[float, float, float]], Dict[str, str]]:
    """Add Natural Earth-compatible alias keys for country matching.

    Returns:
        (expanded_country_data, alias_to_source_key)
    """
    if not country_data:
        return country_data, {}

    if aliases is None:
        aliases = COUNTRY_NAME_ALIASES

    expanded = dict(country_data)
    alias_to_source: Dict[str, str] = {}
    for source, alias in aliases.items():
        if source in country_data and alias and alias not in expanded:
            expanded[alias] = country_data[source]
            alias_to_source[alias] = source

    return expanded, alias_to_source


def _safe_read_geojson(path: str) -> 'gpd.GeoDataFrame':
    """Read GeoJSON without relying on geopandas.read_file (Fiona backend)."""
    if not HAS_GEOPANDAS:
        raise ImportError("需要安装geopandas: pip install geopandas")

    with open(path, "r", encoding="utf-8") as f:
        obj = json.load(f)

    features = obj.get("features", [])
    gdf = gpd.GeoDataFrame.from_features(features)
    if gdf.crs is None:
        gdf = gdf.set_crs("EPSG:4326")
    return gdf


def get_natural_earth_countries(resolution: str = '50m') -> 'gpd.GeoDataFrame':
    """获取Natural Earth国家边界数据"""
    if not HAS_GEOPANDAS:
        raise ImportError("需要安装geopandas: pip install geopandas")

    print(f"[INFO] 正在加载 {resolution} 分辨率地图数据...")
    
    # 1. 优先尝试本地数据
    local_files = {
        '110m': 'map_data/ne_110m_admin_0_countries.geojson',
        '50m': 'map_data/ne_50m_admin_0_countries.geojson',
        '10m': 'map_data/ne_10m_admin_0_countries.geojson'
    }
    
    if resolution in local_files and os.path.exists(local_files[resolution]):
        try:
            print(f"[INFO] 使用本地数据: {local_files[resolution]}")
            local_path = local_files[resolution]
            if str(local_path).lower().endswith((".geojson", ".json")):
                world = _safe_read_geojson(local_path)
            else:
                world = gpd.read_file(local_path)
            print(f"[SUCCESS] 本地地图数据加载成功，国家数: {len(world)}")
            return world
        except Exception as e:
            print(f"[WARNING] 本地数据加载失败: {str(e)}")
    
    # 2. 尝试从自然地球官网直接下载
    try:
        print(f"[INFO] 从自然地球官网下载 {resolution} 数据...")
        if resolution == '110m':
            url = "https://naciscdn.org/naturalearth/110m/cultural/ne_110m_admin_0_countries.zip"
        elif resolution == '50m':
            url = "https://naciscdn.org/naturalearth/50m/cultural/ne_50m_admin_0_countries.zip"
        elif resolution == '10m':
            url = "https://naciscdn.org/naturalearth/10m/cultural/ne_10m_admin_0_countries.zip"
        else:
            url = "https://naciscdn.org/naturalearth/110m/cultural/ne_110m_admin_0_countries.zip"
        
        world = gpd.read_file(url)
        print(f"[SUCCESS] 在线地图数据加载成功，国家数: {len(world)}")

        # 保存到本地供下次使用
        try:
            os.makedirs('map_data', exist_ok=True)
            world.to_file(local_files.get(resolution, 'map_data/world.geojson'), driver='GeoJSON')
            print(f"[INFO] 数据已保存到本地: {local_files.get(resolution, 'map_data/world.geojson')}")
        except Exception as save_err:
            print(f"[WARNING] 地图数据保存失败（不影响本次绘图）: {save_err}")

        return world
    except Exception as e:
        print(f"[WARNING] 在线数据下载失败: {str(e)}")
    
    # 3. 最后尝试创建简化地图
    print("[INFO] 使用简化地图数据...")
    return create_simple_world_map()

def create_simple_world_map() -> 'gpd.GeoDataFrame':
    """创建简化的世界地图数据（当无法加载在线数据时使用）"""
    from shapely.geometry import Polygon
    
    # 创建一些简化的国家多边形（仅用于演示）
    simple_countries = {
        'China': Polygon([(70, 10), (140, 10), (140, 55), (70, 55), (70, 10)]),
        'United States': Polygon([(-130, 25), (-65, 25), (-65, 50), (-130, 50), (-130, 25)]),
        'Brazil': Polygon([(-75, -35), (-35, -35), (-35, 5), (-75, 5), (-75, -35)]),
        'Russia': Polygon([(20, 40), (180, 40), (180, 80), (20, 80), (20, 40)]),
        'India': Polygon([(68, 5), (98, 5), (98, 35), (68, 35), (68, 5)]),
        'Australia': Polygon([(110, -45), (155, -45), (155, -10), (110, -10), (110, -45)]),
        'Germany': Polygon([(5, 47), (15, 47), (15, 55), (5, 55), (5, 47)]),
        'Nigeria': Polygon([(2, 4), (15, 4), (15, 14), (2, 14), (2, 4)]),
        'Japan': Polygon([(129, 30), (146, 30), (146, 46), (129, 46), (129, 30)]),
        'South Africa': Polygon([(16, -35), (33, -35), (33, -22), (16, -22), (16, -35)])
    }
    
    # 创建GeoDataFrame
    geometries = []
    names = []
    for name, geom in simple_countries.items():
        geometries.append(geom)
        names.append(name)
    
    # 创建一个包含所有其他国家的矩形（代表世界其他地区）
    world_rect = Polygon([(-180, -90), (180, -90), (180, 90), (-180, 90), (-180, -90)])
    geometries.append(world_rect)
    names.append('Other')
    
    gdf = gpd.GeoDataFrame({'name': names, 'geometry': geometries})
    gdf.crs = 'EPSG:4326'  # WGS84坐标系
    
    print(f"[INFO] 简化地图创建完成，包含 {len(gdf)} 个区域")
    return gdf


def geometry_to_patches(geom, facecolor, edgecolor='#333333', linewidth=0.3,
                        alpha=1.0) -> List[MplPolygon]:
    """将shapely几何体转换为matplotlib patches"""
    patches = []

    if geom is None or geom.is_empty:
        return patches

    def process_polygon(poly):
        exterior = np.array(poly.exterior.coords)
        patch = MplPolygon(
            exterior, closed=True, facecolor=facecolor, edgecolor=edgecolor,
            linewidth=linewidth, alpha=alpha, antialiased=True,
            joinstyle='round', capstyle='round',
        )
        return patch

    if geom.geom_type == 'Polygon':
        patches.append(process_polygon(geom))
    elif geom.geom_type == 'MultiPolygon':
        for poly in geom.geoms:
            patches.append(process_polygon(poly))

    return patches


# ==================== 经纬度图框 ====================

def _add_graticules(ax: plt.Axes, extent: Optional[Tuple] = None):
    """添加经纬网格线"""
    config = get_config()
    color = config.grid_color
    alpha = config.grid_alpha
    linewidth = 0.3

    if extent:
        lon_min, lon_max, lat_min, lat_max = extent
    else:
        lon_min, lon_max, lat_min, lat_max = -180, 180, -60, 85

    for lon in range(-180, 181, 30):
        if lon_min <= lon <= lon_max:
            ax.axvline(lon, color=color, alpha=alpha, linewidth=linewidth, zorder=0)

    for lat in range(-60, 91, 30):
        if lat_min <= lat <= lat_max:
            ax.axhline(lat, color=color, alpha=alpha, linewidth=linewidth, zorder=0)

    ax.axhline(0, color='#aaaaaa', alpha=0.5, linewidth=0.5, linestyle='--', zorder=0)
    ax.axvline(0, color='#aaaaaa', alpha=0.5, linewidth=0.5, linestyle='--', zorder=0)


def _add_coordinate_frame(ax: plt.Axes, extent: Optional[Tuple] = None,
                          lon_interval: int = 30, lat_interval: int = 30,
                          show_axis_labels: bool = False):
    """添加经纬度坐标图框（不显示刻度线和刻度值，仅保留边框）"""
    config = get_config()

    if extent:
        lon_min, lon_max, lat_min, lat_max = extent
    else:
        lon_min, lon_max, lat_min, lat_max = -180, 180, -60, 85

    ax.axis('on')
    ax.set_xlim(lon_min, lon_max)
    ax.set_ylim(lat_min, lat_max)

    for spine in ax.spines.values():
        spine.set_color(config.frame_color)
        spine.set_linewidth(0.8)

    # 不显示刻度线和刻度值
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_xticklabels([])
    ax.set_yticklabels([])

    # 不显示坐标轴标签
    ax.set_xlabel("")
    ax.set_ylabel("")


# ==================== 主绑图函数 ====================

def create_country_ternary_map(
    country_data: Dict[str, Tuple[float, float, float]],
    ax: Optional[plt.Axes] = None,
    mapper: Optional[TernaryColorMapper] = None,
    world_gdf: Optional['gpd.GeoDataFrame'] = None,
    country_column: str = 'iso_a3',
    resolution: str = '50m',
    add_legend: bool = True,
    legend_labels: Tuple[str, str, str] = ('Var1', 'Var2', 'Var3'),
    legend_position: Tuple[float, float, float, float] = (0.02, 0.02, 0.14, 0.22),
    legend_title: Optional[str] = None,
    title: Optional[str] = None,
    edgecolor: Optional[str] = None,
    linewidth: float = 0.25,
    cluster_info: Optional[Dict[str, Dict[str, str]]] = None,
    cluster_edge_lw: float = 0.7,
    add_cluster_dots: bool = False,
    cluster_dot_size: float = 8.0,
    cluster_dot_alpha: float = 0.9,
    cluster_dot_color_mode: str = "fill",  # "fill" | "cluster"
    missing_color: str = '#e8e8e8',
    ocean_color: Optional[str] = None,
    figsize: Optional[Tuple[float, float]] = None,
    extent: Optional[Tuple[float, float, float, float]] = None,
    add_graticules: bool = True,
    add_coordinate_frame: bool = True,
    normalize_data: bool = True,
    show_title: bool = False,
    show_source_text: bool = False,
) -> Tuple[plt.Figure, plt.Axes]:
    """创建高精度国家边界三元地图"""
    if not HAS_GEOPANDAS:
        raise ImportError("需要安装geopandas: pip install geopandas")

    config = get_config()
    config.apply()

    if mapper is None:
        mapper = TernaryColorMapper()
    if edgecolor is None:
        edgecolor = config.border_color
    if ocean_color is None:
        ocean_color = config.ocean_color
    if figsize is None:
        figsize = config.figsize

    # 数据归一化
    if normalize_data and country_data:
        all_v1 = [v[0] for v in country_data.values()]
        all_v2 = [v[1] for v in country_data.values()]
        all_v3 = [v[2] for v in country_data.values()]

        def norm(arr):
            mn, mx = min(arr), max(arr)
            if mx - mn == 0:
                return [0.5] * len(arr)
            return [(x - mn) / (mx - mn) for x in arr]

        norm_v1 = norm(all_v1)
        norm_v2 = norm(all_v2)
        norm_v3 = norm(all_v3)

        normalized_data = {}
        for i, code in enumerate(country_data.keys()):
            normalized_data[code] = (norm_v1[i], norm_v2[i], norm_v3[i])
        country_data = normalized_data

    original_country_keys = set(country_data.keys())
    country_data, alias_to_source = _expand_country_data_aliases(country_data)

    # 加载世界地图
    if world_gdf is None:
        print(f"正在加载 {resolution} 分辨率地图数据...")
        world_gdf = get_natural_earth_countries(resolution)
        if hasattr(world_gdf, "columns") and "TYPE" in world_gdf.columns:
            n_sovereign = int((world_gdf["TYPE"] == "Sovereign country").sum())
            n_dependency = int((world_gdf["TYPE"] == "Dependency").sum())
            print(f"加载完成，共 {len(world_gdf)} 个区域（含 {n_sovereign} 主权国家，{n_dependency} 属地/依赖地等）")
        else:
            print(f"加载完成，共 {len(world_gdf)} 个区域")

    # 创建图形
    if ax is None:
        fig, ax = plt.subplots(figsize=figsize, facecolor='white')
    else:
        fig = ax.figure

    if ocean_color != "none":
            ax.set_facecolor(ocean_color)

    if add_graticules:
        _add_graticules(ax, extent)

    matched_feature_count = 0
    matched_source_keys: set = set()
    cluster_dot_points: List[Tuple[float, float, str]] = []

    for idx, row in world_gdf.iterrows():
        geom = row.geometry
        if geom is None or geom.is_empty:
            continue

        country_code = None
        color = missing_color
        feature_edgecolor = edgecolor
        feature_linewidth = linewidth

        for col in [country_column, 'iso_a3', 'ISO_A3', 'ADM0_A3', 'SOV_A3']:
            if col in row.index:
                code = row[col]
                if code and code != '-99' and code in country_data:
                    country_code = code
                    v1, v2, v3 = country_data[code]
                    color = mapper.map_single(v1, v2, v3)
                    matched_feature_count += 1
                    source_key = alias_to_source.get(code, code)
                    matched_source_keys.add(source_key)
                    if cluster_info and cluster_edge_lw > 0 and source_key in cluster_info:
                        feature_edgecolor = cluster_info[source_key].get("color", feature_edgecolor)
                        feature_linewidth = max(feature_linewidth, cluster_edge_lw)
                        if add_cluster_dots:
                            try:
                                pt = geom.representative_point()
                                if cluster_dot_color_mode == "cluster":
                                    dot_c = cluster_info[source_key].get("color", "#333333")
                                else:
                                    dot_c = color
                                cluster_dot_points.append((float(pt.x), float(pt.y), dot_c))
                            except Exception:
                                pass
                    break

        if country_code is None:
            for col in ['name', 'NAME', 'ADMIN', 'NAME_EN', 'NAME_LONG', 'FORMAL_EN', 'NAME_CIAWF', 'NAME_SORT', 'SUBUNIT', 'BRK_NAME', 'NAME_TR']:
                if col in row.index:
                    name = row[col]
                    if name and name in country_data:
                        v1, v2, v3 = country_data[name]
                        color = mapper.map_single(v1, v2, v3)
                        matched_feature_count += 1
                        source_key = alias_to_source.get(name, name)
                        matched_source_keys.add(source_key)
                        if cluster_info and cluster_edge_lw > 0 and source_key in cluster_info:
                            feature_edgecolor = cluster_info[source_key].get("color", feature_edgecolor)
                            feature_linewidth = max(feature_linewidth, cluster_edge_lw)
                            if add_cluster_dots:
                                try:
                                    pt = geom.representative_point()
                                    if cluster_dot_color_mode == "cluster":
                                        dot_c = cluster_info[source_key].get("color", "#333333")
                                    else:
                                        dot_c = color
                                    cluster_dot_points.append((float(pt.x), float(pt.y), dot_c))
                                except Exception:
                                    pass
                        break

        patches = geometry_to_patches(geom, facecolor=color, edgecolor=feature_edgecolor,
                                       linewidth=feature_linewidth)
        for patch in patches:
            ax.add_patch(patch)

    print(f"匹配了 {len(matched_source_keys)} 个国家/地区的数据（渲染到 {matched_feature_count} 个地图区域）")
    unmatched = sorted(original_country_keys - matched_source_keys)
    if unmatched:
        preview = ', '.join(unmatched[:20])
        suffix = ' ...' if len(unmatched) > 20 else ''
        print(f"[WARNING] 未匹配到的国家/地区({len(unmatched)}): {preview}{suffix}")

    if extent:
        ax.set_xlim(extent[0], extent[1])
        ax.set_ylim(extent[2], extent[3])
    else:
        ax.set_xlim(-180, 180)
        ax.set_ylim(-60, 85)

    ax.set_aspect('equal')

    if add_coordinate_frame:
        _add_coordinate_frame(ax, extent)
    else:
        ax.axis('off')

    if add_cluster_dots and cluster_dot_points:
        xs = [p[0] for p in cluster_dot_points]
        ys = [p[1] for p in cluster_dot_points]
        cs = [p[2] for p in cluster_dot_points]
        ax.scatter(
            xs,
            ys,
            s=float(cluster_dot_size),
            c=cs,
            alpha=float(cluster_dot_alpha),
            edgecolors="white",
            linewidths=0.35,
            zorder=8,
        )

    if show_title and title:
        ax.set_title(title, fontsize=config.title_size, fontweight='normal', pad=15, color='#222222')

    if add_legend:
        # 使用 inset_axes 将图例放置在地图框内左下角
        ax_legend = ax.inset_axes([0.02, 0.03, 0.18, 0.28])  # [x, y, width, height] 相对于主轴
        legend = ProfessionalTernaryLegend(mapper, resolution=80)
        legend.plot(ax_legend, labels=legend_labels, title=legend_title, discrete=False, show_grid=True, show_ticks=True)

    if show_source_text:
        ax.text(
            0.99,
            0.01,
            'Data: Natural Earth | Ternary RGB Map',
            transform=ax.transAxes,
            fontsize=7,
            ha='right',
            va='bottom',
            color='#888888',
            style='italic',
            alpha=0.7,
        )

    plt.tight_layout()
    return fig, ax


# ==================== 聚类可视化面板（散点与区域分布） ====================

def build_cluster_info(clustered_country_df: 'pd.DataFrame') -> Dict[str, Dict[str, str]]:
    """将聚类结果 DataFrame 转为绘图时用于查找的字典。"""
    info: Dict[str, Dict[str, str]] = {}
    for _, row in clustered_country_df.iterrows():
        key = str(row["Country"])
        info[key] = {
            "id": str(row.get("Cluster_ID", "")),
            "name": str(row.get("Cluster_Name", "")),
            "color": str(row.get("Cluster_Color", "#333333")),
        }
    return info


def add_cluster_ternary_scatter(
    ax: plt.Axes,
    mapper: 'TernaryColorMapper',
    clustered_country_df: 'pd.DataFrame',
    title: str = "国家三元散点（按聚类）",
    show_cluster_labels: bool = True,
):
    """在给定轴上绘制三元背景 + 按聚类着色的国家散点。"""
    legend = ProfessionalTernaryLegend(mapper, resolution=80)
    legend.plot(
        ax,
        labels=("风险 (R)", "意识 (A)", "行动 (Ac)"),
        title=None,
        show_ticks=False,
        show_grid=False,
        discrete=True,
    )

    groups = clustered_country_df.groupby(["Cluster_ID", "Cluster_Name", "Cluster_Color"], sort=True)
    for (_, cname, ccolor), g in groups:
        ax.scatter(
            g["Ternary_X"],
            g["Ternary_Y"],
            s=9,
            c=ccolor,
            alpha=0.9,
            edgecolors="white",
            linewidths=0.4,
            zorder=20,
        )

        if show_cluster_labels and len(g) >= 3:
            cx = float(g["Ternary_X"].mean())
            cy = float(g["Ternary_Y"].mean())
            ax.text(
                cx,
                cy,
                f"{cname}",
                fontsize=7,
                ha="center",
                va="center",
                color="#1a1a1a",
                bbox=dict(boxstyle="round,pad=0.18", facecolor="white", alpha=0.75, linewidth=0),
                zorder=30,
            )

    ax.set_title(title, fontsize=8, pad=2)


def plot_cluster_distribution_by_region(
    ax: plt.Axes,
    clustered_country_df: 'pd.DataFrame',
    region_col: str = "Metadata_Region",
    mapping_csv: Optional[str] = None,
    as_share: bool = True,
    title: str = "各区域聚类种群分布（堆叠柱状图）",
):
    """按区域绘制聚类种群分布的堆叠柱状图。"""
    df = clustered_country_df.copy()
    if region_col not in df.columns:
        df[region_col] = "Unknown"
    df[region_col] = df[region_col].fillna("Unknown")

    if mapping_csv and os.path.exists(mapping_csv):
        mp = pd.read_csv(mapping_csv)
        if "raw_value" in mp.columns and "mapped_value" in mp.columns:
            mapping = dict(zip(mp["raw_value"].astype(str), mp["mapped_value"].astype(str)))
            df[region_col] = df[region_col].astype(str).map(lambda x: mapping.get(x, x))
        # 若模板给出了特定顺序（按出现顺序），则保持
        ordered = []
        for v in mp.get("mapped_value", pd.Series([], dtype=str)).astype(str).tolist():
            if v and v not in ordered:
                ordered.append(v)
    else:
        ordered = []

    # 以地区为 x 轴，聚类为堆叠
    counts = (
        df.groupby([region_col, "Cluster_ID", "Cluster_Name", "Cluster_Color"], sort=False)["Country"]
        .nunique()
        .reset_index(name="n")
    )

    region_totals = counts.groupby(region_col)["n"].sum()
    if ordered:
        regions = [r for r in ordered if r in region_totals.index]
        # 追加未出现在模板顺序里的地区
        for r in region_totals.sort_values(ascending=False).index:
            if r not in regions:
                regions.append(r)
        region_totals = region_totals.reindex(regions)
    else:
        region_totals = region_totals.sort_values(ascending=False)
        regions = list(region_totals.index)

    clusters = (
        df[["Cluster_ID", "Cluster_Name", "Cluster_Color"]]
        .drop_duplicates()
        .sort_values("Cluster_ID")
        .to_records(index=False)
    )

    x = np.arange(len(regions))
    bottom = np.zeros(len(regions), dtype=float)

    for cid, cname, ccolor in clusters:
        v = []
        for r in regions:
            sub = counts[(counts[region_col] == r) & (counts["Cluster_ID"] == cid)]
            v.append(float(sub["n"].iloc[0]) if len(sub) else 0.0)
        v = np.array(v, dtype=float)
        if as_share:
            denom = np.array([float(region_totals[r]) for r in regions], dtype=float)
            denom = np.where(denom <= 0, 1.0, denom)
            v = v / denom

        ax.bar(x, v, bottom=bottom, color=ccolor, width=0.26, edgecolor="white", linewidth=0.3, label=str(cname))
        bottom += v

    ax.set_title(title, fontsize=9, pad=6)
    ax.set_xticks(x)
    ax.set_xticklabels(regions, rotation=30, ha="right", fontsize=8)
    ax.set_ylabel("占比" if as_share else "国家数量", fontsize=8)
    ax.grid(True, axis="y", alpha=0.25, linewidth=0.6)
    ax.set_axisbelow(True)

    if as_share:
        ax.set_ylim(0, 1.05)

# ==================== 文件保存 ====================

def save_figure(fig: plt.Figure, filename: str, strict_size: bool = True, **kwargs):
    """保存图片 - 严格按照 Nature 标准尺寸

    参数:
        fig: matplotlib Figure对象
        filename: 输出文件名
        strict_size: 是否严格保持图片尺寸（不使用bbox_inches='tight'）
        **kwargs: 传递给savefig的额外参数
    """
    config = get_config()

    # SVG 保持文本可编辑
    if filename.lower().endswith('.svg'):
        mpl.rcParams['svg.fonttype'] = 'none'

    default_kwargs = {
        'dpi': config.dpi,
        'facecolor': 'white',
        'edgecolor': 'none',
        'transparent': False,
    }

    # 严格尺寸模式：不裁剪，保持精确尺寸
    if strict_size:
        default_kwargs['bbox_inches'] = None  # 不自动裁剪
        default_kwargs['pad_inches'] = 0
    else:
        default_kwargs['bbox_inches'] = 'tight'
        default_kwargs['pad_inches'] = 0.02

    default_kwargs.update(kwargs)

    fig.savefig(filename, **default_kwargs)

    # 输出实际尺寸信息
    w, h = fig.get_size_inches()
    dpi = default_kwargs['dpi']
    print(f"已保存: {filename}")
    print(f"  尺寸: {w:.2f}\" x {h:.2f}\" ({w*25.4:.1f}mm x {h*25.4:.1f}mm)")
    print(f"  分辨率: {dpi} DPI, 像素: {int(w*dpi)} x {int(h*dpi)}")


def save_svg_editable(fig: plt.Figure, filename: str, strict_size: bool = True, **kwargs):
    """保存为字体可编辑的SVG格式

    参数:
        fig: matplotlib Figure对象
        filename: 输出文件名（应以.svg结尾）
        strict_size: 是否严格保持图片尺寸

    注意：svg.fonttype='none' 必须在创建图形前设置才能完全生效。
    本函数会再次设置以确保保存时正确。
    """
    # 强制设置SVG文字为可编辑
    mpl.rcParams['svg.fonttype'] = 'none'
    mpl.rcParams['pdf.fonttype'] = 42

    # 传递metadata确保正确编码
    if 'metadata' not in kwargs:
        kwargs['metadata'] = {'Creator': 'Ternary Map Visualization'}

    save_figure(fig, filename, strict_size=strict_size, **kwargs)


def save_png(fig: plt.Figure, filename: str, strict_size: bool = True, dpi: int = None, **kwargs):
    """保存为PNG格式

    参数:
        fig: matplotlib Figure对象
        filename: 输出文件名
        strict_size: 是否严格保持图片尺寸
        dpi: 分辨率（默认使用config中的设置）
    """
    if dpi:
        kwargs['dpi'] = dpi
    save_figure(fig, filename, strict_size=strict_size, **kwargs)


def save_data_to_csv(country_data: Dict[str, Tuple[float, float, float]],
                     filename: str, var_names: Tuple[str, str, str] = ('Var1', 'Var2', 'Var3')):
    """保存国家数据到CSV文件"""
    import csv

    with open(filename, 'w', newline='', encoding='utf-8-sig') as f:
        writer = csv.writer(f)
        writer.writerow(['Country_Code', var_names[0], var_names[1], var_names[2]])
        for code, (v1, v2, v3) in sorted(country_data.items()):
            writer.writerow([code, f'{v1:.4f}', f'{v2:.4f}', f'{v3:.4f}'])

    print(f"已保存数据到CSV: {filename}")


def load_data_from_csv(filename: str) -> Dict[str, Tuple[float, float, float]]:
    """从CSV文件加载国家数据"""
    import csv

    data = {}
    with open(filename, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        headers = reader.fieldnames

        if len(headers) < 4:
            raise ValueError("CSV文件需要至少4列：国家代码和3个变量")

        code_col = headers[0]
        var_cols = headers[1:4]

        for row in reader:
            code = row[code_col].strip()
            try:
                v1 = float(row[var_cols[0]])
                v2 = float(row[var_cols[1]])
                v3 = float(row[var_cols[2]])
                data[code] = (v1, v2, v3)
            except (ValueError, KeyError) as e:
                print(f"警告: 跳过无效行 {code}: {e}")

    print(f"从CSV加载了 {len(data)} 个国家的数据")
    return data


# ==================== 辅助函数 ====================

def hex_to_rgb(hex_color: str) -> Tuple[float, float, float]:
    """将十六进制颜色转换为RGB元组"""
    hex_color = hex_color.lstrip('#')
    return tuple(int(hex_color[i:i+2], 16) / 255.0 for i in (0, 2, 4))


def create_custom_mapper(color1: str = '#FFFF00',
                         color2: str = '#1E90FF',
                         color3: str = '#FF007F',
                         white_mix: float = 0.18,
                         gamma: float = 1.0) -> TernaryColorMapper:
    """创建自定义颜色的映射器 - 默认使用参考图的CMY配色"""
    colors = (hex_to_rgb(color1), hex_to_rgb(color2), hex_to_rgb(color3))
    return TernaryColorMapper(colors, white_mix=white_mix, gamma=gamma)


# ==================== 示例数据生成 ====================

def generate_sample_country_data() -> Dict[str, Tuple[float, float, float]]:
    """生成随机示例国家数据"""
    np.random.seed(42)

    countries = [
        'CHN', 'USA', 'RUS', 'CAN', 'BRA', 'AUS', 'IND', 'ARG', 'KAZ', 'DZA',
        'COD', 'SAU', 'MEX', 'IDN', 'SDN', 'LBY', 'IRN', 'MNG', 'PER', 'TCD',
        'NER', 'AGO', 'MLI', 'ZAF', 'COL', 'ETH', 'BOL', 'MRT', 'EGY', 'TZA',
        'NGA', 'VEN', 'PAK', 'NAM', 'MOZ', 'TUR', 'CHL', 'ZMB', 'MMR', 'AFG',
        'SOM', 'CAF', 'UKR', 'MDG', 'BWA', 'KEN', 'FRA', 'YEM', 'THA', 'ESP',
        'TKM', 'CMR', 'PNG', 'SWE', 'UZB', 'MAR', 'IRQ', 'PRY', 'ZWE', 'JPN',
        'DEU', 'POL', 'FIN', 'VNM', 'MYS', 'NOR', 'CIV', 'PHL', 'ECU', 'GBR',
        'GHA', 'ROU', 'LAO', 'UGA', 'GUY', 'OMN', 'BLR', 'KGZ', 'SEN', 'SYR',
        'KHM', 'URY', 'SUR', 'TUN', 'NPL', 'BGD', 'TJK', 'GRC', 'NIC', 'PRK',
        'KOR', 'HUN', 'PRT', 'JOR', 'AZE', 'AUT', 'ARE', 'CZE', 'SRB', 'IRL',
        'GEO', 'LKA', 'LTU', 'LVA', 'HRV', 'SVK', 'EST', 'DNK', 'CHE', 'NLD',
        'BEL', 'TWN', 'ARM', 'ALB', 'ISR', 'SVN', 'MKD', 'RWA', 'BDI', 'NZL',
        'ITA', 'GNB', 'SLE', 'TGO', 'BEN', 'LBR', 'GIN', 'BFA', 'GMB', 'GNQ',
    ]

    data = {}
    for code in countries:
        v1 = np.random.uniform(0.1, 1.0)
        v2 = np.random.uniform(0.1, 1.0)
        v3 = np.random.uniform(0.1, 1.0)
        data[code] = (v1, v2, v3)

    return data

def generate_actual_country_data(csv_file='all_l_dimensions.csv'):
    """
    从实际CSV文件生成国家三元图数据
    
    参数:
        csv_file: CSV文件路径
        
    返回:
        dict: 格式化的国家数据字典
    """
    print("[INFO] 开始加载实际数据...")
    
    # 加载原始数据
    df = load_actual_data(csv_file)
    if df is None:
        print("❌ 数据加载失败，使用示例数据")
        return generate_sample_country_data()
    
    # 按国家聚合数据
    country_agg = aggregate_data_by_country(df)
    if country_agg is None or len(country_agg) == 0:
        print("❌ 数据聚合失败，使用示例数据")
        return generate_sample_country_data()
    
    # 转换为三元图格式
    ternary_data = prepare_data_for_ternary_map(country_agg, 'country')
    
    print(f"[SUCCESS] 实际数据处理完成！")
    print(f"   - 处理国家数: {len(ternary_data)}")
    print(f"   - 数据源: {csv_file}")
    
    # 显示一些统计信息
    r_values = [data[0] for data in ternary_data.values()]  # 修改为元组索引
    a_values = [data[1] for data in ternary_data.values()]
    ac_values = [data[2] for data in ternary_data.values()]
    
    print(f"   - R得分范围: {min(r_values):.3f} - {max(r_values):.3f}")
    print(f"   - A得分范围: {min(a_values):.3f} - {max(a_values):.3f}")
    print(f"   - Ac得分范围: {min(ac_values):.3f} - {max(ac_values):.3f}")
    
    return ternary_data

def generate_actual_landform_data(csv_file='all_l_dimensions.csv'):
    """
    从实际CSV文件生成地貌三元图数据
    
    参数:
        csv_file: CSV文件路径
        
    返回:
        dict: 格式化的地貌数据字典
    """
    print("[INFO] 开始加载地貌数据...")
    
    # 加载原始数据
    df = load_actual_data(csv_file)
    if df is None:
        print("❌ 数据加载失败")
        return {}
    
    # 按地貌类型聚合数据
    landform_agg = aggregate_data_by_landform(df)
    if landform_agg is None or len(landform_agg) == 0:
        print("❌ 地貌数据聚合失败")
        return {}
    
    # 转换为三元图格式
    ternary_data = prepare_data_for_ternary_map(landform_agg, 'landform')
    
    print(f"[SUCCESS] 地貌数据处理完成！")
    print(f"   - 地貌类型数: {len(ternary_data)}")
    print(f"   - 数据源: {csv_file}")
    
    # 显示地貌类型和得分
    print("   - 地貌类型及得分:")
    for landform, data in ternary_data.items():
        print(f"     {landform}: R={data[0]:.3f}, A={data[1]:.3f}, Ac={data[2]:.3f}")
    
    return ternary_data


def generate_regional_pattern_data() -> Dict[str, Tuple[float, float, float]]:
    """生成具有区域模式的示例数据"""
    if not HAS_GEOPANDAS:
        return generate_sample_country_data()

    try:
        world = get_natural_earth_countries('110m')
    except Exception:
        return generate_sample_country_data()

    data = {}

    for idx, row in world.iterrows():
        code = row.get('iso_a3', '')
        if not code or code == '-99':
            continue

        try:
            centroid = row.geometry.centroid
            lat = centroid.y
            lon = centroid.x
        except Exception:
            continue

        v1 = 0.5 + lat / 120
        v2 = 0.7 if 60 <= lon <= 150 else (0.5 if -10 <= lon <= 60 else 0.3)
        v3 = 0.5 - lat / 120

        np.random.seed(hash(code) % 2**31)
        v1 += np.random.uniform(-0.1, 0.1)
        v2 += np.random.uniform(-0.1, 0.1)
        v3 += np.random.uniform(-0.1, 0.1)

        data[code] = (np.clip(v1, 0.05, 1), np.clip(v2, 0.05, 1), np.clip(v3, 0.05, 1))

    return data


# ==================== 交互式模式 ====================

def interactive_input_data() -> Tuple[Dict[str, Tuple[float, float, float]], Tuple[str, str, str]]:
    """交互式输入用户数据"""
    print("\n" + "=" * 60)
    print("交互式数据输入模式")
    print("=" * 60)

    # 输入变量名称
    print("\n请输入三个变量的名称（用于图例显示）：")
    var1_name = input("变量1名称 [默认: 指标A]: ").strip() or "指标A"
    var2_name = input("变量2名称 [默认: 指标B]: ").strip() or "指标B"
    var3_name = input("变量3名称 [默认: 指标C]: ").strip() or "指标C"

    var_names = (var1_name, var2_name, var3_name)

    print("\n数据输入方式:")
    print("1. 手动逐个输入国家数据")
    print("2. 从CSV文件导入")

    input_choice = input("\n请选择 [1/2，默认1]: ").strip() or "1"

    if input_choice == "2":
        # 从CSV导入
        csv_path = input("请输入CSV文件路径: ").strip()
        if os.path.exists(csv_path):
            data = load_data_from_csv(csv_path)
            return data, var_names
        else:
            print(f"文件不存在: {csv_path}")
            print("切换到手动输入模式...")

    # 手动输入
    print("\n手动输入国家数据")
    print("格式: 国家代码(ISO 3166-1 alpha-3) 变量1值 变量2值 变量3值")
    print("示例: CHN 0.8 0.5 0.3")
    print("输入 'done' 完成输入\n")

    print("常用国家代码参考:")
    print("CHN-中国, USA-美国, RUS-俄罗斯, JPN-日本, DEU-德国")
    print("GBR-英国, FRA-法国, BRA-巴西, IND-印度, AUS-澳大利亚\n")

    data = {}
    while True:
        line = input("输入数据 (或 'done' 完成): ").strip()
        if line.lower() == 'done':
            break
        if not line:
            continue

        parts = line.split()
        if len(parts) < 4:
            print("格式错误，请输入: 国家代码 值1 值2 值3")
            continue

        try:
            code = parts[0].upper()
            v1 = float(parts[1])
            v2 = float(parts[2])
            v3 = float(parts[3])
            data[code] = (v1, v2, v3)
            print(f"  已添加: {code} = ({v1}, {v2}, {v3})")
        except ValueError:
            print("数值格式错误，请输入有效的数字")

    print(f"\n共输入 {len(data)} 个国家的数据")
    return data, var_names


def run_simulation_mode():
    """模式1: 生成模拟数据并保存"""
    print("\n" + "=" * 60)
    print("模式1: 模拟数据生成")
    print("=" * 60)

    print("\n选择数据类型:")
    print("1. 随机数据")
    print("2. 区域模式数据（北半球/亚洲/南半球趋势）")

    data_choice = input("\n请选择 [1/2，默认2]: ").strip() or "2"

    if data_choice == "1":
        country_data = generate_sample_country_data()
        var_names = ('随机指标A', '随机指标B', '随机指标C')
    else:
        country_data = generate_regional_pattern_data()
        var_names = ('北半球指标', '亚洲指标', '南半球指标')

    print(f"生成了 {len(country_data)} 个国家的数据")

    # 输入输出文件名
    base_name = input("\n输出文件名前缀 [默认: ternary_map]: ").strip() or "ternary_map"
    title = None

    # 生成地图 - 使用 Nature 双栏标准尺寸
    print("\n正在生成地图...")
    fig, ax = create_country_ternary_map(
        country_data=country_data,
        resolution='50m',
        legend_labels=var_names,
        legend_title='三元色彩图例',
        title=title,
        # figsize 不指定，使用 config 中的 Nature 标准尺寸
    )

    # 保存文件
    save_svg_editable(fig, f'{base_name}.svg')
    save_png(fig, f'{base_name}.png')
    save_data_to_csv(country_data, f'{base_name}_data.csv', var_names)

    print("\n生成完成！")
    plt.show()


def run_custom_mode():
    """模式2: 自定义数据输入"""
    country_data, var_names = interactive_input_data()

    if not country_data:
        print("没有输入数据，退出。")
        return

    # 输入输出设置
    base_name = input("\n输出文件名前缀 [默认: custom_map]: ").strip() or "custom_map"
    title = None

    # 生成地图 - 使用 Nature 双栏标准尺寸
    print("\n正在生成地图...")
    fig, ax = create_country_ternary_map(
        country_data=country_data,
        resolution='50m',
        legend_labels=var_names,
        legend_title='三元色彩图例',
        title=title,
        # figsize 不指定，使用 config 中的 Nature 标准尺寸
    )

    # 保存文件
    save_svg_editable(fig, f'{base_name}.svg')
    save_png(fig, f'{base_name}.png')
    save_data_to_csv(country_data, f'{base_name}_data.csv', var_names)

    print("\n生成完成！")
    plt.show()


# ==================== 地貌三元图绘制函数 ====================

def create_landform_ternary_plot(landform_data, output_file='地貌类型三元图.png'):
    """
    创建地貌类型的三元散点图
    
    参数:
        landform_data: 地貌数据字典
        output_file: 输出文件名
    """
    # 应用配置
    config = get_config()
    config.apply()
    
    # 创建图形
    fig, ax = plt.subplots(figsize=get_nature_figsize('double_column'))
    
    # 三元坐标转换函数
    def to_ternary_coords(r, a, ac):
        """将三元坐标转换为二维坐标"""
        # 归一化
        total = r + a + ac
        if total > 0:
            r = r / total
            a = a / total
            ac = ac / total
        else:
            r, a, ac = 1/3, 1/3, 1/3
        
        # 转换为二维坐标（等边三角形）
        x = a + ac * 0.5
        y = ac * np.sqrt(3) / 2
        return x, y
    
    # 绘制三角形边框
    triangle_vertices = [
        (0, 0),  # R顶点
        (1, 0),  # A顶点  
        (0.5, np.sqrt(3)/2)  # Ac顶点
    ]
    
    triangle = plt.Polygon(triangle_vertices, fill=False, edgecolor='black', linewidth=2)
    ax.add_patch(triangle)
    
    # 绘制网格线
    for i in range(1, 10):
        ratio = i / 10
        # 平行于R边的线
        x_line = [ratio, 1 - ratio/2]
        y_line = [0, ratio * np.sqrt(3)/2]
        ax.plot(x_line, y_line, 'gray', alpha=0.3, linewidth=0.5)
        
        # 平行于A边的线
        x_line = [0, 1 - ratio]
        y_line = [ratio * np.sqrt(3)/2, 0]
        ax.plot(x_line, y_line, 'gray', alpha=0.3, linewidth=0.5)
        
        # 平行于Ac边的线
        x_line = [ratio/2, 1 - ratio/2]
        y_line = [ratio * np.sqrt(3)/2, ratio * np.sqrt(3)/2]
        ax.plot(x_line, y_line, 'gray', alpha=0.3, linewidth=0.5)
    
    # 获取颜色映射器
    mapper = TernaryColorMapper()
    
    # 绘制地貌数据点
    for landform_name, data in landform_data.items():
        # data现在是元组格式 (R, A, Ac)
        r_val, a_val, ac_val = data
        x, y = to_ternary_coords(r_val, a_val, ac_val)
        color = mapper.map_single(r_val, a_val, ac_val)
        
        # 根据记录数量设置点的大小 - 这里使用固定大小，因为元组格式不包含元数据
        size = 200  # 固定大小，适合地貌显示
        
        # 绘制散点
        ax.scatter(x, y, c=[color], s=size, alpha=0.9, 
                  edgecolors='black', linewidth=2, marker='s')
        
        # 添加地貌标签
        # 截断过长的地貌名称
        display_name = landform_name.replace(' & ', '\n')  # 换行显示
        if len(display_name) > 20:
            display_name = display_name[:18] + '...'
            
        ax.annotate(display_name, (x, y), xytext=(5, 5), 
                   textcoords='offset points', fontsize=8, 
                   fontweight='bold', alpha=0.9,
                   bbox=dict(boxstyle='round,pad=0.3', facecolor='white', alpha=0.7))
    
    # 设置顶点标签
    ax.text(0.5, -0.15, '风险 (Risk)', ha='center', fontsize=12, fontweight='bold')
    ax.text(-0.15, np.sqrt(3)/4, '意识 (Awareness)', ha='right', fontsize=12, 
            fontweight='bold', rotation=60)
    ax.text(1.15, np.sqrt(3)/4, '行动 (Action)', ha='left', fontsize=12, 
            fontweight='bold', rotation=-60)
    
    # 设置坐标轴范围
    ax.set_xlim(-0.3, 1.3)
    ax.set_ylim(-0.2, np.sqrt(3)/2 + 0.2)
    ax.set_aspect('equal')
    ax.axis('off')
    
    # 添加标题
    ax.set_title('全球地貌类型风险-意识-行动三元图\n(基于196个国家实际数据)', 
                fontsize=14, fontweight='bold', pad=20)
    
    # 添加说明文本
    info_text = "点的大小代表该地貌类型的样本数量\n颜色反映R-A-Ac三个维度的相对比例"
    ax.text(0.02, 0.98, info_text, transform=ax.transAxes, 
            fontsize=9, verticalalignment='top',
            bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8))
    
    # 保存图形
    plt.tight_layout()
    plt.savefig(output_file, dpi=300, bbox_inches='tight', facecolor='white')
    print(f"[OUTPUT] 地貌三元图已保存: {output_file}")

# ==================== 为每种地貌单独生成三元图的函数 ====================

def create_individual_landform_ternary_plots(csv_file='all_l_dimensions.csv'):
    """
    为每种地貌类型单独生成三元图
    每个地貌显示该地貌在所有国家的R-A-Ac分布
    
    参数:
        csv_file: CSV数据文件路径
        
    返回:
        dict: 生成的文件路径字典
    """
    print("[INFO] 开始为每种地貌单独生成三元图...")
    
    # 加载数据
    try:
        df = pd.read_csv(csv_file)
        print(f"[SUCCESS] 数据加载成功: {len(df)}条记录")
    except Exception as e:
        print(f"[ERROR] 数据加载失败: {e}")
        return {}
    
    # 获取所有地貌类型
    landform_types = df['Sub_Theme'].unique()
    print(f"[INFO] 发现 {len(landform_types)} 种地貌类型")
    
    # 创建输出目录
    import os
    output_dir = '各地貌单独三元图'
    os.makedirs(output_dir, exist_ok=True)
    
    # 存储生成的文件路径
    generated_files = {}
    all_landform_stats = {}
    
    # 为每种地貌生成三元图
    for landform in landform_types:
        print(f"\n[PROCESSING] 正在处理: {landform}")
        
        # 筛选该地貌的数据
        landform_df = df[df['Sub_Theme'] == landform].copy()
        
        if len(landform_df) == 0:
            print(f"[WARNING] {landform} 没有数据，跳过")
            continue
        
        # 生成该地貌的三元图
        output_file = create_single_landform_ternary_plot(
            landform_df, 
            landform, 
            output_dir
        )
        
        if output_file:
            generated_files[landform] = output_file
            
            # 计算统计信息
            stats = {
                'country_count': len(landform_df),
                'avg_r': landform_df['Scores_R_total_score'].mean(),
                'avg_a': landform_df['Scores_A_total_score'].mean(),
                'avg_ac': landform_df['Scores_Ac_total_score'].mean(),
                'avg_gap': landform_df['Scores_action_minus_risk_score'].mean()
            }
            all_landform_stats[landform] = stats
    
    # 生成汇总统计图
    if all_landform_stats:
        summary_file = create_landform_summary_plot(all_landform_stats, output_dir)
        generated_files['汇总统计'] = summary_file
        
        # 保存统计数据
        stats_file = save_landform_statistics(all_landform_stats, output_dir)
        generated_files['统计数据'] = stats_file
    
    print(f"\n[SUCCESS] 所有地貌三元图生成完成！")
    print(f"[INFO] 输出目录: {output_dir}")
    print(f"[INFO] 生成文件数: {len(generated_files)}")
    
    return generated_files

def create_single_landform_ternary_plot(landform_df, landform_name, output_dir):
    """
    为单个地貌类型创建三元图
    
    参数:
        landform_df: 该地貌的所有国家数据 (DataFrame)
        landform_name: 地貌名称 (str)
        output_dir: 输出目录 (str)
        
    返回:
        str: 生成的文件路径
    """
    try:
        # 应用配置
        config = get_config()
        config.apply()
        
        # 创建图形 - 使用单栏尺寸，适合多个小图
        fig, ax = plt.subplots(figsize=get_nature_figsize('single_column'))
        
        # 绘制三角形边框
        h = np.sqrt(3) / 2
        triangle = plt.Polygon([(0, 0), (1, 0), (0.5, h)], fill=False, 
                              edgecolor='black', linewidth=1.2)
        ax.add_patch(triangle)
        
        # 绘制网格线（减少数量，更清晰）
        for i in range(1, 6):  # 5条网格线
            ratio = i / 5
            # 三组平行线
            x_line = [ratio, 1 - ratio/2]
            y_line = [0, ratio * h]
            ax.plot(x_line, y_line, 'gray', alpha=0.2, linewidth=0.3)
            
            x_line = [0, 1 - ratio]
            y_line = [ratio * h, 0]
            ax.plot(x_line, y_line, 'gray', alpha=0.2, linewidth=0.3)
            
            x_line = [ratio/2, 1 - ratio/2]
            y_line = [ratio * h, ratio * h]
            ax.plot(x_line, y_line, 'gray', alpha=0.2, linewidth=0.3)
        
        # 标准化数据到0-1范围
        max_score = 15
        landform_df['R_norm'] = landform_df['Scores_R_total_score'] / max_score
        landform_df['A_norm'] = landform_df['Scores_A_total_score'] / max_score
        landform_df['Ac_norm'] = landform_df['Scores_Ac_total_score'] / max_score
        
        # 获取颜色映射器（使用我们修改的离散配色）
        mapper = TernaryColorMapper()
        
        # 按收入组分类数据点
        income_groups = {'High': [], 'Upper': [], 'Lower': [], 'Low': []}
        
        for _, row in landform_df.iterrows():
            # 计算三元坐标
            x, y = to_ternary_coords(row['R_norm'], row['A_norm'], row['Ac_norm'])
            # 获取离散颜色
            color = mapper.map_single(row['R_norm'], row['A_norm'], row['Ac_norm'])
            
            # 根据收入组分类
            income_str = str(row.get('Metadata_Income_Group', 'Unknown'))
            if 'High' in income_str:
                income_groups['High'].append((x, y, color, row['Country']))
            elif 'Upper' in income_str:
                income_groups['Upper'].append((x, y, color, row['Country']))
            elif 'Lower' in income_str:
                income_groups['Lower'].append((x, y, color, row['Country']))
            else:
                income_groups['Low'].append((x, y, color, row['Country']))
        
        # 按收入组绘制数据点
        sizes = {'High': 50, 'Upper': 40, 'Lower': 30, 'Low': 20}  # 点的大小
        markers = {'High': 'o', 'Upper': 's', 'Lower': '^', 'Low': 'D'}  # 点的形状
        alphas = {'High': 0.9, 'Upper': 0.8, 'Lower': 0.7, 'Low': 0.6}  # 透明度
        
        for group, points in income_groups.items():
            if points:
                x_vals = [p[0] for p in points]
                y_vals = [p[1] for p in points]
                colors = [p[2] for p in points]
                
                ax.scatter(x_vals, y_vals, c=colors, s=sizes[group], 
                          alpha=alphas[group], edgecolors='black', linewidth=0.3,
                          marker=markers[group], label=group)
        
        # 设置顶点标签
        ax.text(0.5, -0.12, '风险 (R)', ha='center', fontsize=9, fontweight='bold')
        ax.text(-0.12, h/2, '意识 (A)', ha='right', fontsize=9, 
                fontweight='bold', rotation=60)
        ax.text(1.12, h/2, '行动 (Ac)', ha='left', fontsize=9, 
                fontweight='bold', rotation=-60)
        
        # 设置坐标轴范围和比例
        ax.set_xlim(-0.1, 1.1)
        ax.set_ylim(-0.05, h + 0.05)
        ax.set_aspect('equal')
        ax.axis('off')  # 隐藏坐标轴
        
        # 添加标题 - 处理长名称
        display_name = landform_name.replace(' & ', '\n')  # 长名称换行
        if len(display_name) > 20:
            display_name = display_name[:18] + '...'
        
        ax.set_title(f'{display_name}\n({len(landform_df)}个国家)', 
                    fontsize=10, fontweight='bold', pad=8)
        
        # 添加简化的图例（如果有数据）
        if any(income_groups.values()):
            ax.legend(loc='upper right', fontsize=6, framealpha=0.8, ncol=2)
        
        # 添加统计信息框
        avg_r = landform_df['Scores_R_total_score'].mean()
        avg_a = landform_df['Scores_A_total_score'].mean()
        avg_ac = landform_df['Scores_Ac_total_score'].mean()
        avg_gap = landform_df['Scores_action_minus_risk_score'].mean()
        
        info_text = f"平均得分:\nR={avg_r:.1f}\nA={avg_a:.1f}\nAc={avg_ac:.1f}\nGap={avg_gap:.1f}"
        ax.text(0.02, 0.98, info_text, transform=ax.transAxes, 
                fontsize=7, verticalalignment='top',
                bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.7))
        
        # 生成安全的文件名
        import os
        safe_name = landform_name.replace(' & ', '_').replace(' ', '_').replace('/', '_')
        output_file = os.path.join(output_dir, f'{safe_name}_三元图.png')
        
        # 保存图形
        plt.tight_layout()
        plt.savefig(output_file, dpi=300, bbox_inches='tight', facecolor='white')
        plt.close()  # 关闭图形，释放内存
        
        print(f"[OK] {landform_name}: {len(landform_df)}个国家 -> 生成成功")
        return output_file
        
    except Exception as e:
        print(f"[ERROR] 生成 {landform_name} 三元图失败: {e}")
        return None


def create_landform_world_maps(csv_file='all_l_dimensions.csv', output_dir='各地貌单独三元图'):
    """
    为每种地貌类型生成国家层面的三元世界地图（PNG + SVG + 数据CSV）
    """
    print("[INFO] 开始生成地貌三元世界地图...")

    df = load_actual_data(csv_file)
    if df is None:
        return {}

    landform_types = df['Sub_Theme'].dropna().unique()
    print(f"[INFO] 发现 {len(landform_types)} 种地貌类型: {', '.join(landform_types)}")

    os.makedirs(output_dir, exist_ok=True)

    generated_files = {}
    all_landform_stats = {}

    for landform in landform_types:
        print(f"\n[PROCESSING] 正在处理: {landform}")
        landform_df = df[df['Sub_Theme'] == landform].copy()
        if landform_df.empty:
            print(f"[WARNING] {landform} 没有数据，跳过")
            continue

        country_agg = aggregate_data_by_country(landform_df)
        if country_agg is None or len(country_agg) == 0:
            print(f"[WARNING] {landform} 聚合后没有可用的国家数据，跳过")
            continue

        country_data = prepare_data_for_ternary_map(country_agg, 'country')
        if not country_data:
            print(f"[WARNING] {landform} 没有有效的三元数据，跳过")
            continue

        title = f'{landform} 风险-意识-行动三元世界地图'
        fig, ax = create_country_ternary_map(
            country_data=country_data,
            resolution='50m',
            legend_labels=('风险 (R)', '意识 (A)', '行动 (Ac)'),
            title=title,
            linewidth=0.4,
            add_coordinate_frame=True,
        )

        safe_name = landform.replace(' & ', '_').replace(' ', '_').replace('/', '_')
        png_file = os.path.join(output_dir, f'{safe_name}_三元世界地图.png')
        svg_file = os.path.join(output_dir, f'{safe_name}_三元世界地图.svg')
        data_file = os.path.join(output_dir, f'{safe_name}_三元世界地图_data.csv')

        save_png(fig, png_file, strict_size=False)
        save_svg_editable(fig, svg_file, strict_size=False)
        save_data_to_csv(country_data, data_file, ('风险 (R)', '意识 (A)', '行动 (Ac)'))
        plt.close(fig)

        generated_files[landform] = {
            'png': png_file,
            'svg': svg_file,
            'data': data_file,
        }

        stats = {
            'country_count': landform_df['Country'].nunique(),
            'avg_r': landform_df['Scores_R_total_score'].mean(),
            'avg_a': landform_df['Scores_A_total_score'].mean(),
            'avg_ac': landform_df['Scores_Ac_total_score'].mean(),
            'avg_gap': landform_df['Scores_action_minus_risk_score'].mean()
        }
        all_landform_stats[landform] = stats

        print(f"[OK] {landform}: {stats['country_count']}个国家 -> PNG/SVG/CSV 已生成")

    if all_landform_stats:
        summary_file = create_landform_summary_plot(all_landform_stats, output_dir)
        stats_file = save_landform_statistics(all_landform_stats, output_dir)
        generated_files['汇总统计'] = {
            'png': summary_file,
            'data': stats_file,
        }

    print(f"\n[SUCCESS] 所有地貌三元世界地图生成完成！")
    print(f"[INFO] 输出目录: {output_dir}")
    print(f"[INFO] 生成文件组数: {len(generated_files)}")

    return generated_files

def to_ternary_coords(r, a, ac):
    """
    将三元坐标转换为二维坐标
    
    参数:
        r, a, ac: 三个维度的值 (0-1范围)
        
    返回:
        tuple: (x, y) 二维坐标
    """
    # 归一化，确保总和为1
    total = r + a + ac
    if total > 0:
        r, a, ac = r/total, a/total, ac/total
    else:
        r, a, ac = 1/3, 1/3, 1/3  # 等边三角形中心
    
    # 转换为等边三角形的二维坐标
    x = a + ac * 0.5
    y = ac * np.sqrt(3) / 2
    return x, y

def create_landform_summary_plot(all_landform_stats, output_dir):
    """
    创建地貌汇总统计图
    
    参数:
        all_landform_stats: 所有地貌的统计信息 (dict)
        output_dir: 输出目录 (str)
        
    返回:
        str: 汇总图文件路径
    """
    try:
        # 应用配置
        config = get_config()
        config.apply()
        
        # 创建双栏图形
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=get_nature_figsize('double_column'))
        
        # 提取数据
        landforms = list(all_landform_stats.keys())
        avg_r = [stats['avg_r'] for stats in all_landform_stats.values()]
        avg_a = [stats['avg_a'] for stats in all_landform_stats.values()]
        avg_ac = [stats['avg_ac'] for stats in all_landform_stats.values()]
        avg_gap = [stats['avg_gap'] for stats in all_landform_stats.values()]
        country_counts = [stats['country_count'] for stats in all_landform_stats.values()]
        
        # 图1: 平均得分对比柱状图
        x = np.arange(len(landforms))
        width = 0.25
        
        bars1 = ax1.bar(x - width, avg_r, width, label='风险 (R)', color='#c44e52', alpha=0.85)
        bars2 = ax1.bar(x, avg_a, width, label='意识 (A)', color='#4c72b0', alpha=0.85)
        bars3 = ax1.bar(x + width, avg_ac, width, label='行动 (Ac)', color='#55a868', alpha=0.85)
        
        ax1.set_xlabel('地貌类型')
        ax1.set_ylabel('平均得分')
        ax1.set_title('各地貌类型平均R-A-Ac得分对比')
        ax1.set_xticks(x)
        
        # 处理x轴标签（长名称换行）
        labels = [name.replace(' & ', '\n')[:15] for name in landforms]
        ax1.set_xticklabels(labels, rotation=45, ha='right', fontsize=8)
        ax1.legend(fontsize=8)
        ax1.grid(True, alpha=0.3)
        
        # 图2: 行动赤字对比
        # 根据赤字程度设置颜色
        colors = []
        for gap in avg_gap:
            if gap < -4:
                colors.append('#c44e52')      # 严重赤字
            elif gap < -2:
                colors.append('#dd8452')      # 中等赤字
            elif gap < 0:
                colors.append('#e0c04f')      # 轻微赤字
            else:
                colors.append('#55a868')      # 无赤字
        
        bars = ax2.bar(x, avg_gap, color=colors, alpha=0.7)
        ax2.set_xlabel('地貌类型')
        ax2.set_ylabel('平均行动赤字 (Ac-R)')
        ax2.set_title('各地貌类型行动赤字对比')
        ax2.set_xticks(x)
        ax2.set_xticklabels(labels, rotation=45, ha='right', fontsize=8)
        ax2.axhline(y=0, color='black', linestyle='-', alpha=0.5)
        ax2.grid(True, alpha=0.3)
        
        # 添加数值标签
        for bar, gap in zip(bars, avg_gap):
            height = bar.get_height()
            ax2.text(bar.get_x() + bar.get_width()/2., 
                    height + 0.1 if height >= 0 else height - 0.3,
                    f'{gap:.1f}', ha='center', 
                    va='bottom' if height >= 0 else 'top', 
                    fontsize=7)
        
        # 调整布局并保存
        plt.tight_layout()
        
        import os
        summary_file = os.path.join(output_dir, '地貌汇总统计.png')
        plt.savefig(summary_file, dpi=300, bbox_inches='tight', facecolor='white')
        plt.close()
        
        print(f"[OK] 汇总统计图生成成功: {summary_file}")
        return summary_file
        
    except Exception as e:
        print(f"[ERROR] 汇总统计图生成失败: {e}")
        return None

def save_landform_statistics(all_landform_stats, output_dir):
    """
    保存地貌统计数据到CSV文件
    
    参数:
        all_landform_stats: 所有地貌的统计信息 (dict)
        output_dir: 输出目录 (str)
        
    返回:
        str: CSV文件路径
    """
    try:
        # 创建DataFrame
        stats_data = []
        for landform, stats in all_landform_stats.items():
            stats_data.append({
                '地貌类型': landform,
                '国家数量': stats['country_count'],
                '平均风险得分': round(stats['avg_r'], 2),
                '平均意识得分': round(stats['avg_a'], 2),
                '平均行动得分': round(stats['avg_ac'], 2),
                '平均行动赤字': round(stats['avg_gap'], 2)
            })
        
        stats_df = pd.DataFrame(stats_data)
        
        # 保存到CSV
        import os
        stats_file = os.path.join(output_dir, '地貌统计数据.csv')
        stats_df.to_csv(stats_file, index=False, encoding='utf-8-sig')
        
        print(f"[OK] 统计数据保存成功: {stats_file}")
        return stats_file
        
    except Exception as e:
        print(f"[ERROR] 统计数据保存失败: {e}")
        return None

def get_nature_figsize(size_type='double_column'):
    """获取Nature标准尺寸"""
    if size_type == 'double_column':
        return (7.2, 4.5)  # 双栏标准
    elif size_type == 'single_column':
        return (3.5, 2.8)  # 单栏标准
    else:
        return (7.2, 4.5)  # 默认双栏

# ==================== 主函数 ====================

def main():
    """主函数 - 交互式模式选择"""
    print("=" * 60)
    print("三元地图可视化工具 - Ternary Map Visualization")
    print("=" * 60)
    print("输出尺寸: Nature 双栏标准 (183mm x 114mm)")
    print("=" * 60)

    # 应用配置
    config = get_config()
    config.apply()

    print("\n请选择运行模式:")
    print("1. 模拟数据模式 - 生成示例数据，保存图片和CSV")
    print("2. 自定义数据模式 - 输入您自己的国家数据")
    print("3. 快速演示 - 直接生成一张示例地图")
    print("4. [NEW] 实际数据模式 - 国家三元底色 + 言行不一差距散点(Ac-A)")
    print("5. [NEW] 地貌单独三元世界地图 - 为每种地貌生成国家级三元世界地图 (PNG+SVG)")
    print("6. [NEW] 实际数据聚类增强模式 - 地图+聚类散点+区域堆叠柱 (PNG+SVG)")

    choice = input("\n请输入选项 [1/2/3/4/5/6，默认4]: ").strip() or "4"

    if choice == "1":
        run_simulation_mode()
    elif choice == "2":
        run_custom_mode()
    elif choice == "3":
        # 快速演示 - 使用 Nature 标准尺寸
        print("\n正在生成快速演示...")
        country_data = generate_regional_pattern_data()
        fig, ax = create_country_ternary_map(
            country_data=country_data,
            resolution='50m',
            legend_labels=('北半球指标', '亚洲指标', '南半球指标'),
            title='世界国家三元色彩地图（演示）',
            # 使用 config 中的 Nature 标准尺寸
        )
        save_svg_editable(fig, 'demo_ternary_map.svg')
        save_png(fig, 'demo_ternary_map.png')
        plt.show()
    elif choice == "4":
        # 实际数据模式 - 国家三元底色 + “言行不一”差距散点：Ac - A（颜色=差距，大小=地貌数量）
        print("\n[INFO] 正在生成国家三元底色 + 行动-意识差距散点...")

        raw_df = load_actual_data("all_l_dimensions.csv")
        if raw_df is None:
            print("[ERROR] 实际数据加载失败")
            return

        # 1) 三元底色（保持原始版本的计算与配色）
        country_agg = aggregate_data_by_country(raw_df)
        if country_agg is None or len(country_agg) == 0:
            print("[ERROR] 国家数据聚合失败")
            return
        country_data = prepare_data_for_ternary_map(country_agg, "country")

        world_gdf = get_natural_earth_countries("50m")
        fig, ax = create_country_ternary_map(
            country_data=country_data,
            world_gdf=world_gdf,
            resolution="50m",
            legend_labels=("风险 (R)", "意识 (A)", "行动 (Ac)"),
            title="全球国家风险-意识-行动三元图\n(叠加：行动-意识差距 Ac - A)",
            edgecolor="black",
            linewidth=0.5,
            normalize_data=True,
            show_title=True,
        )

        # 2) 叠加差距散点
        gap_df = compute_country_awareness_action_gap(raw_df)
        add_gap_scatter_overlay(
            fig,
            ax,
            world_gdf=world_gdf,
            gap_df=gap_df,
            min_dot_size=4.0,
            max_dot_size=22.5,
            cmap="RdBu_r",
            gap_col="Gap_Ac_minus_A",
        )

        # 保存文件（沿用原始三元图文件名，但内容包含叠加散点）
        save_svg_editable(fig, "实际数据_国家三元图.svg")
        save_png(fig, "实际数据_国家三元图.png")
        save_data_to_csv(country_data, "实际数据_国家三元图_data.csv")
        gap_df.to_csv("实际数据_国家_言行不一差距_数据.csv", index=False, encoding="utf-8-sig")

        print("[SUCCESS] 已输出:")
        print("   - 实际数据_国家三元图.svg / 实际数据_国家三元图.png (三元底色+差距散点)")
        print("   - 实际数据_国家三元图_data.csv (三元数据)")
        print("   - 实际数据_国家_言行不一差距_数据.csv (差距与地貌数量)")

        plt.show()

    elif choice == "6":
        # 实际数据聚类增强模式 - 地图+聚类散点+区域堆叠柱
        print("\n[INFO] 正在生成实际数据的国家三元图（含聚类与区域分布）...")

        raw_df = load_actual_data("all_l_dimensions.csv")
        if raw_df is None:
            print("[ERROR] 实际数据加载失败")
            return

        country_agg = aggregate_data_by_country(raw_df)
        if country_agg is None or len(country_agg) == 0:
            print("[ERROR] 国家数据聚合失败")
            return

        clustered = cluster_countries_by_scores(country_agg, n_clusters=4, random_state=42, n_init=18)
        cluster_info = build_cluster_info(clustered)

        # 聚类增强图的底色：保持“最初版本”的 country_data（/15 后，再由 create_country_ternary_map 做 min-max）
        country_data = prepare_data_for_ternary_map(country_agg, 'country')

        config = get_config()
        config.apply()

        base_w, base_h = config.figsize
        fig = plt.figure(figsize=(base_w, base_h + 1.35), facecolor="white")
        gs = fig.add_gridspec(nrows=2, ncols=1, height_ratios=[3.6, 1.25], hspace=0.08)
        ax_map = fig.add_subplot(gs[0, 0])
        ax_bar = fig.add_subplot(gs[1, 0])

        mapper = TernaryColorMapper()
        create_country_ternary_map(
            country_data=country_data,
            ax=ax_map,
            mapper=mapper,
            resolution="50m",
            legend_labels=("风险 (R)", "意识 (A)", "行动 (Ac)"),
            title="全球国家风险-意识-行动三元图（聚类增强）\n(基于实际地貌数据分析)",
            edgecolor="none",
            linewidth=0.0,
            cluster_info=cluster_info,
            cluster_edge_lw=0.0,
            add_cluster_dots=True,
            cluster_dot_size=5.0,
            cluster_dot_alpha=0.95,
            cluster_dot_color_mode="cluster",
            normalize_data=True,
            show_title=True,
        )

        # 三元散点（按聚类着色）
        ax_scatter = ax_map.inset_axes([0.70, 0.03, 0.28, 0.40])
        add_cluster_ternary_scatter(
            ax_scatter,
            mapper=mapper,
            clustered_country_df=clustered,
            title="国家三元散点（按聚类）",
            show_cluster_labels=False,
        )

        # 聚类图例（用于散点颜色）
        from matplotlib.lines import Line2D

        legend_rows = (
            clustered[["Cluster_ID", "Cluster_Name", "Cluster_Color"]]
            .drop_duplicates()
            .sort_values("Cluster_ID")
            .to_dict("records")
        )
        handles = [
            Line2D(
                [0],
                [0],
                marker="o",
                color="none",
                markerfacecolor=r["Cluster_Color"],
                markeredgecolor="white",
                markeredgewidth=0.6,
                markersize=6,
                label=r["Cluster_Name"],
            )
            for r in legend_rows
        ]
        ax_map.legend(
            handles=handles,
            title="聚类种群",
            loc="upper right",
            fontsize=7,
            title_fontsize=8,
            frameon=True,
            framealpha=0.9,
            borderpad=0.6,
            labelspacing=0.4,
            handletextpad=0.5,
        )

        # 底部：按区域堆叠柱状图（国家数量）
        plot_cluster_distribution_by_region(
            ax_bar,
            clustered_country_df=clustered,
            region_col="Metadata_Region",
            mapping_csv=os.path.join("outputs", "mapping_template_Metadata_Region.csv"),
            as_share=False,
            title="各区域聚类种群分布（国家数量）",
        )
        leg = ax_bar.get_legend()
        if leg is not None:
            leg.remove()

        # 保存文件
        save_svg_editable(fig, "实际数据_国家三元图_聚类.svg")
        save_png(fig, "实际数据_国家三元图_聚类.png")
        clustered.to_csv("实际数据_国家聚类结果.csv", index=False, encoding="utf-8-sig")

        print("[SUCCESS] 国家三元图（聚类版）生成完成！")
        print("   输出文件:")
        print("   - 实际数据_国家三元图_聚类.svg (可编辑矢量图)")
        print("   - 实际数据_国家三元图_聚类.png (高清图片)")
        print("   - 实际数据_国家聚类结果.csv (国家聚类与三元坐标)")

        plt.show()
            
    elif choice == "5":
        # [NEW] 地貌单独三元图模式 - 为每种地貌生成国家级三元世界地图
        print("\n[INFO] 正在为每种地貌生成三元世界地图...")
        print("   这将为8种地貌类型分别生成PNG + 可编辑SVG + 数据CSV")
        print("   每个图显示该地貌在不同国家的R-A-Ac分布（国家边界上着色）")
        
        generated_files = create_landform_world_maps()
        
        if generated_files:
            print("\n[SUCCESS] 所有地貌三元世界地图生成完成！")
            print("   输出文件:")
            for landform, files in generated_files.items():
                if isinstance(files, dict):
                    parts = []
                    if files.get('png'):
                        parts.append(f"PNG: {files['png']}")
                    if files.get('svg'):
                        parts.append(f"SVG: {files['svg']}")
                    if files.get('data'):
                        parts.append(f"数据: {files['data']}")
                    print(f"   - {landform}: " + "; ".join(parts))
                else:
                    print(f"   - {landform}: {files}")
        else:
            print("[ERROR] 地貌三元世界地图生成失败")
    else:
        print("[ERROR] 无效选项，请重新运行程序")


# ==================== 模块导出 ====================

__all__ = [
    'TernaryColorMapper',
    'TernaryMapConfig',
    'ProfessionalTernaryLegend',
    'create_country_ternary_map',
    'save_figure',
    'save_svg_editable',
    'save_png',
    'save_data_to_csv',
    'load_data_from_csv',
    'create_custom_mapper',
    'hex_to_rgb',
    'generate_sample_country_data',
    'generate_regional_pattern_data',
    'get_natural_earth_countries',
    'get_config',
    'set_config',
    'create_landform_world_maps',
]


if __name__ == '__main__':
    main()
