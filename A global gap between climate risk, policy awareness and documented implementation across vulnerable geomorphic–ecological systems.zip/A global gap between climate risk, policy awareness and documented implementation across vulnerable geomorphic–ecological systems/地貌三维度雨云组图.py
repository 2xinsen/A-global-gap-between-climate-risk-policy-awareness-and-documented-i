# -*- coding: utf-8 -*-
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Sequence

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import Rectangle

# 引入模板工具
TEMPLATE_DIR = Path(__file__).parent / "模板"
if str(TEMPLATE_DIR) not in sys.path:
    sys.path.insert(0, str(TEMPLATE_DIR))

from config_nature import apply_nature_style  # type: ignore
from base import auto_output_path  # type: ignore

# 八类地貌
SUB_THEMES: Sequence[str] = [
    "Forests & Ecosystems",
    "Coastal Wetlands",
    "Desertification & Drylands",
    "Rivers & Deltas",
    "Karst Systems",
    "Coral Reefs & Islands",
    "Peatlands",
    "Cryosphere & Permafrost",
]

# 三个总分维度
METRICS: Sequence[tuple[str, str]] = [
    ("Scores_R_total_score", "Risk (R)"),
    ("Scores_A_total_score", "Awareness (A)"),
    ("Scores_Ac_total_score", "Action (Ac)"),
]

# 8个地貌的基础色（色相区分）；每个地貌的3个维度用同色不同明度来区分
THEME_BASE_COLORS = {
    "Forests & Ecosystems": "#1b9e77",
    "Coastal Wetlands": "#d95f02",
    "Desertification & Drylands": "#7570b3",
    "Rivers & Deltas": "#e7298a",
    "Karst Systems": "#66a61e",
    "Coral Reefs & Islands": "#e6ab02",
    "Peatlands": "#a6761d",
    "Cryosphere & Permafrost": "#1f78b4",
}


def _half_violin(ax, values: np.ndarray, *, center: float, width: float, color: str) -> None:
    """半小提琴：右半边保留以减少重叠。"""
    violin = ax.violinplot(
        values,
        positions=[center],
        widths=width,
        showmeans=False,
        showmedians=False,
        showextrema=False,
    )
    for body in violin["bodies"]:
        body.set_facecolor(color)
        body.set_edgecolor(color)
        body.set_alpha(0.35)
        vertices = body.get_paths()[0].vertices
        mask = vertices[:, 0] < center
        vertices[mask, 0] = center


def _box(ax, values: np.ndarray, *, center: float, width: float, color: str) -> None:
    """箱线图：兼容 IQR=0 场景，必要时补微小箱体。"""
    q1, median, q3 = np.percentile(values, [25, 50, 75])
    data_min, data_max = float(np.min(values)), float(np.max(values))
    flat_iqr = np.isclose(q1, q3)
    ax.boxplot(
        values,
        positions=[center],
        widths=width,
        patch_artist=True,
        showfliers=False,
        notch=True,
        medianprops={"color": "black", "linewidth": 1.0},
        boxprops={"facecolor": color, "edgecolor": "black", "linewidth": 1.0, "alpha": 0.7},
        whiskerprops={"color": "black", "linewidth": 1.0},
        capprops={"color": "black", "linewidth": 1.0},
        whis=[0, 100],
    )
    if flat_iqr:
        span = max(0.2, 0.04 * (data_max - data_min if data_max > data_min else 1.0))
        lower = max(data_min, q1 - span / 2)
        upper = min(data_max, q1 + span / 2)
        ax.add_patch(
            Rectangle(
                (center - width / 2, lower),
                width,
                max(upper - lower, 1e-3),
                facecolor=color,
                edgecolor="black",
                linewidth=1.0,
                alpha=0.7,
                zorder=2,
            )
        )


def _lighten(color: str, amount: float) -> str:
    """调亮颜色，amount ∈ [0,1] 越大越亮。"""
    r, g, b = mpl.colors.to_rgb(color)
    mix = (1 - amount) * np.array([r, g, b]) + amount * np.array([1, 1, 1])
    return mpl.colors.to_hex(np.clip(mix, 0, 1))


def plot_theme_panel(ax: plt.Axes, df: pd.DataFrame, theme: str) -> None:
    """单个地貌面板，包含3个维度的雨云组合（箱线+半小提琴，无散点，保证不重叠）。"""
    centers = [-0.5, 0.0, 0.5]  # 充分间距避免三维度互相遮挡
    base = THEME_BASE_COLORS.get(theme, "#888888")
    dim_colors = [
        base,
        _lighten(base, 0.22),
        _lighten(base, 0.38),
    ]
    for (col, label), center, color in zip(METRICS, centers, dim_colors):
        if col not in df.columns:
            continue
        vals = pd.to_numeric(df[col], errors="coerce").dropna().to_numpy()
        if vals.size == 0:
            ax.text(center, 7.5, "No data", ha="center", va="center", fontsize=7)
            continue
        # 箱线居中，半小提琴右移，避免自身重叠且与其他维度有间隔
        _box(ax, vals, center=center, width=0.2, color=color)
        _half_violin(ax, vals, center=center + 0.18, width=0.34, color=color)

    ax.set_title(theme, fontsize=9, pad=6, color=base)
    ax.set_xlim(-0.85, 0.85)
    ax.set_ylim(-0.5, 15.5)
    ax.set_xticks(centers)
    ax.set_xticklabels([label for _, label in METRICS], rotation=20, fontsize=7)
    ax.set_yticks([0, 5, 10, 15])
    ax.tick_params(axis="y", labelsize=7, length=5, width=1.0)
    ax.tick_params(axis="x", labelsize=7, length=5, width=1.0)
    for spine in ["top", "right"]:
        ax.spines[spine].set_visible(False)


def create_geomorph_raincloud(
    csv_path: str = "all_l_dimensions.csv",
    output_prefix: str | None = None,
) -> None:
    df = pd.read_csv(csv_path)
    style = apply_nature_style("double")

    fig, axes = plt.subplots(
        nrows=2,
        ncols=4,
        figsize=(13.5, 6.8),
        dpi=style.dpi,
        sharey=True,
    )

    for theme, ax in zip(SUB_THEMES, axes.flat):
        subset = df[df["Sub_Theme"] == theme]
        plot_theme_panel(ax, subset, theme)

    for idx, ax in enumerate(axes.flat):
        if idx % 4 == 0:
            ax.set_ylabel("Score", fontsize=8)

    fig.suptitle("Eight geomorphologies – three score dimensions", fontsize=10, y=0.97)
    fig.tight_layout(pad=1.1, rect=(0, 0, 1, 0.96))

    out_dir, _ = auto_output_path(__file__, csv_path)
    prefix = output_prefix or f"{Path(csv_path).stem}_geomorph_raincloud"
    save_base = out_dir / prefix
    save_base.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(f"{save_base}.png", dpi=style.dpi)
    fig.savefig(f"{save_base}.svg", dpi=style.dpi)
    plt.close(fig)

    # 输出统计数据 CSV
    stats_list = []
    for theme in SUB_THEMES:
        subset = df[df["Sub_Theme"] == theme]
        for col, label in METRICS:
            if col in subset.columns:
                vals = pd.to_numeric(subset[col], errors="coerce").dropna()
                if vals.size > 0:
                    stats_list.append({
                        "Theme": theme,
                        "Dimension": label,
                        "Column": col,
                        "Min": vals.min(),
                        "Q25": vals.quantile(0.25),
                        "Median": vals.median(),
                        "Q75": vals.quantile(0.75),
                        "Max": vals.max(),
                        "Mean": vals.mean(),
                        "Std": vals.std(),
                        "Count": vals.size,
                    })
                else:
                    stats_list.append({
                        "Theme": theme,
                        "Dimension": label,
                        "Column": col,
                        "Min": np.nan,
                        "Q25": np.nan,
                        "Median": np.nan,
                        "Q75": np.nan,
                        "Max": np.nan,
                        "Mean": np.nan,
                        "Std": np.nan,
                        "Count": 0,
                    })

    stats_df = pd.DataFrame(stats_list)
    csv_path = f"{save_base}_data.csv"
    stats_df.to_csv(csv_path, index=False, encoding="utf-8-sig")
    print(f"[SUCCESS] Saved: {save_base}.png and .svg")
    print(f"[SUCCESS] Saved statistics: {csv_path}")


def main() -> None:
    parser = argparse.ArgumentParser(description="8地貌 × 3维度雨云组图 (4x2)")
    parser.add_argument("--csv", default="all_l_dimensions.csv", help="输入CSV路径")
    parser.add_argument("--out_prefix", default=None, help="输出前缀（可选）")
    args = parser.parse_args()
    create_geomorph_raincloud(csv_path=args.csv, output_prefix=args.out_prefix)


if __name__ == "__main__":
    main()
