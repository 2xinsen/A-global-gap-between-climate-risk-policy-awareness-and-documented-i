from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# 引入模板工具
TEMPLATE_DIR = Path(__file__).parent / "模板"
if str(TEMPLATE_DIR) not in sys.path:
    sys.path.insert(0, str(TEMPLATE_DIR))

from config_nature import apply_nature_style  # type: ignore
from base import auto_output_path  # type: ignore

# 八类地貌
SUB_THEMES: Sequence[str] = [
    "Forests & Ecosystems",
    "Coastal Wetlands",
    "Desertification & Drylands",
    "Rivers & Deltas",
    "Karst Systems",
    "Coral Reefs & Islands",
    "Peatlands",
    "Cryosphere & Permafrost",
]

# 指标：字段、标签、变换模式、推荐刻度（原始单位）
# 仅保留 1/2/5/6：行动减风险、GDP loss、FGI、时间跨度
METRICS: Sequence[Tuple[str, str, str, Sequence[float]]] = [
    ("Scores_action_minus_risk_score", "Action – Risk score", "linear", (-10, -5, 0, 5, 10)),
    ("Deep_Metrics_Risk_GDP_Loss_Pct", "GDP loss (%)", "log1p", (0, 1, 5, 10, 20, 40)),
    ("Deep_Metrics_FGI_Pct", "FGI (%)", "log1p", (0, 0.1, 1, 10, 100)),
    ("Deep_Metrics_Time_Horizon_Yrs", "Time horizon (yrs)", "linear", (0, 10, 20, 40, 80)),
]

# 地貌基础色
THEME_BASE_COLORS: Dict[str, str] = {
    "Forests & Ecosystems": "#1b9e77",
    "Coastal Wetlands": "#d95f02",
    "Desertification & Drylands": "#7570b3",
    "Rivers & Deltas": "#e7298a",
    "Karst Systems": "#66a61e",
    "Coral Reefs & Islands": "#e6ab02",
    "Peatlands": "#a6761d",
    "Cryosphere & Permafrost": "#1f78b4",
}


def _transform(values: pd.Series, mode: str) -> np.ndarray:
    arr = pd.to_numeric(values, errors="coerce").dropna().to_numpy()
    if mode == "log1p":
        arr = np.log1p(np.clip(arr, 0, None))
    return arr


def _inv_transform(values: np.ndarray, mode: str) -> np.ndarray:
    if mode == "log1p":
        return np.expm1(values)
    return values

def _smooth_density(arr: np.ndarray, vmin: float, vmax: float, bins: int = 80) -> Tuple[np.ndarray, np.ndarray]:
    """平滑直方密度，避免山脊锯齿与极端集中。"""
    hist, edges = np.histogram(arr, bins=bins, range=(vmin, vmax), density=True)
    centers = (edges[:-1] + edges[1:]) / 2
    # Gaussian kernel平滑（更宽核，提升平缓度）
    kernel_x = np.linspace(-4, 4, 35)
    kernel = np.exp(-0.5 * kernel_x**2)
    kernel /= kernel.sum()
    smooth = np.convolve(hist, kernel, mode="same")
    return centers, smooth

def _quantile_range(arr: np.ndarray, q: float = 0.05) -> Tuple[float, float]:
    if arr.size == 0:
        return (0.0, 1.0)
    low, high = np.quantile(arr, [q, 1 - q])
    if low == high:
        return (low - 0.5, high + 0.5)
    return (low, high)


def _nice_ticks(ticks: Sequence[float], vmin: float, vmax: float) -> List[float]:
    return [t for t in ticks if vmin <= t <= vmax]


def create_ridge_grid(csv_path: str = "all_l_dimensions.csv", output_prefix: str | None = None) -> None:
    df = pd.read_csv(csv_path)
    style = apply_nature_style("double")

    # 预处理：按指标计算全局范围（变换后，分位裁剪）
    metric_ranges: Dict[str, Tuple[float, float]] = {}
    for col, _, mode, _ in METRICS:
        vals = _transform(df[col], mode) if col in df.columns else np.array([])
        metric_ranges[col] = _quantile_range(vals, q=0.01)

    n_rows = len(METRICS)
    n_cols = len(SUB_THEMES)
    fig_height = max(6.0, n_rows * 1.2)  # 控制整体高度
    fig, axes = plt.subplots(
        nrows=n_rows,
        ncols=n_cols,
        figsize=(18, fig_height),
        dpi=style.dpi,
        sharey=False,
        sharex=False,
    )

    for row_idx, (col, label, mode, tick_candidates) in enumerate(METRICS):
        vmin, vmax = metric_ranges.get(col, (0.0, 1.0))
        for col_idx, theme in enumerate(SUB_THEMES):
            ax = axes[row_idx, col_idx] if n_rows > 1 else axes[col_idx]
            theme_color = THEME_BASE_COLORS.get(theme, "#444444")
            if col not in df.columns:
                ax.text(0.5, 0.5, "No data", ha="center", va="center", fontsize=7)
                ax.axis("off")
                continue
            vals = _transform(df.loc[df["Sub_Theme"] == theme, col], mode)
            vals = vals[(vals >= vmin) & (vals <= vmax)]
            if vals.size == 0:
                ax.text(0.5, 0.5, "No data", ha="center", va="center", fontsize=7)
                ax.axis("off")
                continue

            centers, density = _smooth_density(vals, vmin, vmax, bins=100)

            ax.fill_between(centers, density, color=theme_color, alpha=0.35)
            ax.plot(centers, density, color=theme_color, linewidth=1.0)

            ax.set_ylim(0, density.max() * 1.15 if density.size else 1)
            ax.set_xlim(vmin, vmax)
            # 刻度：用原始单位 tick_candidates 映射到变换后位置
            tick_positions = []
            tick_labels = []
            raw_min, raw_max = _inv_transform(np.array([vmin, vmax]), mode)
            for t in _nice_ticks(tick_candidates, raw_min, raw_max):
                pos = np.log1p(t) if mode == "log1p" else t
                if vmin <= pos <= vmax:
                    tick_positions.append(pos)
                    tick_labels.append(str(t))
            if not tick_positions:
                tick_positions = [vmin, vmax]
                tick_labels = [f"{_inv_transform(np.array([vmin]))[0]:.2g}", f"{_inv_transform(np.array([vmax]))[0]:.2g}"]
            ax.set_xticks(tick_positions)
            ax.set_xticklabels(tick_labels, fontsize=7, rotation=20)
            ax.set_yticks([])
            if col_idx == 0:
                ax.set_ylabel(label, fontsize=8)
            else:
                ax.set_yticklabels([])
            if row_idx == 0:
                ax.set_title(theme, fontsize=9, pad=6, color=theme_color)
            for spine in ["top", "right", "left"]:
                ax.spines[spine].set_visible(False)

    fig.suptitle("Deep metrics ridgeline by geomorphology", fontsize=10, y=0.995)
    fig.tight_layout(pad=1.0, rect=(0, 0, 1, 0.985))

    out_dir, _ = auto_output_path(__file__, csv_path)
    prefix = output_prefix or f"{Path(csv_path).stem}_deep_metrics_ridge"
    save_base = out_dir / prefix
    save_base.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(f"{save_base}.png", dpi=style.dpi, bbox_inches="tight")
    fig.savefig(f"{save_base}.svg", dpi=style.dpi, bbox_inches="tight")
    plt.close(fig)
    print(f"[SUCCESS] Saved: {save_base}.png and .svg")
    print("FGI uses log1p; ticks show original units.")

    # 额外导出：用于分析的密度曲线与摘要统计（按指标×地貌）
    density_rows: list[dict] = []
    summary_rows: list[dict] = []

    for col, label, mode, _tick_candidates in METRICS:
        vmin, vmax = metric_ranges.get(col, (0.0, 1.0))
        for theme in SUB_THEMES:
            raw_series = pd.to_numeric(df.loc[df["Sub_Theme"] == theme, col], errors="coerce").dropna()
            if raw_series.empty:
                continue
            raw_arr = raw_series.to_numpy(dtype=float)
            trans_arr = np.log1p(np.clip(raw_arr, 0, None)) if mode == "log1p" else raw_arr
            mask = (trans_arr >= vmin) & (trans_arr <= vmax)
            raw_used = raw_arr[mask]
            trans_used = trans_arr[mask]
            if trans_used.size == 0:
                continue

            centers, density = _smooth_density(trans_used, vmin, vmax, bins=100)
            raw_centers = _inv_transform(centers, mode)
            for x_t, x_raw, d in zip(centers.tolist(), raw_centers.tolist(), density.tolist()):
                density_rows.append(
                    dict(
                        metric_col=col,
                        metric_label=label,
                        transform=mode,
                        sub_theme=theme,
                        x_transformed=float(x_t),
                        x_raw=float(x_raw),
                        density=float(d),
                    )
                )

            summary_rows.append(
                dict(
                    metric_col=col,
                    metric_label=label,
                    transform=mode,
                    sub_theme=theme,
                    n=int(raw_used.size),
                    mean=float(np.mean(raw_used)),
                    median=float(np.median(raw_used)),
                    q05=float(np.quantile(raw_used, 0.05)),
                    q25=float(np.quantile(raw_used, 0.25)),
                    q75=float(np.quantile(raw_used, 0.75)),
                    q95=float(np.quantile(raw_used, 0.95)),
                    plot_vmin_transformed=float(vmin),
                    plot_vmax_transformed=float(vmax),
                )
            )

    if density_rows:
        density_df = pd.DataFrame(density_rows)
        density_path = f"{save_base}_density_data.csv"
        density_df.to_csv(density_path, index=False, encoding="utf-8-sig")
        print(f"[SUCCESS] Data exported: {density_path}")
    if summary_rows:
        summary_df = pd.DataFrame(summary_rows)
        summary_path = f"{save_base}_summary_data.csv"
        summary_df.to_csv(summary_path, index=False, encoding="utf-8-sig")
        print(f"[SUCCESS] Data exported: {summary_path}")


def main() -> None:
    parser = argparse.ArgumentParser(description="深度指标山脊组图（1行8地貌，列内竖排指标）")
    parser.add_argument("--csv", default="all_l_dimensions.csv", help="输入CSV路径")
    parser.add_argument("--out_prefix", default=None, help="输出前缀（可选）")
    args = parser.parse_args()
    create_ridge_grid(csv_path=args.csv, output_prefix=args.out_prefix)


if __name__ == "__main__":
    main()
