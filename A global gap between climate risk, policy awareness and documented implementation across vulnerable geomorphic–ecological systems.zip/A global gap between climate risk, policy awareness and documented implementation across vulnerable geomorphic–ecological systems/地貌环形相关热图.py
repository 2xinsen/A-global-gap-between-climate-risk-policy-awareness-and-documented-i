from __future__ import annotations

import argparse
import math
import sys
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.transforms import offset_copy

# 引入模板工具（Nature 风格与输出路径）
TEMPLATE_DIR = Path(__file__).parent / "模板"
if str(TEMPLATE_DIR) not in sys.path:
    sys.path.insert(0, str(TEMPLATE_DIR))

from config_nature import apply_nature_style  # type: ignore
from base import auto_output_path  # type: ignore


# 八类地貌（保持统一顺序）
SUB_THEMES: Sequence[str] = [
    "Forests & Ecosystems",
    "Coastal Wetlands",
    "Desertification & Drylands",
    "Rivers & Deltas",
    "Karst Systems",
    "Coral Reefs & Islands",
    "Peatlands",
    "Cryosphere & Permafrost",
]

# 与雨云组图保持一致的主题色
THEME_BASE_COLORS: Dict[str, str] = {
    "Forests & Ecosystems": "#1b9e77",
    "Coastal Wetlands": "#d95f02",
    "Desertification & Drylands": "#7570b3",
    "Rivers & Deltas": "#e7298a",
    "Karst Systems": "#66a61e",
    "Coral Reefs & Islands": "#e6ab02",
    "Peatlands": "#a6761d",
    "Cryosphere & Permafrost": "#1f78b4",
}

# 分组色（跨地貌一致；色盲友好）
GROUP_COLORS: Dict[str, str] = {
    "Contextual Determinants": "#3C5488FF",
    "Adaptation Consistency": "#00A087FF",
    "Implementation Intensity": "#4DBBD5FF",
    "Risk & Impact Metrics": "#E64B35FF",
    "Implementation Barriers": "#F39B7FFF",
    "Mechanism Pathways": "#8491B4FF",
}

# 目标相关性：R1-R5 + Gap
TARGETS: Sequence[Tuple[str, str]] = [
    ("Scores_R1_Hazard", "R1 Hazard"),
    ("Scores_R2_Exposure", "R2 Exposure"),
    ("Scores_R3_Vulnerability", "R3 Vulnerability"),
    ("Scores_R4_Data_Gap", "R4 Data gap"),
    ("Scores_R5_Eco_Impact", "R5 Eco impact"),
    ("Scores_action_minus_risk_score", "Action–Risk gap"),
]

# 需要测试相关性的特征（按用户列出的顺序分组）
FeatureDef = Tuple[str, str, str]  # (column, label, group)

FEATURES: Sequence[FeatureDef] = [
    # Contextual Determinants（原 Metadata）
    ("Metadata_Region", "Region", "Contextual Determinants"),
    ("Metadata_Income_Group", "Income group", "Contextual Determinants"),
    ("Metadata_Climate_Zone", "Climate zone", "Contextual Determinants"),
    ("Metadata_GDP_pc", "GDP per capita", "Contextual Determinants"),
    ("Metadata_Agri_Pct", "Agriculture share (%)", "Contextual Determinants"),
    ("Metadata_Industrial_Pct", "Industry share (%)", "Contextual Determinants"),
    ("Metadata_WGI_Gov", "Gov. Effectiveness (WGI)", "Contextual Determinants"),
    ("Metadata_WGI_Cor", "Control of Corruption", "Contextual Determinants"),
    ("Metadata_ND_Vul_Index", "ND Vulnerability Index", "Contextual Determinants"),
    ("Metadata_A_Doc_Year", "Assessment Year", "Contextual Determinants"),
    ("Metadata_Act_Doc_Year", "Action Year", "Contextual Determinants"),
    ("Metadata_Doc_Language", "Document Language", "Contextual Determinants"),
    ("Metadata_Pct_FullText_Description", "Text Availability (%)", "Contextual Determinants"),
    # Adaptation Consistency（原 A1-A5）
    ("Scores_A1_Diagnostic", "A1: Diagnostic Consistency", "Adaptation Consistency"),
    ("Scores_A2_Integration", "A2: Policy Integration", "Adaptation Consistency"),
    ("Scores_A3_Stakeholder", "A3: Stakeholder Engagement", "Adaptation Consistency"),
    ("Scores_A4_Planning", "A4: Planning Robustness", "Adaptation Consistency"),
    ("Scores_A5_Finance", "A5: Financial Framework", "Adaptation Consistency"),
    # Implementation Intensity（原 Ac1-Ac5）
    ("Scores_Ac1_Implementation", "Ac1: Implementation Status", "Implementation Intensity"),
    ("Scores_Ac2_Governance", "Ac2: Governance Structure", "Implementation Intensity"),
    ("Scores_Ac3_Finance", "Ac3: Funding Mechanism", "Implementation Intensity"),
    ("Scores_Ac4_Monitoring", "Ac4: M&E Systems", "Implementation Intensity"),
    ("Scores_Ac5_Capacity", "Ac5: Technical Capacity", "Implementation Intensity"),
    # Risk & Impact Metrics（原 Deep Metrics）
    ("Deep_Metrics_Risk_Probability_Val", "Risk Probability", "Risk & Impact Metrics"),
    ("Deep_Metrics_Exposed_Pop_Count", "Exposed Population", "Risk & Impact Metrics"),
    ("Deep_Metrics_Vul_Index_Ref", "Reference Vulnerability", "Risk & Impact Metrics"),
    ("Deep_Metrics_Risk_GDP_Loss_Pct", "Proj. GDP Loss (%)", "Risk & Impact Metrics"),
    ("Deep_Metrics_TSI_Score", "TSI Score", "Risk & Impact Metrics"),
    ("Deep_Metrics_Time_Horizon_Yrs", "Time Horizon (Years)", "Risk & Impact Metrics"),
    ("Deep_Metrics_Budget_Commit_USD", "Committed Budget (USD)", "Risk & Impact Metrics"),
    ("Deep_Metrics_PCS_Score", "PCS Score", "Risk & Impact Metrics"),
    ("Deep_Metrics_FGI_Pct", "Fin. Gap Index (%)", "Risk & Impact Metrics"),
    ("Deep_Metrics_Inv_Gap_USD", "Investment Gap (USD)", "Risk & Impact Metrics"),
    # Implementation Barriers（原 Barriers）
    ("Barrier_Weights_Financial", "Barrier: Financial", "Implementation Barriers"),
    ("Barrier_Weights_Institutional", "Barrier: Institutional", "Implementation Barriers"),
    ("Barrier_Weights_Technical", "Barrier: Technical", "Implementation Barriers"),
    ("Barrier_Weights_Political", "Barrier: Political", "Implementation Barriers"),
    ("Barrier_Weights_Regulatory", "Barrier: Regulatory", "Implementation Barriers"),
    # Mechanism Pathways（原 Causal chains）
    ("Causal_Chains_1_Chain_Type", "Risk Cascade Type", "Mechanism Pathways"),
    ("Causal_Chains_2_Chain_Type", "Barrier Mechanism", "Mechanism Pathways"),
]


def _corr_with_feature(series_target: pd.Series, series_feat: pd.Series) -> Tuple[float, str | None]:
    """Compute Spearman correlation; categorical特征会用 one-hot 单列里相关性最大的类别."""
    t = pd.to_numeric(series_target, errors="coerce")
    f_raw = series_feat
    mask = t.notna() & f_raw.notna()
    t = t[mask]
    f = f_raw[mask]
    if len(t) < 6 or t.nunique() < 2:  # 样本太少或无波动
        return math.nan, None

    f_num = pd.to_numeric(f, errors="coerce")
    # 如果多数可转为数值且有波动，则直接 Spearman
    if f_num.notna().sum() >= max(4, int(len(f) * 0.45)) and f_num.nunique() >= 2:
        return float(t.corr(f_num, method="spearman")), None

    # 类别型：逐个 dummy 计算，取绝对值最大的类别
    cats = f.astype(str).str.strip()
    dummies = pd.get_dummies(cats, drop_first=False)
    best_corr = math.nan
    best_cat: str | None = None
    for col in dummies.columns:
        dummy = dummies[col]
        if dummy.sum() < 3:  # 避免极小样本类别
            continue
        corr_val = t.corr(dummy, method="spearman")
        if pd.notna(corr_val) and (math.isnan(best_corr) or abs(corr_val) > abs(best_corr)):
            best_corr = float(corr_val)
            best_cat = col
    return best_corr, best_cat


def compute_correlation_matrix(df: pd.DataFrame) -> Tuple[np.ndarray, Dict[str, str | None]]:
    """返回相关矩阵 (targets x features) 以及特征的最佳类别注记。"""
    matrix = np.full((len(TARGETS), len(FEATURES)), np.nan)
    feature_notes: Dict[str, str | None] = {}

    for j, (feat_col, feat_label, _) in enumerate(FEATURES):
        if feat_col not in df.columns:
            feature_notes[feat_label] = None
            continue
        cat_notes: Dict[int, str | None] = {}
        for i, (target_col, _) in enumerate(TARGETS):
            corr_val, best_cat = _corr_with_feature(df[target_col], df[feat_col])
            matrix[i, j] = corr_val
            if best_cat:
                cat_notes[i] = best_cat
        # 记录该特征在“最相关目标”下的类别名称，便于图例说明
        if cat_notes:
            # 选取绝对值最大的目标对应的类别
            idx_best = max(cat_notes.keys(), key=lambda idx: abs(matrix[idx, j]))
            feature_notes[feat_label] = cat_notes[idx_best]
        else:
            feature_notes[feat_label] = None
    return matrix, feature_notes


def _polar_deg(theta: float, *, theta_offset: float, theta_direction: float) -> float:
    """将 data theta 映射为屏幕坐标角度（度），与 Matplotlib rotation 一致。"""
    angle = theta_offset + theta_direction * theta
    return (np.degrees(angle) + 360.0) % 360.0


def _radial_text_rotation(theta: float, *, theta_offset: float, theta_direction: float) -> Tuple[float, str]:
    """径向文字：沿半径方向放置，并在左半球翻转保证可读。"""
    deg = _polar_deg(theta, theta_offset=theta_offset, theta_direction=theta_direction)
    rotation = deg
    if 90.0 < deg < 270.0:
        return rotation + 180.0, "right"
    return rotation, "left"


def _tangent_char_rotation(display_deg: float) -> float:
    """弧线字符：切线方向且保持正向（不倒立）。"""
    if 90.0 < display_deg < 270.0:
        return display_deg + 90.0
    return display_deg - 90.0


def _group_spans(feature_defs: Sequence[FeatureDef]) -> List[Tuple[str, int, int]]:
    """计算同一分组在特征序列中的起止索引。"""
    spans: List[Tuple[str, int, int]] = []
    if not feature_defs:
        return spans
    start = 0
    current_group = feature_defs[0][2]
    for idx, (_, _, group) in enumerate(feature_defs):
        if group != current_group:
            spans.append((current_group, start, idx))
            start = idx
            current_group = group
    spans.append((current_group, start, len(feature_defs)))
    return spans


def _arc_text(
    ax,
    start_ang: float,
    end_ang: float,
    radius: float,
    text: str,
    color: str,
    *,
    theta_offset: float,
    theta_direction: float,
    fontsize: float = 7.6,
) -> None:
    """在圆弧上逐字符排版组别文字。"""
    if not text:
        return
    # 将扇形端点转换到“显示角度”空间（已包含 offset 与 direction）
    start_disp = theta_offset + theta_direction * start_ang
    end_disp = theta_offset + theta_direction * end_ang
    center_disp = (start_disp + end_disp) / 2
    sector_width = abs(end_disp - start_disp)
    chars = list(text)
    if not chars or sector_width <= 0:
        return

    # 按上半圆/下半圆决定文字走向：保证从左到右阅读
    center_deg = (np.degrees(center_disp) + 360.0) % 360.0
    direction_disp = 1.0 if center_deg >= 180.0 else -1.0

    weights = [0.18 if ch.isspace() else 1.0 for ch in chars]
    total_weight = float(sum(weights))
    if total_weight <= 0:
        return

    usable = sector_width * 0.75
    # 字符间距上限（越大越“稀疏”）；放大字体时反而应更紧凑
    max_step = np.deg2rad(3.2 if fontsize <= 10 else 2.6)
    step = min(usable / total_weight, max_step)
    used = step * total_weight
    start_text = center_disp - direction_disp * used / 2

    cursor = 0.0
    for ch, w in zip(chars, weights):
        cursor += w * step / 2
        disp_ang = start_text + direction_disp * cursor
        cursor += w * step / 2
        if ch.isspace():
            continue
        # 反解回 data theta
        theta_data = (disp_ang - theta_offset) / theta_direction
        rot = _tangent_char_rotation((np.degrees(disp_ang) + 360.0) % 360.0)
        ax.text(
            theta_data,
            radius,
            ch,
            color=color,
            ha="center",
            va="center",
            fontsize=fontsize,
            fontweight="bold",
            rotation=rot,
            rotation_mode="anchor",
            zorder=4,
        )


def _split_group_label(text: str) -> Tuple[str, str] | None:
    parts = [p for p in text.split(" ") if p]
    if len(parts) <= 1:
        return None
    mid = len(parts) // 2
    return (" ".join(parts[:mid]), " ".join(parts[mid:]))


def plot_ring_heatmap(
    corr_matrix: np.ndarray,
    feature_defs: Sequence[FeatureDef],
    feature_notes: Dict[str, str | None],
    *,
    sub_theme: str,
    style,
    save_base: Path,
) -> None:
    """绘制环形相关性热图。"""
    n_targets, n_features = corr_matrix.shape

    # 3/4 环：覆盖 270 度，保留 90 度留白
    theta_span = 1.5 * np.pi
    theta_edges = np.linspace(0, theta_span, n_features + 1)
    # 半径：内圈空白扩大两倍（相对 r_inner=0.7），并保持足够环带厚度
    r_inner = 1.4
    r_outer = 2.0
    radius_edges = np.linspace(r_inner, r_outer, n_targets + 1)

    # 配色：以当前地貌主题色为正向锚点
    theme_color = THEME_BASE_COLORS.get(sub_theme, "#2f3e46")
    ct = style.color_transform
    neg_anchor = ct.darken(ct.desaturate(theme_color, 0.7), 0.25)
    pos_anchor = ct.darken(theme_color, 0.0)
    cmap = mpl.colors.LinearSegmentedColormap.from_list(
        "theme_div",
        [neg_anchor, "#f7f7f7", pos_anchor],
    )
    cmap.set_bad("#f0f0f0")
    norm = mpl.colors.Normalize(vmin=-1, vmax=1)

    fig = plt.figure(figsize=(10.5, 10.5), dpi=style.dpi)
    ax = fig.add_subplot(111, projection="polar")
    ax.set_theta_offset(np.pi / 2)  # 12 点方向开始
    ax.set_theta_direction(-1)  # 顺时针

    # 环形色块
    pc = ax.pcolormesh(theta_edges, radius_edges, corr_matrix, cmap=cmap, norm=norm, shading="flat")

    # 环形分隔线
    for r in radius_edges:
        ax.plot(theta_edges, np.full_like(theta_edges, r), color="#d8d8d8", linewidth=0.6, zorder=2)
    for ang in theta_edges:
        ax.plot([ang, ang], [radius_edges[0], radius_edges[-1]], color="#f0f0f0", linewidth=0.45, zorder=2)

    theta_offset = ax.get_theta_offset()
    theta_direction = float(ax.get_theta_direction())
    # 目标标签：右侧挨着热力图（与每一环带对齐），在 axes 坐标系中排布以避免 polar 在 3 点方向 y 恒定的问题
    theta_ref = theta_span * 0.58  # 选在右下象限附近，确保不同半径有不同 y
    ref_points = []
    for idx, (_, t_label) in enumerate(TARGETS):
        r_pos = (radius_edges[idx] + radius_edges[idx + 1]) / 2
        x_disp, y_disp = ax.transData.transform((theta_ref, r_pos))
        x_ax, y_ax = ax.transAxes.inverted().transform((x_disp, y_disp))
        ref_points.append((y_ax, t_label))
    # 从上到下排列（y 大在上）
    ref_points.sort(key=lambda t: t[0], reverse=True)
    x_target = max(ax.transAxes.inverted().transform(ax.transData.transform((theta_ref, radius_edges[-1])))[0] + 0.03, 0.52)
    for y_ax, t_label in ref_points:
        ax.text(
            x_target,
            y_ax,
            t_label,
            transform=ax.transAxes,
            ha="left",
            va="center",
            fontsize=14,
            fontweight="bold",
            color=theme_color,
            bbox=dict(facecolor="white", edgecolor="none", alpha=0.85, pad=1.6),
            zorder=6,
        )

    # 特征标签（外圈）
    band_bottom = radius_edges[-1] + 0.10
    band_height = 0.20
    label_radius = band_bottom + band_height + 0.012
    group_spans = _group_spans(feature_defs)
    group_colors = [GROUP_COLORS.get(group, "#D0D0D0") for group, _, _ in group_spans]

    for idx, ((_, feat_label, _)) in enumerate(feature_defs):
        ang = (theta_edges[idx] + theta_edges[idx + 1]) / 2
        rotation, align = _radial_text_rotation(ang, theta_offset=theta_offset, theta_direction=theta_direction)
        note = feature_notes.get(feat_label)
        text_label = f"{feat_label}" if not note else f"{feat_label} ({note})"
        ax.text(
            ang,
            label_radius,
            text_label,
            ha=align,
            va="center",
            rotation=rotation,
            rotation_mode="anchor",
            fontsize=6.7 * 1.5,
            color="#222222",
            fontweight="medium",
        )

    # 分组环（跨地貌一致的组别色）
    for color, (group, start, end) in zip(group_colors, group_spans):
        start_ang = theta_edges[start]
        end_ang = theta_edges[end]
        width = end_ang - start_ang
        center_ang = start_ang + width / 2
        ax.bar(
            x=[center_ang],
            height=[band_height],
            width=[width],
            bottom=[band_bottom],
            color=color,
            alpha=0.18,  # 更淡的背景，提升文字对比度
            edgecolor=color,
            linewidth=0.6,
            align="center",
            zorder=3,
        )
        sector_disp = abs((theta_offset + theta_direction * end_ang) - (theta_offset + theta_direction * start_ang))
        effective_chars = len([c for c in group if not c.isspace()])
        split = _split_group_label(group)
        too_tight = effective_chars > 0 and (sector_disp / effective_chars) < np.deg2rad(2.8)
        # 扇形字符贴合：组名默认放大 2 倍；极窄扇形允许略降字号并双层
        group_fontsize = 7.6 * (1.6 if too_tight else 2.0)
        if split and (too_tight or len(group) >= 16):
            top, bottom = split
            _arc_text(
                ax,
                start_ang,
                end_ang,
                band_bottom + band_height * 0.78,
                top,
                color="#333333",
                theta_offset=theta_offset,
                theta_direction=theta_direction,
                fontsize=group_fontsize,
            )
            _arc_text(
                ax,
                start_ang,
                end_ang,
                band_bottom + band_height * 0.22,
                bottom,
                color="#333333",
                theta_offset=theta_offset,
                theta_direction=theta_direction,
                fontsize=group_fontsize,
            )
        else:
            _arc_text(
                ax,
                start_ang,
                end_ang,
                band_bottom + band_height / 2,
                group,
                color="#333333",
                theta_offset=theta_offset,
                theta_direction=theta_direction,
                fontsize=group_fontsize,
            )

    ax.set_ylim(r_inner - 0.12, band_bottom + band_height + 0.26)
    ax.set_axis_off()
    ax.set_title(f"{sub_theme}: ring correlation map", y=1.05, fontsize=11, fontweight="bold", color=theme_color)

    # 颜色条
    cbar = fig.colorbar(pc, ax=ax, fraction=0.04, pad=0.1)
    cbar.set_label("Spearman r (-1 to 1)", fontsize=8)
    cbar.ax.tick_params(labelsize=7)
    cbar.outline.set_edgecolor(theme_color)

    # 说明
    fig.text(
        0.5,
        0.02,
        "Spearman ρ; categorical -> strongest dummy; gray = insufficient data; 3/4 ring",
        ha="center",
        va="center",
        fontsize=7,
        color="#4a4a4a",
    )

    fig.tight_layout()
    fig.savefig(f"{save_base}.png", dpi=style.dpi, bbox_inches="tight")
    fig.savefig(f"{save_base}.svg", dpi=style.dpi, bbox_inches="tight")
    plt.close(fig)


def _slugify(name: str) -> str:
    return "".join(ch if ch.isalnum() else "_" for ch in name).strip("_").lower()


def create_ring_charts(csv_path: str = "all_l_dimensions.csv", output_prefix: str | None = None) -> None:
    df = pd.read_csv(csv_path)
    style = apply_nature_style("double")

    out_dir, _ = auto_output_path(__file__, csv_path)
    base_prefix = output_prefix or f"{Path(csv_path).stem}_ring_corr"

    for sub_theme in SUB_THEMES:
        df_sub = df[df["Sub_Theme"] == sub_theme].copy()
        if df_sub.empty:
            print(f"[WARN] {sub_theme}: no data, skip.")
            continue
        corr_matrix, feature_notes = compute_correlation_matrix(df_sub)
        save_base = out_dir / f"{base_prefix}_{_slugify(sub_theme)}"
        plot_ring_heatmap(
            corr_matrix,
            FEATURES,
            feature_notes,
            sub_theme=sub_theme,
            style=style,
            save_base=save_base,
        )
        print(f"[OK] {sub_theme} -> {save_base}.png / .svg")


def main() -> None:
    parser = argparse.ArgumentParser(description="八类地貌的环形相关性热图（R1-R5+Gap vs 元数据/行动/深度/障碍/因果链）")
    parser.add_argument("--csv", default="all_l_dimensions.csv", help="输入CSV路径")
    parser.add_argument("--out_prefix", default=None, help="输出前缀（可选）")
    args = parser.parse_args()
    create_ring_charts(csv_path=args.csv, output_prefix=args.out_prefix)


if __name__ == "__main__":
    main()
