from __future__ import annotations

import argparse
import math
import sys
import textwrap
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from mpl_toolkits.axes_grid1.inset_locator import inset_axes

# 引入模板工具（Nature 风格与输出路径）
TEMPLATE_DIR = Path(__file__).parent / "模板"
if str(TEMPLATE_DIR) not in sys.path:
    sys.path.insert(0, str(TEMPLATE_DIR))

from config_nature import apply_nature_style  # type: ignore
from base import auto_output_path  # type: ignore

# 八类地貌
SUB_THEMES: Sequence[str] = [
    "Forests & Ecosystems",
    "Coastal Wetlands",
    "Desertification & Drylands",
    "Rivers & Deltas",
    "Karst Systems",
    "Coral Reefs & Islands",
    "Peatlands",
    "Cryosphere & Permafrost",
]

# 与雨云组图保持一致的主题色（用于面板强调，不影响相关色带）
THEME_BASE_COLORS: Dict[str, str] = {
    "Forests & Ecosystems": "#1b9e77",
    "Coastal Wetlands": "#d95f02",
    "Desertification & Drylands": "#7570b3",
    "Rivers & Deltas": "#e7298a",
    "Karst Systems": "#66a61e",
    "Coral Reefs & Islands": "#e6ab02",
    "Peatlands": "#a6761d",
    "Cryosphere & Permafrost": "#1f78b4",
}

# 分组色（跨地貌一致；用于“特征行”背景分区）
GROUP_COLORS: Dict[str, str] = {
    "Contextual Determinants": "#3C5488FF",
    "Adaptation Consistency": "#00A087FF",
    "Implementation Intensity": "#4DBBD5FF",
    "Risk & Impact Metrics": "#E64B35FF",
    "Implementation Barriers": "#F39B7FFF",
    "Mechanism Pathways": "#8491B4FF",
}

# 目标相关性：R1-R5 + Gap
TARGETS: Sequence[Tuple[str, str]] = [
    ("Scores_R1_Hazard", "R1 Hazard"),
    ("Scores_R2_Exposure", "R2 Exposure"),
    ("Scores_R3_Vulnerability", "R3 Vulnerability"),
    ("Scores_R4_Data_Gap", "R4 Data gap"),
    ("Scores_R5_Eco_Impact", "R5 Eco impact"),
    ("Scores_action_minus_risk_score", "Action–Risk gap"),
]

FeatureDef = Tuple[str, str, str]  # (column, label, group)

FEATURES: Sequence[FeatureDef] = [
    ("Metadata_Region", "Region", "Contextual Determinants"),
    ("Metadata_Income_Group", "Income group", "Contextual Determinants"),
    ("Metadata_Climate_Zone", "Climate zone", "Contextual Determinants"),
    ("Metadata_GDP_pc", "GDP per capita", "Contextual Determinants"),
    ("Metadata_Agri_Pct", "Agriculture share (%)", "Contextual Determinants"),
    ("Metadata_Industrial_Pct", "Industry share (%)", "Contextual Determinants"),
    ("Metadata_WGI_Gov", "Gov. Effectiveness (WGI)", "Contextual Determinants"),
    ("Metadata_WGI_Cor", "Control of Corruption", "Contextual Determinants"),
    ("Metadata_ND_Vul_Index", "ND Vulnerability Index", "Contextual Determinants"),
    ("Metadata_A_Doc_Year", "Assessment Year", "Contextual Determinants"),
    ("Metadata_Act_Doc_Year", "Action Year", "Contextual Determinants"),
    ("Metadata_Doc_Language", "Document Language", "Contextual Determinants"),
    ("Metadata_Pct_FullText_Description", "Text Availability (%)", "Contextual Determinants"),
    ("Scores_A1_Diagnostic", "A1: Diagnostic Consistency", "Adaptation Consistency"),
    ("Scores_A2_Integration", "A2: Policy Integration", "Adaptation Consistency"),
    ("Scores_A3_Stakeholder", "A3: Stakeholder Engagement", "Adaptation Consistency"),
    ("Scores_A4_Planning", "A4: Planning Robustness", "Adaptation Consistency"),
    ("Scores_A5_Finance", "A5: Financial Framework", "Adaptation Consistency"),
    ("Scores_Ac1_Implementation", "Ac1: Implementation Status", "Implementation Intensity"),
    ("Scores_Ac2_Governance", "Ac2: Governance Structure", "Implementation Intensity"),
    ("Scores_Ac3_Finance", "Ac3: Funding Mechanism", "Implementation Intensity"),
    ("Scores_Ac4_Monitoring", "Ac4: M&E Systems", "Implementation Intensity"),
    ("Scores_Ac5_Capacity", "Ac5: Technical Capacity", "Implementation Intensity"),
    ("Deep_Metrics_Risk_Probability_Val", "Risk Probability", "Risk & Impact Metrics"),
    ("Deep_Metrics_Exposed_Pop_Count", "Exposed Population", "Risk & Impact Metrics"),
    ("Deep_Metrics_Vul_Index_Ref", "Reference Vulnerability", "Risk & Impact Metrics"),
    ("Deep_Metrics_Risk_GDP_Loss_Pct", "Proj. GDP Loss (%)", "Risk & Impact Metrics"),
    ("Deep_Metrics_TSI_Score", "TSI Score", "Risk & Impact Metrics"),
    ("Deep_Metrics_Time_Horizon_Yrs", "Time Horizon (Years)", "Risk & Impact Metrics"),
    ("Deep_Metrics_Budget_Commit_USD", "Committed Budget (USD)", "Risk & Impact Metrics"),
    ("Deep_Metrics_PCS_Score", "PCS Score", "Risk & Impact Metrics"),
    ("Deep_Metrics_FGI_Pct", "Fin. Gap Index (%)", "Risk & Impact Metrics"),
    ("Deep_Metrics_Inv_Gap_USD", "Investment Gap (USD)", "Risk & Impact Metrics"),
    ("Barrier_Weights_Financial", "Barrier: Financial", "Implementation Barriers"),
    ("Barrier_Weights_Institutional", "Barrier: Institutional", "Implementation Barriers"),
    ("Barrier_Weights_Technical", "Barrier: Technical", "Implementation Barriers"),
    ("Barrier_Weights_Political", "Barrier: Political", "Implementation Barriers"),
    ("Barrier_Weights_Regulatory", "Barrier: Regulatory", "Implementation Barriers"),
    ("Causal_Chains_1_Chain_Type", "Risk Cascade Type", "Mechanism Pathways"),
    ("Causal_Chains_2_Chain_Type", "Barrier Mechanism", "Mechanism Pathways"),
]


def _group_spans(feature_defs: Sequence[FeatureDef]) -> List[Tuple[str, int, int]]:
    spans: List[Tuple[str, int, int]] = []
    if not feature_defs:
        return spans
    start = 0
    current = feature_defs[0][2]
    for idx, (_, _, grp) in enumerate(feature_defs):
        if grp != current:
            spans.append((current, start, idx))
            start = idx
            current = grp
    spans.append((current, start, len(feature_defs)))
    return spans


def _corr_with_feature(series_target: pd.Series, series_feat: pd.Series) -> float:
    t = pd.to_numeric(series_target, errors="coerce")
    f_raw = series_feat
    mask = t.notna() & f_raw.notna()
    t = t[mask]
    f = f_raw[mask]
    if len(t) < 6 or t.nunique() < 2:
        return math.nan

    f_num = pd.to_numeric(f, errors="coerce")
    if f_num.notna().sum() >= max(4, int(len(f) * 0.45)) and f_num.nunique() >= 2:
        return float(t.corr(f_num, method="spearman"))

    cats = f.astype(str).str.strip()
    dummies = pd.get_dummies(cats, drop_first=False)
    best = math.nan
    for col in dummies.columns:
        dummy = dummies[col]
        if dummy.sum() < 3:
            continue
        corr_val = t.corr(dummy, method="spearman")
        if pd.notna(corr_val) and (math.isnan(best) or abs(float(corr_val)) > abs(best)):
            best = float(corr_val)
    return best


def _corr_with_feature_details(series_target: pd.Series, series_feat: pd.Series) -> Dict[str, object]:
    """返回相关性+方法细节（用于导出分析表）。"""
    t = pd.to_numeric(series_target, errors="coerce")
    f_raw = series_feat
    mask = t.notna() & f_raw.notna()
    t = t[mask]
    f = f_raw[mask]
    out: Dict[str, object] = {
        "n_pairs": int(len(t)),
        "corr": math.nan,
        "method": "",
        "best_category": "",
        "best_category_n": math.nan,
        "feature_nunique": int(f.nunique()) if len(f) else 0,
        "target_nunique": int(t.nunique()) if len(t) else 0,
    }
    if len(t) < 6 or t.nunique() < 2:
        return out

    f_num = pd.to_numeric(f, errors="coerce")
    if f_num.notna().sum() >= max(4, int(len(f) * 0.45)) and f_num.nunique() >= 2:
        out["corr"] = float(t.corr(f_num, method="spearman"))
        out["method"] = "numeric_spearman"
        return out

    cats = f.astype(str).str.strip()
    dummies = pd.get_dummies(cats, drop_first=False)
    best = math.nan
    best_cat = ""
    best_n = math.nan
    for col in dummies.columns:
        dummy = dummies[col]
        support = int(dummy.sum())
        if support < 3:
            continue
        corr_val = t.corr(dummy, method="spearman")
        if pd.notna(corr_val) and (math.isnan(best) or abs(float(corr_val)) > abs(best)):
            best = float(corr_val)
            best_cat = str(col)
            best_n = support
    out["corr"] = best
    out["method"] = "categorical_best_dummy"
    out["best_category"] = best_cat
    out["best_category_n"] = best_n
    return out


def compute_matrix(df: pd.DataFrame) -> np.ndarray:
    """Return (n_features, n_targets) Spearman matrix."""
    out = np.full((len(FEATURES), len(TARGETS)), np.nan)
    for f_idx, (feat_col, _, _) in enumerate(FEATURES):
        if feat_col not in df.columns:
            continue
        for t_idx, (target_col, _) in enumerate(TARGETS):
            if target_col not in df.columns:
                continue
            out[f_idx, t_idx] = _corr_with_feature(df[target_col], df[feat_col])
    return out


def _theme_diverging_cmap(style, theme_color: str) -> mpl.colors.Colormap:
    """Per-theme diverging map: neg is desaturated+darkened theme, pos is theme."""
    ct = style.color_transform
    neg = ct.darken(ct.desaturate(theme_color, 0.75), 0.35)
    pos = ct.darken(theme_color, 0.0)
    cmap = mpl.colors.LinearSegmentedColormap.from_list("theme_corr", [neg, "#F7F7F7", pos])
    cmap.set_bad("#f0f0f0")
    return cmap


def create_horizontal_panel(csv_path: str = "all_l_dimensions.csv", output_prefix: str | None = None) -> None:
    df = pd.read_csv(csv_path)
    style = apply_nature_style("double")

    spans = _group_spans(FEATURES)
    feature_labels = [label for _, label, _ in FEATURES]
    target_labels = [label for _, label in TARGETS]

    vmin, vmax = -1.0, 1.0

    # 布局：左侧标签轴 + 8 个面板（每个面板自带色标）
    fig = plt.figure(figsize=(72.0, 20.4), dpi=style.dpi)
    gs = fig.add_gridspec(
        nrows=1,
        ncols=1 + len(SUB_THEMES),
        width_ratios=[1.25] + [1.0] * len(SUB_THEMES),
        wspace=0.01,
    )
    label_ax = fig.add_subplot(gs[0, 0])
    axes = [fig.add_subplot(gs[0, i + 1]) for i in range(len(SUB_THEMES))]

    # 左侧标签：分组 + 子变量
    label_ax.set_xlim(0, 1)
    label_ax.set_ylim(len(feature_labels) - 0.5, -0.5)
    label_ax.axis("off")
    for grp, start, end in spans:
        bg = GROUP_COLORS.get(grp, "#D0D0D0")
        label_ax.axhspan(start - 0.5, end - 0.5, color=bg, alpha=0.10, lw=0)
        label_ax.hlines(end - 0.5, 0, 1, colors="#d0d0d0", linewidth=0.7)
        y_center = (start + end - 1) / 2
        grp_wrapped = textwrap.fill(grp, width=18)
        label_ax.text(
            0.42,
            y_center,
            grp_wrapped,
            ha="right",
            va="center",
            fontsize=6,
            fontweight="bold",
            color="#222222",
        )
        for row in range(start, end):
            label_ax.text(
                0.98,
                row,
                feature_labels[row],
                ha="right",
                va="center",
                fontsize=6,
                rotation=32,
                color="#222222",
            )

    im = None
    for ax, theme in zip(axes, SUB_THEMES):
        sub = df[df["Sub_Theme"] == theme].copy()
        mat = compute_matrix(sub)

        # 背景分组淡色
        for grp, start, end in spans:
            color = GROUP_COLORS.get(grp, "#D0D0D0")
            ax.axhspan(start - 0.5, end - 0.5, color=color, alpha=0.07, lw=0)
            ax.hlines(end - 0.5, -0.5, len(TARGETS) - 0.5, colors="#d0d0d0", linewidth=0.6)

        theme_color = THEME_BASE_COLORS.get(theme, "#333333")
        cmap = _theme_diverging_cmap(style, theme_color)
        im = ax.imshow(
            mat,
            aspect="auto",
            cmap=cmap,
            vmin=vmin,
            vmax=vmax,
            interpolation="nearest",
            origin="upper",
        )

        # x 轴：targets
        ax.set_xticks(range(len(target_labels)))
        ax.set_xticklabels(target_labels, rotation=45, ha="right", fontsize=6)
        ax.tick_params(axis="x", length=0, pad=1)

        ax.set_yticks(range(len(feature_labels)))
        ax.set_yticklabels([])
        ax.tick_params(axis="y", length=0)

        # 面板强调（主题色标题 + 框）
        ax.set_title(theme, fontsize=6, fontweight="bold", color=theme_color, pad=8)
        for spine in ax.spines.values():
            spine.set_visible(True)
            spine.set_linewidth(1.0)
            spine.set_edgecolor(mpl.colors.to_hex(mpl.colors.to_rgb(theme_color)))

        # 轻量网格：白色细边界
        ax.set_xlim(-0.5, len(target_labels) - 0.5)
        ax.set_ylim(len(feature_labels) - 0.5, -0.5)
        for x in range(len(target_labels) + 1):
            ax.vlines(x - 0.5, -0.5, len(feature_labels) - 0.5, colors="white", linewidth=0.5, alpha=0.9)
        for y in range(len(feature_labels) + 1):
            ax.hlines(y - 0.5, -0.5, len(target_labels) - 0.5, colors="white", linewidth=0.4, alpha=0.9)

        # 每个地貌面板下侧绘制各自的色标（与该面板 cmap 一致）
        cax_inset = inset_axes(
            ax,
            width="100%",
            height="3.6%",
            loc="lower left",
            bbox_to_anchor=(0.0, -0.15, 1.0, 1.0),
            bbox_transform=ax.transAxes,
            borderpad=0,
        )
        sm = mpl.cm.ScalarMappable(norm=mpl.colors.Normalize(vmin=vmin, vmax=vmax), cmap=cmap)
        sm.set_array([])
        cbar = fig.colorbar(sm, cax=cax_inset, orientation="horizontal")
        cbar.set_ticks([-1.0, 0.0, 1.0])
        cbar.ax.tick_params(labelsize=6, length=2, pad=1)
        cbar.outline.set_linewidth(0.6)

    fig.suptitle("Eight geomorphologies: correlation heatmaps (Spearman ρ)", fontsize=6, y=1.02)
    fig.subplots_adjust(left=0.012, right=0.99, top=0.9, bottom=0.175, wspace=0.01)

    out_dir, _ = auto_output_path(__file__, csv_path)
    prefix = output_prefix or f"{Path(csv_path).stem}_geomorph_corr_heatmap_row"
    save_base = out_dir / prefix
    save_base.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(f"{save_base}.png", dpi=style.dpi, bbox_inches="tight")
    fig.savefig(f"{save_base}.svg", dpi=style.dpi, bbox_inches="tight")
    plt.close(fig)
    print(f"[SUCCESS] Saved: {save_base}.png and .svg")

    # 额外导出：逐地貌×逐特征×逐目标的相关性长表（含方法/样本量/最佳类别）
    rows: List[Dict[str, object]] = []
    for theme in SUB_THEMES:
        sub = df[df["Sub_Theme"] == theme].copy()
        for feat_col, feat_label, feat_group in FEATURES:
            if feat_col not in sub.columns:
                continue
            for target_col, target_label in TARGETS:
                if target_col not in sub.columns:
                    continue
                details = _corr_with_feature_details(sub[target_col], sub[feat_col])
                rows.append(
                    dict(
                        sub_theme=theme,
                        feature_col=feat_col,
                        feature_label=feat_label,
                        feature_group=feat_group,
                        target_col=target_col,
                        target_label=target_label,
                        corr=details.get("corr"),
                        n_pairs=details.get("n_pairs"),
                        method=details.get("method"),
                        best_category=details.get("best_category"),
                        best_category_n=details.get("best_category_n"),
                        feature_nunique=details.get("feature_nunique"),
                        target_nunique=details.get("target_nunique"),
                    )
                )
    if rows:
        pd.DataFrame(rows).to_csv(f"{save_base}_data.csv", index=False, encoding="utf-8-sig")
        print(f"[SUCCESS] Data exported: {save_base}_data.csv")


def main() -> None:
    parser = argparse.ArgumentParser(description="八个地貌拼接的横向相关性热力图（普通矩形版）")
    parser.add_argument("--csv", default="all_l_dimensions.csv", help="输入CSV路径")
    parser.add_argument("--out_prefix", default=None, help="输出前缀（可选）")
    args = parser.parse_args()
    create_horizontal_panel(csv_path=args.csv, output_prefix=args.out_prefix)


if __name__ == "__main__":
    main()
