"""
生成三个因果机制的桑基图（Risk_Cascade / Barrier_Mechanism / Transboundary_Spillover）。

左侧：驱动/障碍节点（按出现频次截断，并将低频合并为 Other）。
中间：8 类地貌。
右侧：结果/影响节点（同样截断合并）。

用法示例：
    .venv/Scripts/python.exe 机制桑基图.py --csv all_l_dimensions.csv --outdir outputs
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import pandas as pd
import plotly.graph_objects as go


# 三类机制的固定顺序，便于控制输出文件名与色调
CHAIN_ORDER: Sequence[str] = [
    "Risk_Cascade",
    "Barrier_Mechanism",
    "Transboundary_Spillover",
]

# 地貌顺序与配色（柔和、低饱和度，贴近 Nature 风格）
LANDFORM_ORDER: Sequence[str] = [
    "Forests & Ecosystems",
    "Coastal Wetlands",
    "Desertification & Drylands",
    "Rivers & Deltas",
    "Karst Systems",
    "Coral Reefs & Islands",
    "Peatlands",
    "Cryosphere & Permafrost",
]

LANDFORM_COLORS: Dict[str, str] = {
    "Forests & Ecosystems": "#4c9f70",
    "Coastal Wetlands": "#2a9d8f",
    "Desertification & Drylands": "#c9a227",
    "Rivers & Deltas": "#4d6c9c",
    "Karst Systems": "#7e6b8f",
    "Coral Reefs & Islands": "#d97192",
    "Peatlands": "#7ca35c",
    "Cryosphere & Permafrost": "#76b7e8",
}

# 8个地貌的 Nature 样式基础色（来自地貌三维度雨云组图）
THEME_BASE_COLORS: Dict[str, str] = {
    "Forests & Ecosystems": "#1b9e77",
    "Coastal Wetlands": "#d95f02",
    "Desertification & Drylands": "#7570b3",
    "Rivers & Deltas": "#e7298a",
    "Karst Systems": "#66a61e",
    "Coral Reefs & Islands": "#e6ab02",
    "Peatlands": "#a6761d",
    "Cryosphere & Permafrost": "#1f78b4",
}

# 每类机制的基准色（用于左侧节点与链接）
CHAIN_ACCENT: Dict[str, str] = {
    "Risk_Cascade": "#b45f06",           # 琥珀橙
    "Barrier_Mechanism": "#0f766e",      # 墨绿蓝
    "Transboundary_Spillover": "#5a4fcf",  # 靛紫
}

CHAIN_LABEL: Dict[str, str] = {
    "Risk_Cascade": "Risk",
    "Barrier_Mechanism": "Barrier",
    "Transboundary_Spillover": "Spillover",
}

# 结果节点颜色基调（右侧）
EFFECT_BASE = "#344e5c"

# 常见节点同义词归并（小写键）
CAUSE_ALIAS: Dict[str, str] = {
    "drought/heat": "Drought",
    "extreme heat": "Heatwave",
    "glacier melt": "Glacier Melt",
    "sea-level rise": "Sea Level Rise",
    "sea level rise": "Sea Level Rise",
    "sea level rise (slr)": "Sea Level Rise",
    "coastal erosion": "Coastal Erosion",
    "storm surge": "Storm Surge",
    "data gap": "Lack of Data",
    "data gaps": "Lack of Data",
    "lack of data": "Lack of Data",
    "funding gap": "Funding Gap",
    "finance gap": "Funding Gap",
    "financial gap": "Funding Gap",
    "institutional fragmentation": "Institutional Fragmentation",
    "weak governance": "Institutional Fragmentation",
}

EFFECT_ALIAS: Dict[str, str] = {
    "ecological collapse": "Ecological Collapse",
    "biodiversity loss": "Biodiversity Loss",
    "coral bleaching": "Coral Bleaching",
    "coastal erosion": "Coastal Erosion",
    "soil erosion": "Soil Erosion",
    "soil degradation": "Soil Degradation",
    "forest degradation": "Forest Degradation",
    "forest loss": "Forest Cover Loss",
    "forest cover loss": "Forest Cover Loss",
    "implementation delay": "Implementation Delay",
    "project failure": "Project Failure",
    "marine protection failure": "Marine Protection",
}

# 手工挑选的可视化白名单（可选，用于进一步压缩节点；默认关闭）
CAUSE_WHITELIST: Dict[str, Sequence[str]] = {
    "Risk_Cascade": [
        "Sea Level Rise",
        "Drought",
        "Extreme Rainfall",
        "Extreme Precipitation",
        "Ocean Warming/Acidification",
        "Deforestation",
        "Land Degradation",
        "Warming",
    ],
    "Barrier_Mechanism": [
        "Funding Gap",
        "Institutional Fragmentation",
        "Lack of Data",
        "Weak Enforcement",
        "Development Pressure",
        "Technical Capacity",
        "Investment Gap",
        "Knowledge Gap",
    ],
    "Transboundary_Spillover": [
        "Glacier Melt",
        "Upstream Flow Change",
        "Upstream River Management",
        "Regional Drought",
        "Development Aid",
    ],
}

EFFECT_WHITELIST: Dict[str, Sequence[str]] = {
    "Risk_Cascade": [
        "Coral Bleaching",
        "Coastal Erosion",
        "Soil Erosion",
        "Biodiversity Loss",
        "Soil Degradation",
        "Forest Fires",
        "Mangrove Loss",
        "Water Scarcity",
        "Desertification",
    ],
    "Barrier_Mechanism": [
        "Sustainable Forest Management",
        "Forest Management",
        "Reforestation Targets",
        "Forest Conservation",
        "Marine Protection",
        "Peatland Restoration",
        "Wetland Conservation",
        "Sustainable Land Management",
        "Restoration Targets",
    ],
    "Transboundary_Spillover": [
        "Regional Water Security",
        "Water Availability",
        "Water Security",
        "Water Insecurity",
        "Riparian Relations",
        "Transboundary Inflow",
        "Bangladesh River Flow",
        "India Hydropower/Irrigation",
    ],
}


def apply_alias(name: str, alias_map: Dict[str, str]) -> str:
    key = (name or "").strip()
    low = key.lower()
    return alias_map.get(low, key)


def map_with_rules(name: str, rules: Sequence[Tuple[str, Sequence[str]]], default_label: str) -> str:
    low = name.lower()
    for label, keys in rules:
        if any(k in low for k in keys):
            return label
    return default_label


# 归类规则：尽量将长尾归入有限类别，保证覆盖但减少节点
CAUSE_RULES: Dict[str, Sequence[Tuple[str, Sequence[str]]]] = {
    "Risk_Cascade": [
        ("Coastal hazards / SLR", ["sea level", "storm surge", "coastal"]),
        ("Drought / aridity", ["drought", "arid", "desert"]),
        ("Extreme rain / flood", ["rain", "precipitation", "flood"]),
        ("Ocean warming / acidification", ["ocean warming", "sea temperature", "acidification", "marine heat"]),
        ("Heat / temperature rise", ["warming", "heat", "temperature"]),
        ("Land-use change / degradation", ["deforestation", "land degradation", "agricultur", "urban", "overgrazing"]),
        ("Cryosphere melt", ["glacier", "glacial", "snow", "permafrost"]),
        ("Water scarcity / overuse", ["water scarcity", "water stress", "withdrawal"]),
        ("Climate change (general)", ["climate change"]),
    ],
    "Barrier_Mechanism": [
        ("Funding / finance gap", ["funding", "finance", "investment", "budget", "resources", "lack of financial"]),
        ("Institutional fragmentation / governance", ["institutional", "governance", "fragment", "complexity"]),
        ("Data / knowledge / technical gap", ["data", "knowledge", "technical", "capacity"]),
        ("Regulation / enforcement", ["enforcement", "regulation", "code", "policy"]),
        ("Socio-economic pressure", ["pressure", "agri", "expansion", "development", "sprawl", "dependence", "pollution"]),
        ("Energy / biomass reliance", ["biomass", "energy"]),
        ("Conflict / instability", ["conflict", "occupation", "boko haram"]),
        ("Environmental constraint", ["harsh", "volcanic", "drought"]),
    ],
    "Transboundary_Spillover": [
        ("Upstream dams / flow change", ["upstream", "dam", "flow", "release", "withdrawal"]),
        ("Glacier melt / cryosphere", ["glacier", "glacial", "snow", "pamir", "tien shan"]),
        ("Regional drought / rainfall shift", ["drought", "rainfall", "precip"]),
        ("Upstream land use / pollution", ["land use", "deforestation", "pollution", "nutrient"]),
        ("External policy / market", ["aid", "regulation", "export", "market"]),
        ("Global warming (generic)", ["global warming"]),
    ],
}

EFFECT_RULES: Dict[str, Sequence[Tuple[str, Sequence[str]]]] = {
    "Risk_Cascade": [
        ("Coastal impacts / salinization", ["coastal", "salin"]),
        ("Soil / land degradation", ["soil", "land degradation", "desertification", "erosion"]),
        ("Water scarcity / depletion", ["water scarcity", "groundwater", "depletion", "insecurity", "water crisis"]),
        ("Biodiversity / ecosystem loss", ["biodiversity", "mangrove", "reef", "coral", "ecosystem"]),
        ("Fire risk / wildfire", ["fire"]),
        ("Flooding / inundation", ["flood", "inundation"]),
        ("Food / fisheries impact", ["food", "crop", "fisheries"]),
        ("Economic loss / gdp", ["gdp", "economic"]),
        ("Carbon sink decline", ["carbon sink"]),
    ],
    "Barrier_Mechanism": [
        ("Forest / land management shortfall", ["forest", "land", "afforestation", "reforestation", "regeneration"]),
        ("Restoration targets", ["restoration", "rehabilitation", "regeneration"]),
        ("Conservation / protection", ["conservation", "protection", "ghg inventory", "equitable allocation"]),
        ("Marine / coastal management", ["marine", "coastal", "reef", "mangrove"]),
        ("Water management", ["water", "aquifer", "watershed"]),
        ("Infrastructure / storage", ["infrastructure", "storage"]),
    ],
    "Transboundary_Spillover": [
        ("Downstream water security", ["water security", "water availability", "water inflow", "hydrology", "flow"]),
        ("Hydropower / energy", ["hydro", "energy"]),
        ("Agriculture / food / trade", ["agric", "export", "market", "trade"]),
        ("Ecosystem / marine impact", ["ecosystem", "reef", "sea"]),
        ("Conflict / migration", ["conflict", "migration"]),
    ],
}



def mix_with_white(hex_color: str, ratio: float) -> str:
    """将颜色与白色混合，ratio 越大越浅，范围 0~1。"""
    hex_color = hex_color.lstrip("#")
    r, g, b = int(hex_color[0:2], 16), int(hex_color[2:4], 16), int(hex_color[4:6], 16)
    r = int(r + (255 - r) * ratio)
    g = int(g + (255 - g) * ratio)
    b = int(b + (255 - b) * ratio)
    return f"#{r:02x}{g:02x}{b:02x}"


def hex_to_rgba(hex_color: str, alpha: float) -> str:
    hex_color = hex_color.lstrip("#")
    r, g, b = int(hex_color[0:2], 16), int(hex_color[2:4], 16), int(hex_color[4:6], 16)
    return f"rgba({r},{g},{b},{alpha})"


def extract_chains(df: pd.DataFrame) -> pd.DataFrame:
    """将链条列转为行，方便后续分组。"""
    records: List[Tuple[str, str, str, str]] = []
    for suffix in (1, 2):
        chain_col = f"Causal_Chains_{suffix}_Chain_Type"
        cause_col = f"Causal_Chains_{suffix}_Cause_Node"
        effect_col = f"Causal_Chains_{suffix}_Effect_Node"
        for _, row in df.iterrows():
            chain = row.get(chain_col)
            cause = row.get(cause_col)
            effect = row.get(effect_col)
            landform = row.get("Sub_Theme")
            if pd.isna(chain) or pd.isna(cause) or pd.isna(effect) or pd.isna(landform):
                continue
            cause_norm = apply_alias(str(cause), CAUSE_ALIAS)
            effect_norm = apply_alias(str(effect), EFFECT_ALIAS)
            chain_name = str(chain)
            cause_cat = map_with_rules(
                cause_norm,
                CAUSE_RULES.get(chain_name, []),
                default_label="Other drivers",
            )
            effect_cat = map_with_rules(
                effect_norm,
                EFFECT_RULES.get(chain_name, []),
                default_label="Other outcomes",
            )
            records.append((chain_name, cause_cat, effect_cat, str(landform)))

    return pd.DataFrame(records, columns=["chain_type", "cause", "effect", "landform"])


def prepare_chain_tables(
    chains_df: pd.DataFrame,
    chain_type: str,
    max_causes: int,
    max_effects: int,
    min_count: int,
    collapse: bool,
    use_whitelist: bool,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, List[str], List[str], List[str], List[str], List[int], List[int], List[int], float, int]:
    """返回用于绘图与导出的中间表与节点/链接结构。"""
    subset = chains_df[chains_df["chain_type"] == chain_type].copy()
    if subset.empty:
        return (
            subset,
            pd.DataFrame(columns=["cause_group", "landform", "value"]),
            pd.DataFrame(columns=["landform", "effect_group", "value"]),
            [],
            [],
            [],
            [],
            [],
            [],
            [],
            0.0,
            0,
        )

    # 应用可视化白名单，去掉长尾；保留 coverage 信息
    if use_whitelist:
        cause_keep = set(CAUSE_WHITELIST.get(chain_type, []))
        effect_keep = set(EFFECT_WHITELIST.get(chain_type, []))
        if cause_keep:
            subset = subset[subset["cause"].isin(cause_keep)]
        if effect_keep:
            subset = subset[subset["effect"].isin(effect_keep)]
    if subset.empty:
        return (
            subset,
            pd.DataFrame(columns=["cause_group", "landform", "value"]),
            pd.DataFrame(columns=["landform", "effect_group", "value"]),
            [],
            [],
            [],
            [],
            [],
            [],
            [],
            0.0,
            0,
        )

    total_links = len(subset)
    cause_counts = subset["cause"].value_counts()
    effect_counts = subset["effect"].value_counts()

    # 根据开关决定是否合并尾部
    if collapse:
        cause_top = cause_counts[cause_counts >= min_count].head(max_causes).index.tolist()
        effect_top = effect_counts[effect_counts >= min_count].head(max_effects).index.tolist()
        subset["cause_group"] = subset["cause"].where(subset["cause"].isin(cause_top), "Other drivers")
        subset["effect_group"] = subset["effect"].where(subset["effect"].isin(effect_top), "Other outcomes")
    else:
        # 不合并时，只依据最小频次过滤
        cause_top = cause_counts[cause_counts >= min_count].index.tolist()
        effect_top = effect_counts[effect_counts >= min_count].index.tolist()
        subset = subset[subset["cause"].isin(cause_top) & subset["effect"].isin(effect_top)]
        subset["cause_group"] = subset["cause"]
        subset["effect_group"] = subset["effect"]

    # cause -> landform
    flow_cl = subset.groupby(["cause_group", "landform"]).size().reset_index(name="value")
    # landform -> effect
    flow_le = subset.groupby(["landform", "effect_group"]).size().reset_index(name="value")

    causes = flow_cl["cause_group"].unique().tolist()
    landforms = [lf for lf in LANDFORM_ORDER if lf in subset["landform"].unique()]
    effects = flow_le["effect_group"].unique().tolist()

    labels: List[str] = causes + landforms + effects
    label_to_idx = {label: idx for idx, label in enumerate(labels)}

    sources: List[int] = []
    targets: List[int] = []
    values: List[int] = []

    for _, row in flow_cl.iterrows():
        sources.append(label_to_idx[row["cause_group"]])
        targets.append(label_to_idx[row["landform"]])
        values.append(int(row["value"]))

    for _, row in flow_le.iterrows():
        sources.append(label_to_idx[row["landform"]])
        targets.append(label_to_idx[row["effect_group"]])
        values.append(int(row["value"]))

    kept_links = sum(values)
    coverage = kept_links / total_links if total_links else 0.0

    return subset, flow_cl, flow_le, labels, causes, landforms, effects, sources, targets, values, coverage, total_links


def aggregate_flows(
    chains_df: pd.DataFrame,
    chain_type: str,
    max_causes: int,
    max_effects: int,
    min_count: int,
    collapse: bool,
    use_whitelist: bool,
) -> Tuple[List[str], List[str], List[str], List[int], List[int], List[int], float, int]:
    """返回 Plotly 所需的节点标签与链接索引。"""
    subset, _flow_cl, _flow_le, labels, causes, landforms, effects, sources, targets, values, coverage, total_links = prepare_chain_tables(
        chains_df,
        chain_type,
        max_causes,
        max_effects,
        min_count,
        collapse=collapse,
        use_whitelist=use_whitelist,
    )
    if subset.empty:
        return [], [], [], [], [], [], 0.0, 0
    return labels, causes, landforms, effects, sources, targets, values, coverage, total_links


def make_colors(labels: List[str], causes: List[str], landforms: List[str], chain_type: str) -> List[str]:
    colors: List[str] = []
    for label in labels:
        if label in causes:
            # 左侧节点做阶梯式变浅，避免单色黏连
            idx = causes.index(label)
            lighten_ratio = min(0.35, 0.08 * idx)
            colors.append(mix_with_white(CHAIN_ACCENT[chain_type], lighten_ratio))
        elif label in landforms:
            colors.append(LANDFORM_COLORS.get(label, "#9aa5b1"))
        else:
            colors.append(mix_with_white(EFFECT_BASE, 0.2))
    return colors


def build_sankey_figure(
    labels: List[str],
    causes: List[str],
    landforms: List[str],
    effects: List[str],
    sources: List[int],
    targets: List[int],
    values: List[int],
    chain_type: str,
    coverage: float,
    total_links: int,
) -> go.Figure:
    if not labels:
        return go.Figure()

    # 为标签附上计数，方便读者理解权重
    node_sum: Dict[str, int] = {}
    for s, t, v in zip(sources, targets, values):
        node_sum[labels[s]] = node_sum.get(labels[s], 0) + v
        node_sum[labels[t]] = node_sum.get(labels[t], 0) + v

    display_labels = [
        f"{label} ({node_sum.get(label, 0)})" if node_sum.get(label, 0) > 0 else label
        for label in labels
    ]

    node_colors = make_colors(labels, causes, landforms, chain_type)
    link_colors: List[str] = []
    for s in sources:
        base = node_colors[s]
        link_colors.append(hex_to_rgba(base, 0.42))

    fig = go.Figure(
        go.Sankey(
            arrangement="snap",
            node=dict(
                pad=18,
                thickness=16,
                line=dict(color="#f5f5f5", width=0.5),
                label=display_labels,
                color=node_colors,
            ),
            link=dict(
                source=sources,
                target=targets,
                value=values,
                color=link_colors,
            ),
            orientation="h",
            valueformat=",.0f",
        )
    )

    fig.update_layout(
        font=dict(family="Arial, Helvetica, sans-serif", size=14, color="#1f1f1f"),
        margin=dict(l=20, r=20, t=36, b=20),
        width=1100,
        height=620,
        paper_bgcolor="white",
        plot_bgcolor="white",
        title=dict(
            text=(
                f"{chain_type.replace('_', ' ')} "
                f"(mechanism → landform → outcome) • "
                f"coverage {coverage*100:.1f}% of {total_links} links"
            ),
            x=0.02,
            y=0.97,
            font=dict(size=16, color="#111111"),
        ),
    )
    return fig


def aggregate_composite(
    chains_df: pd.DataFrame,
    max_causes: int,
    max_effects: int,
    min_count: int,
    collapse: bool,
    use_whitelist: bool,
) -> Tuple[List[str], List[int], List[int], List[int]]:
    """聚合为“地貌 → 机制原因 → 结果”的综合桑基图。"""
    landforms = [lf for lf in LANDFORM_ORDER if lf in chains_df["landform"].unique()]
    if not landforms:
        return [], [], [], []

    labels: List[str] = []
    colors: List[str] = []
    sources: List[int] = []
    targets: List[int] = []
    values: List[int] = []

    def add_node(label: str, color: str) -> int:
        if label not in labels:
            labels.append(label)
            colors.append(color)
        return labels.index(label)

    # 先放入地貌节点（左侧）
    landform_idx: Dict[str, int] = {}
    for lf in landforms:
        landform_idx[lf] = add_node(lf, THEME_BASE_COLORS.get(lf, "#8a8a8a"))

    # 针对三类机制分别处理中间/右侧节点
    for chain_type in CHAIN_ORDER:
        subset = chains_df[chains_df["chain_type"] == chain_type].copy()
        if subset.empty:
            continue
        if use_whitelist:
            cause_keep = set(CAUSE_WHITELIST.get(chain_type, []))
            effect_keep = set(EFFECT_WHITELIST.get(chain_type, []))
            if cause_keep:
                subset = subset[subset["cause"].isin(cause_keep)]
            if effect_keep:
                subset = subset[subset["effect"].isin(effect_keep)]
        if subset.empty:
            continue

        cause_counts = subset["cause"].value_counts()
        effect_counts = subset["effect"].value_counts()
        if collapse:
            cause_top = cause_counts[cause_counts >= min_count].head(max_causes).index.tolist()
            effect_top = effect_counts[effect_counts >= min_count].head(max_effects).index.tolist()
            subset["cause_group"] = subset["cause"].where(subset["cause"].isin(cause_top), "Other drivers")
            subset["effect_group"] = subset["effect"].where(subset["effect"].isin(effect_top), "Other outcomes")
        else:
            cause_top = cause_counts[cause_counts >= min_count].index.tolist()
            effect_top = effect_counts[effect_counts >= min_count].index.tolist()
            subset = subset[subset["cause"].isin(cause_top) & subset["effect"].isin(effect_top)]
            subset["cause_group"] = subset["cause"]
            subset["effect_group"] = subset["effect"]
        if subset.empty:
            continue

        flow_lc = subset.groupby(["landform", "cause_group"]).size().reset_index(name="value")
        flow_ce = subset.groupby(["cause_group", "effect_group"]).size().reset_index(name="value")

        # 为该机制的 cause/effect 节点分配颜色与索引
        cause_groups = flow_lc["cause_group"].unique().tolist()
        effect_groups = flow_ce["effect_group"].unique().tolist()
        cause_idx: Dict[str, int] = {}
        effect_idx: Dict[str, int] = {}
        for i, cg in enumerate(cause_groups):
            label = f"{CHAIN_LABEL.get(chain_type, chain_type)} · {cg}"
            lighten_ratio = min(0.42, 0.08 * i)
            color = mix_with_white(CHAIN_ACCENT[chain_type], lighten_ratio)
            cause_idx[cg] = add_node(label, color)
        for j, eg in enumerate(effect_groups):
            label = f"{CHAIN_LABEL.get(chain_type, chain_type)} · {eg}"
            lighten_ratio = 0.35 + 0.04 * j
            color = mix_with_white(CHAIN_ACCENT[chain_type], min(0.65, lighten_ratio))
            effect_idx[eg] = add_node(label, color)

        for _, row in flow_lc.iterrows():
            lf = row["landform"]
            cg = row["cause_group"]
            if lf not in landform_idx or cg not in cause_idx:
                continue
            sources.append(landform_idx[lf])
            targets.append(cause_idx[cg])
            values.append(int(row["value"]))

        for _, row in flow_ce.iterrows():
            cg = row["cause_group"]
            eg = row["effect_group"]
            if cg not in cause_idx or eg not in effect_idx:
                continue
            sources.append(cause_idx[cg])
            targets.append(effect_idx[eg])
            values.append(int(row["value"]))

    return labels, colors, sources, targets, values


def build_composite_figure(
    labels: List[str],
    colors: List[str],
    sources: List[int],
    targets: List[int],
    values: List[int],
) -> go.Figure:
    if not labels:
        return go.Figure()

    fig = go.Figure(
        go.Sankey(
            arrangement="snap",
            node=dict(
                pad=28,
                thickness=18,
                line=dict(color="#ffffff", width=0.8),
                label=labels,
                color=colors,
            ),
            link=dict(
                source=sources,
                target=targets,
                value=values,
                color=[hex_to_rgba(colors[s], 0.32) for s in sources],
            ),
            orientation="h",
            valueformat=",.0f",
        )
    )

    fig.update_traces(textfont=dict(size=12, color="#111111"))
    fig.update_layout(
        font=dict(family="Arial, Helvetica, sans-serif", size=13, color="#1f1f1f"),
        margin=dict(l=24, r=24, t=50, b=24),
        width=1280,
        height=760,
        paper_bgcolor="white",
        plot_bgcolor="white",
        title=dict(
            text="Landform → Mechanism causes → Outcomes (composite)",
            x=0.02,
            y=0.96,
            font=dict(size=18, color="#111111"),
        ),
    )
    return fig


def main() -> None:
    parser = argparse.ArgumentParser(description="生成三类机制的桑基图")
    parser.add_argument("--csv", type=str, default="all_l_dimensions.csv", help="源数据 CSV 路径")
    parser.add_argument("--outdir", type=str, default="outputs", help="输出目录")
    parser.add_argument("--max-causes", type=int, default=10, help="左侧节点保留的最大数目，其余合并为 Other drivers（关闭合并时忽略）")
    parser.add_argument("--max-effects", type=int, default=10, help="右侧节点保留的最大数目，其余合并为 Other outcomes（关闭合并时忽略）")
    parser.add_argument("--min-count", type=int, default=1, help="节点最小出现频次，低于该值可被过滤或并入 Other")
    parser.add_argument("--no-collapse", action="store_true", help="关闭合并模式：只按 min-count 过滤，保留其余具体名称")
    parser.add_argument("--use-whitelist", action="store_true", help="启用手工白名单进一步压缩节点（默认关闭以保持全量覆盖）")
    parser.add_argument("--composite", action="store_true", help="额外输出综合桑基图（地貌 → 机制原因 → 结果）")
    args = parser.parse_args()

    csv_path = Path(args.csv)
    if not csv_path.exists():
        raise FileNotFoundError(f"找不到数据文件：{csv_path}")

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(csv_path)
    chains_df = extract_chains(df)

    # 收集所有数据的列表
    all_data_rows: List[Dict] = []

    for chain_type in CHAIN_ORDER:
        subset, flow_cl, flow_le, labels, causes, landforms, effects, sources, targets, values, coverage, total_links = prepare_chain_tables(
            chains_df,
            chain_type,
            args.max_causes,
            args.max_effects,
            args.min_count,
            collapse=not args.no_collapse,
            use_whitelist=args.use_whitelist,
        )
        fig = build_sankey_figure(
            labels, causes, landforms, effects, sources, targets, values, chain_type, coverage, total_links
        )
        png_path = outdir / f"{chain_type}_sankey.png"
        svg_path = outdir / f"{chain_type}_sankey.svg"
        fig.write_image(png_path, format="png", scale=2)
        fig.write_image(svg_path, format="svg")
        print(f"[saved] {png_path}")
        print(f"[saved] {svg_path}")

        # 构建节点类型判断函数
        def _ntype(label: str) -> str:
            if label in causes:
                return "cause"
            if label in landforms:
                return "landform"
            return "effect"

        # 收集节点数据
        if labels:
            node_sum: Dict[str, int] = {}
            for s, t, v in zip(sources, targets, values):
                node_sum[labels[s]] = node_sum.get(labels[s], 0) + int(v)
                node_sum[labels[t]] = node_sum.get(labels[t], 0) + int(v)
            node_colors = make_colors(labels, causes, landforms, chain_type)
            for i, lab in enumerate(labels):
                all_data_rows.append({
                    "sheet_type": "nodes",
                    "chain_type": chain_type,
                    "node_index": i,
                    "label": lab,
                    "node_type": _ntype(lab),
                    "value": int(node_sum.get(lab, 0)),
                    "color": node_colors[i],
                    "source_index": None,
                    "target_index": None,
                    "source_label": None,
                    "target_label": None,
                    "source_type": None,
                    "target_type": None,
                    "flow_from": None,
                    "flow_to": None,
                    "flow_value": None,
                    "cause": None,
                    "effect": None,
                    "landform": None,
                    "total_links": None,
                    "kept_links": None,
                    "coverage": None,
                    "collapse": None,
                    "use_whitelist": None,
                    "max_causes": None,
                    "max_effects": None,
                    "min_count": None,
                })

            # 收集链接数据
            for s, t, v in zip(sources, targets, values):
                all_data_rows.append({
                    "sheet_type": "links",
                    "chain_type": chain_type,
                    "node_index": None,
                    "label": None,
                    "node_type": None,
                    "value": int(v),
                    "color": None,
                    "source_index": int(s),
                    "target_index": int(t),
                    "source_label": labels[int(s)],
                    "target_label": labels[int(t)],
                    "source_type": _ntype(labels[int(s)]),
                    "target_type": _ntype(labels[int(t)]),
                    "flow_from": None,
                    "flow_to": None,
                    "flow_value": None,
                    "cause": None,
                    "effect": None,
                    "landform": None,
                    "total_links": None,
                    "kept_links": None,
                    "coverage": None,
                    "collapse": None,
                    "use_whitelist": None,
                    "max_causes": None,
                    "max_effects": None,
                    "min_count": None,
                })

        # 收集流数据 (cause -> landform)
        if not flow_cl.empty:
            for _, row in flow_cl.iterrows():
                all_data_rows.append({
                    "sheet_type": "flow_cl",
                    "chain_type": chain_type,
                    "node_index": None,
                    "label": None,
                    "node_type": None,
                    "value": None,
                    "color": None,
                    "source_index": None,
                    "target_index": None,
                    "source_label": None,
                    "target_label": None,
                    "source_type": None,
                    "target_type": None,
                    "flow_from": row["cause_group"],
                    "flow_to": row["landform"],
                    "flow_value": int(row["value"]),
                    "cause": None,
                    "effect": None,
                    "landform": None,
                    "total_links": None,
                    "kept_links": None,
                    "coverage": None,
                    "collapse": None,
                    "use_whitelist": None,
                    "max_causes": None,
                    "max_effects": None,
                    "min_count": None,
                })

        # 收集流数据 (landform -> effect)
        if not flow_le.empty:
            for _, row in flow_le.iterrows():
                all_data_rows.append({
                    "sheet_type": "flow_le",
                    "chain_type": chain_type,
                    "node_index": None,
                    "label": None,
                    "node_type": None,
                    "value": None,
                    "color": None,
                    "source_index": None,
                    "target_index": None,
                    "source_label": None,
                    "target_label": None,
                    "source_type": None,
                    "target_type": None,
                    "flow_from": row["landform"],
                    "flow_to": row["effect_group"],
                    "flow_value": int(row["value"]),
                    "cause": None,
                    "effect": None,
                    "landform": None,
                    "total_links": None,
                    "kept_links": None,
                    "coverage": None,
                    "collapse": None,
                    "use_whitelist": None,
                    "max_causes": None,
                    "max_effects": None,
                    "min_count": None,
                })

        # 收集原始记录数据
        if not subset.empty:
            for _, row in subset.iterrows():
                all_data_rows.append({
                    "sheet_type": "records",
                    "chain_type": chain_type,
                    "node_index": None,
                    "label": None,
                    "node_type": None,
                    "value": None,
                    "color": None,
                    "source_index": None,
                    "target_index": None,
                    "source_label": None,
                    "target_label": None,
                    "source_type": None,
                    "target_type": None,
                    "flow_from": None,
                    "flow_to": None,
                    "flow_value": None,
                    "cause": row.get("cause", None),
                    "effect": row.get("effect", None),
                    "landform": row.get("landform", None),
                    "total_links": None,
                    "kept_links": None,
                    "coverage": None,
                    "collapse": None,
                    "use_whitelist": None,
                    "max_causes": None,
                    "max_effects": None,
                    "min_count": None,
                })

        # 收集元数据
        all_data_rows.append({
            "sheet_type": "meta",
            "chain_type": chain_type,
            "node_index": None,
            "label": None,
            "node_type": None,
            "value": None,
            "color": None,
            "source_index": None,
            "target_index": None,
            "source_label": None,
            "target_label": None,
            "source_type": None,
            "target_type": None,
            "flow_from": None,
            "flow_to": None,
            "flow_value": None,
            "cause": None,
            "effect": None,
            "landform": None,
            "total_links": int(total_links),
            "kept_links": int(sum(values) if values else 0),
            "coverage": float(coverage),
            "collapse": int(not args.no_collapse),
            "use_whitelist": int(args.use_whitelist),
            "max_causes": int(args.max_causes),
            "max_effects": int(args.max_effects),
            "min_count": int(args.min_count),
        })

    # 导出统一数据文件
    unified_df = pd.DataFrame(all_data_rows)
    unified_path = outdir / "sankey_unified_data.csv"
    unified_df.to_csv(unified_path, index=False, encoding="utf-8-sig")
    print(f"[saved] {unified_path}")

    if args.composite:
        labels, colors, sources, targets, values = aggregate_composite(
            chains_df,
            args.max_causes,
            args.max_effects,
            args.min_count,
            collapse=not args.no_collapse,
            use_whitelist=args.use_whitelist,
        )
        fig_c = build_composite_figure(labels, colors, sources, targets, values)
        png_path = outdir / "composite_landform_cause_effect.png"
        svg_path = outdir / "composite_landform_cause_effect.svg"
        fig_c.write_image(png_path, format="png", scale=2)
        fig_c.write_image(svg_path, format="svg")
        print(f"[saved] {png_path}")
        print(f"[saved] {svg_path}")


if __name__ == "__main__":
    main()
