"""
跨国影响链条全球地图

用途：
- 解析 all_l_dimensions.csv 中的跨国/国际/全球影响链条（Causal_Chains_* 列）
- 将同一影响链条涉及的国家填充为同一颜色，并用曲线箭头连接来源国与目标国
- 输出 PNG 与可编辑 SVG，沿用 config/三元国家地图 的版式和底图

运行示例：
    python 跨国影响链条地图.py --csv all_l_dimensions.csv --out_prefix 影响链条_全球地图
"""

from __future__ import annotations

import argparse
import os
import re
from typing import Dict, List, Optional, Sequence, Set, Tuple

import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import FancyArrowPatch
import pandas as pd
import numpy as np

try:
    from shapely.geometry import MultiPolygon, Polygon  # type: ignore
except ImportError:
    raise ImportError("需要安装 shapely/geopandas：pip install geopandas")

try:
    from config import DEFAULT_MAP_PALETTE
except ImportError:
    DEFAULT_MAP_PALETTE = [
        "#fb8072", "#80b1d3", "#fdb462", "#b3de69", "#bebada",
        "#8dd3c7", "#ccebc5", "#d9d9d9", "#ffffb3", "#bc80bd",
    ]

from 三元国家地图 import (  # noqa: E402
    _add_coordinate_frame,
    _add_graticules,
    get_config,
    get_natural_earth_countries,
    load_actual_data,
    save_png,
    save_svg_editable,
)

# 配置
EDGE_COLOR = "#b3b3b3"   # 边界更深一点，保证所有国家可见
BASE_FACE = "#e6e6e6"    # 未参与链条的国家填充色（浅灰）
ARROW_ALPHA = 0.78
POINT_EDGE = "#111111"
MIN_CURVE_DIST = 10.0    # 最小曲线对应的经纬度距离，用于短距离放大弧度
BASE_RAD = 0.38
RAD_JITTER = 0.12
RAD_MAX = 1.1
LINE_WIDTH = 0.033       # 线条再缩小约3倍
HEAD_LEN = 1.0
HEAD_WID = 0.55
TAIL_WID = 0.12
JITTER_STEP = 0.0        # 标记不再偏移，保持同一点
GOLDEN_ANGLE = 137.508   # 抗重叠偏移角度增量（度）
MIN_SEP = 0.0            # 允许重合，确保聚集到同一点
MECH_NODE_X_LEFT = -205  # 风险机制节点X
MECH_NODE_X_RIGHT = 205  # 障碍机制节点X
MECH_NODE_SIZE = 35      # 机制节点绘制大小
MECH_CURVE_RAD = 0.35    # 机制曲线弧度
AREA_MIN = 2.0           # 仅绘制面积较大的国家（近似度量）
# 较浅且不重复的10色，用于风险/障碍节点
RISK_COLOR_LIST = [
    "#8dd3c7", "#ffffb3", "#bebada", "#fb8072", "#80b1d3",
    "#fdb462", "#b3de69", "#fccde5", "#d9d9d9", "#bc80bd",
]
BARRIER_COLOR_LIST = [
    "#ccebc5", "#ffed6f", "#bc80bd", "#fdb462", "#80b1d3",
    "#fb9a99", "#b2df8a", "#cab2d6", "#ffffb3", "#8dd3c7",
]

# 常见别名，键为小写
COUNTRY_ALIASES: Dict[str, str] = {
    "brunei darussalam": "Brunei",
    "cabo verde": "Cape Verde",
    "czech republic": "Czechia",
    "democratic republic of congo": "Democratic Republic of the Congo",
    "democratic republic of the congo": "Democratic Republic of the Congo",
    "drc": "Democratic Republic of the Congo",
    "congo, dem. rep.": "Democratic Republic of the Congo",
    "republic of congo": "Republic of the Congo",
    "russian federation": "Russia",
    "syrian arab republic": "Syria",
    "state of palestine": "Palestine",
    "palestinian territories": "Palestine",
    "kyrgyz republic": "Kyrgyzstan",
    "lao people's democratic republic": "Laos",
    "laos pdr": "Laos",
    "turkiye": "Turkey",
    "türkiye": "Turkey",
    "united states": "United States of America",
    "united states of america": "United States of America",
    "usa": "United States of America",
    "u.s.": "United States of America",
    "uk": "United Kingdom",
    "u.k.": "United Kingdom",
    "united kingdom of great britain and northern ireland": "United Kingdom",
    "vatican city (holy see)": "Vatican",
    "holy see": "Vatican",
    "south korea": "South Korea",
    "north korea": "North Korea",
    "republic of korea": "South Korea",
    "gambia, the": "Gambia",
    "iran, islamic rep.": "Iran",
    "venezuela, rb": "Venezuela",
    "cote d'ivoire": "Côte d'Ivoire",
    "ivory coast": "Côte d'Ivoire",
    "eswatini (swaziland)": "Eswatini",
    "timor-leste": "East Timor",
    "viet nam": "Vietnam",
}

CAUSE_ALIAS: Dict[str, str] = {
    "drought/heat": "Drought",
    "extreme heat": "Heatwave",
    "glacier melt": "Glacier Melt",
    "sea-level rise": "Sea Level Rise",
    "sea level rise": "Sea Level Rise",
    "sea level rise (slr)": "Sea Level Rise",
    "coastal erosion": "Coastal Erosion",
    "storm surge": "Storm Surge",
    "data gap": "Lack of Data",
    "data gaps": "Lack of Data",
    "lack of data": "Lack of Data",
    "funding gap": "Funding Gap",
    "finance gap": "Funding Gap",
    "financial gap": "Funding Gap",
    "institutional fragmentation": "Institutional Fragmentation",
    "weak governance": "Institutional Fragmentation",
}

CAUSE_RULES: Dict[str, Sequence[Tuple[str, Sequence[str]]]] = {
    "Risk_Cascade": [
        ("Coastal hazards / SLR", ["sea level", "storm surge", "coastal"]),
        ("Drought / aridity", ["drought", "arid", "desert"]),
        ("Extreme rain / flood", ["rain", "precipitation", "flood"]),
        ("Ocean warming / acidification", ["ocean warming", "sea temperature", "acidification", "marine heat"]),
        ("Heat / temperature rise", ["warming", "heat", "temperature"]),
        ("Land-use change / degradation", ["deforestation", "land degradation", "agricultur", "urban", "overgrazing"]),
        ("Cryosphere melt", ["glacier", "glacial", "snow", "permafrost"]),
        ("Water scarcity / overuse", ["water scarcity", "water stress", "withdrawal"]),
        ("Climate change (general)", ["climate change"]),
    ],
    "Barrier_Mechanism": [
        ("Funding / finance gap", ["funding", "finance", "investment", "budget", "resources", "lack of financial"]),
        ("Institutional fragmentation / governance", ["institutional", "governance", "fragment", "complexity"]),
        ("Data / knowledge / technical gap", ["data", "knowledge", "technical", "capacity"]),
        ("Regulation / enforcement", ["enforcement", "regulation", "code", "policy"]),
        ("Socio-economic pressure", ["pressure", "agri", "expansion", "development", "sprawl", "dependence", "pollution"]),
        ("Energy / biomass reliance", ["biomass", "energy"]),
        ("Conflict / instability", ["conflict", "occupation", "boko haram"]),
        ("Environmental constraint", ["harsh", "volcanic", "drought"]),
    ],
}


def _clean_name(text: str) -> str:
    s = (text or "").strip().strip(",;")
    if not s:
        return ""
    s = s.strip('"').strip("'")
    s = re.sub(r"[()\[\]]", " ", s)
    s = re.sub(r"\s+", " ", s)
    return s.strip()


def normalize_country_name(name: str) -> str:
    """归一化国家名称；不对应具体国家则返回空字符串。"""
    s = _clean_name(name)
    if not s:
        return ""
    low = s.lower()
    # 常见非国家描述，直接忽略
    if any(k in low for k in ["region", "basin", "neighbor", "market", "global"]):
        return ""
    if low.endswith("countries"):
        return ""
    if low in COUNTRY_ALIASES:
        return COUNTRY_ALIASES[low]
    return s


def build_country_lookup(world) -> Tuple[Dict[str, str], Dict[str, object], Dict[str, object]]:
    """构建 name→admin、admin→geometry/point 的索引。"""
    name_to_admin: Dict[str, str] = {}
    admin_to_geom: Dict[str, object] = {}
    admin_to_point: Dict[str, object] = {}
    cols: Sequence[str] = (
        "ADMIN",
        "NAME",
        "NAME_EN",
        "SOVEREIGNT",
        "SOV_A3",
        "ADM0_A3",
        "ISO_A3",
        "BRK_NAME",
        "FORMAL_EN",
    )

    for _, row in world.iterrows():
        geom = row.geometry
        if geom is None or geom.is_empty:
            continue
        admin = str(row.get("ADMIN") or row.get("NAME") or "").strip()
        if not admin:
            continue
        admin_to_geom[admin] = geom
        try:
            point = geom.representative_point()
        except Exception:
            point = geom.centroid
        admin_to_point[admin] = point

        for col in cols:
            val = row.get(col)
            if isinstance(val, str) and val.strip():
                name_to_admin[val.strip().lower()] = admin

    # 额外别名
    for key, target in COUNTRY_ALIASES.items():
        if target in admin_to_geom:
            name_to_admin[key] = target

    return name_to_admin, admin_to_geom, admin_to_point


def resolve_country(name: str, name_to_admin: Dict[str, str]) -> Optional[str]:
    norm = normalize_country_name(name)
    if not norm:
        return None
    key = norm.lower()
    if key in COUNTRY_ALIASES:
        key = COUNTRY_ALIASES[key].lower()
    if key in name_to_admin:
        return name_to_admin[key]
    # ISO-3 情况
    if len(norm) == 3 and norm.lower() in name_to_admin:
        return name_to_admin[norm.lower()]
    return None


def parse_targets(text: str) -> List[str]:
    parts = re.split(r"[;,/|]|\band\b|&", text, flags=re.IGNORECASE)
    return [p.strip() for p in parts if p.strip()]


def extract_chains(
    df: pd.DataFrame,
    name_to_admin: Dict[str, str],
    skip_self: bool = True,
    include_domestic: bool = True,
) -> Tuple[List[Dict], Set[str]]:
    """提取跨国影响链条。"""
    chains: List[Dict] = []
    unknown_names: Set[str] = set()
    chain_idx = 1

    for _, row in df.iterrows():
        source_raw = row.get("Country", "")
        source_admin = resolve_country(source_raw, name_to_admin)
        if not source_admin:
            unknown_names.add(str(source_raw))
            continue

        for idx in (1, 2):
            scope = str(row.get(f"Causal_Chains_{idx}_Impact_Scope", "")).strip()
            target_val = row.get(f"Causal_Chains_{idx}_Target_Country")
            if pd.isna(target_val) or not str(target_val).strip():
                continue
            if (not include_domestic) and scope.lower() == "domestic":
                continue

            targets_raw = parse_targets(str(target_val))
            mapped_targets: List[str] = []
            for tgt in targets_raw:
                expanded = expand_region(tgt)
                if expanded:
                    for ext in expanded:
                        if ext == "__SELF__":
                            mapped_targets.append(source_admin)
                            continue
                        resolved = resolve_country(ext, name_to_admin)
                        if resolved:
                            mapped_targets.append(resolved)
                    continue
                resolved = resolve_country(tgt, name_to_admin)
                if resolved:
                    mapped_targets.append(resolved)
                else:
                    unknown_names.add(tgt)

            # 去除自身指向以减轻视觉拥挤（可通过参数关闭）
            if skip_self:
                mapped_targets = [t for t in mapped_targets if t != source_admin]

            if not mapped_targets:
                continue

            chain = {
                "id": f"C{chain_idx:02d}",
                "source": source_admin,
                "targets": list(dict.fromkeys(mapped_targets)),
                "chain_type": str(row.get(f"Causal_Chains_{idx}_Chain_Type", "")).strip(),
                "scope": scope or "International",
            }
            chains.append(chain)
            chain_idx += 1

    return chains, unknown_names


def darken(hex_color: str, factor: float = 0.7) -> str:
    """略微加深颜色，用于线条/箭头/标记，填色保持原色。"""
    hex_color = hex_color.lstrip("#")
    rgb = [int(hex_color[i:i+2], 16) for i in (0, 2, 4)]
    rgb = [max(0, min(255, int(c * factor))) for c in rgb]
    return "#{:02x}{:02x}{:02x}".format(*rgb)


def assign_colors(n: int, palette: Sequence[str]) -> List[str]:
    """返回基础填色（原色），线条在绘图时加深。"""
    return [palette[i % len(palette)] for i in range(n)]


REGION_EXPANSIONS: Dict[str, List[str]] = {
    "lake chad basin countries": ["Chad", "Niger", "Nigeria", "Cameroon"],
    "mekong region": ["Cambodia", "Laos", "Thailand", "Vietnam", "Myanmar", "China"],
    "baltic region": ["Estonia", "Latvia", "Lithuania"],
    "baltic sea region": ["Estonia", "Latvia", "Lithuania", "Sweden", "Finland", "Poland", "Germany", "Denmark"],
    "black sea region": ["Bulgaria", "Romania", "Ukraine", "Russia", "Turkey", "Georgia"],
    "central asia": ["Kazakhstan", "Kyrgyzstan", "Tajikistan", "Turkmenistan", "Uzbekistan"],
    "nile basin": ["Egypt", "Sudan", "South Sudan", "Ethiopia", "Uganda", "Kenya", "Tanzania"],
    "omvs countries": ["Mauritania", "Mali", "Senegal"],
    "sadc region": ["Angola", "Botswana", "Comoros", "Democratic Republic of the Congo", "Eswatini", "Lesotho",
                    "Madagascar", "Malawi", "Mauritius", "Mozambique", "Namibia", "Seychelles",
                    "South Africa", "Tanzania", "Zambia", "Zimbabwe"],
    "sahel region": ["Mauritania", "Senegal", "Mali", "Burkina Faso", "Niger", "Chad", "Sudan", "Eritrea"],
    "western balkans": ["Albania", "Bosnia and Herzegovina", "Kosovo", "Montenegro", "North Macedonia", "Serbia"],
    "uk overseas territories": ["United Kingdom"],  # 归并到英国
    "vatican city (holy see)": ["Vatican"],
    "global": ["__SELF__"],  # 视为来源自身
    "global (regional)": ["__SELF__"],
    "global markets": ["__SELF__"],
    "region": ["__SELF__"],
    "regional": ["__SELF__"],
    "sub-saharan africa": ["__SELF__"],
    "neighboring countries": ["__SELF__"],
    "neighboring countries (zambia": ["__SELF__"],
    "neighbors (danube)": ["__SELF__"],
    "neighbors (georgia": ["__SELF__"],
}


def expand_region(raw: str) -> List[str]:
    key = raw.strip().lower()
    key = re.sub(r"\(.*?\)", "", key).strip()
    if key in REGION_EXPANSIONS:
        return REGION_EXPANSIONS[key]
    if "neighbor" in key:
        return []
    if key.endswith("countries") or "region" in key or "basin" in key or "global" in key:
        return REGION_EXPANSIONS.get(key, [])
    return []


def normalize_cause(name: str) -> str:
    key = (name or "").strip()
    low = key.lower()
    if low in CAUSE_ALIAS:
        return CAUSE_ALIAS[low]
    return key


def classify_cause(chain_type: str, cause: str) -> str:
    cause_norm = normalize_cause(cause)
    rules = CAUSE_RULES.get(chain_type, [])
    low = cause_norm.lower()
    for label, keys in rules:
        if any(k in low for k in keys):
            return label
    return cause_norm or "Other"


def compute_mechanism_strengths(df: pd.DataFrame, name_to_admin: Dict[str, str]) -> Dict:
    """计算风险级联/障碍的主因分类（Top N，其余合并 Other），并连到国家。"""
    TOP_RISK = 5
    TOP_BARRIER = 5

    def aggregate_causes(chain_type: str, top_n: int) -> Tuple[Dict[str, int], List[Tuple[str, str, int]]]:
        nodes: Dict[str, int] = {}
        edges_count: Dict[Tuple[str, str], int] = {}
        for idx in (1, 2):
            mask = df.get(f"Causal_Chains_{idx}_Chain_Type", "") == chain_type
            cols_needed = [f"Causal_Chains_{idx}_Cause_Node", "Country"]
            sub_df = df.loc[mask, cols_needed]
            for _, row in sub_df.iterrows():
                cause_raw = str(row.get(f"Causal_Chains_{idx}_Cause_Node", "")).strip()
                src_country = row.get("Country", "")
                country_admin = resolve_country(src_country, name_to_admin)
                if not cause_raw or not country_admin:
                    continue
                cause_cat = classify_cause(chain_type, cause_raw)
                nodes[cause_cat] = nodes.get(cause_cat, 0) + 1
                key = (cause_cat, country_admin)
                edges_count[key] = edges_count.get(key, 0) + 1
        if not nodes:
            return {}, []
        sorted_nodes = sorted(nodes.items(), key=lambda kv: kv[1], reverse=True)
        top_labels = {label for label, _ in sorted_nodes[:top_n]}
        merged_nodes: Dict[str, int] = {lbl: nodes[lbl] for lbl in top_labels}
        other_sum = sum(v for lbl, v in nodes.items() if lbl not in top_labels)
        label_map: Dict[str, str] = {}
        for lbl in nodes:
            label_map[lbl] = lbl if lbl in top_labels else "Other"
        if other_sum > 0:
            merged_nodes["Other"] = other_sum
        # 同一 国家-原因 只保留一条线（使用累计计数，但在合并后每国只取最强原因）
        merged_edges: List[Tuple[str, str, int]] = []
        # 聚合到合并后的标签
        agg_by_country: Dict[str, Dict[str, int]] = {}
        for (lbl, country), cnt in edges_count.items():
            mapped = label_map.get(lbl, "Other")
            agg_by_country.setdefault(country, {})
            agg_by_country[country][mapped] = agg_by_country[country].get(mapped, 0) + cnt
        for country, cause_dict in agg_by_country.items():
            # 只保留该国出现次数最高的单一原因
            best_label, best_cnt = max(cause_dict.items(), key=lambda kv: kv[1])
            merged_edges.append((best_label, country, best_cnt))
        return merged_nodes, merged_edges

    risk_nodes, risk_edges = aggregate_causes("Risk_Cascade", TOP_RISK)
    barrier_nodes, barrier_edges = aggregate_causes("Barrier_Mechanism", TOP_BARRIER)

    return {
        "risk_nodes": risk_nodes,         # {cause_cat: count}
        "risk_edges": risk_edges,         # [(cause_cat, country, count)]
        "barrier_nodes": barrier_nodes,   # {cause_cat: count}
        "barrier_edges": barrier_edges,   # [(cause_cat, country, count)]
    }


def draw_mechanism_links(ax: plt.Axes, mech_data: Dict, admin_to_point: Dict[str, object], big_countries: set):
    """在左右两侧绘制机制节点与国家的连线（线宽表示强度）。"""
    risk_color = "#b2182b"
    barrier_base = "#2b8cbe"

    # 风险级联节点（按 Cause 分类）
    risk_nodes = mech_data.get("risk_nodes", {})
    risk_edges = mech_data.get("risk_edges", [])
    risk_legend: List[Line2D] = []
    if risk_nodes:
        labels = list(risk_nodes.keys())
        counts = [risk_nodes[k] for k in labels]
        max_count = max(counts) if counts else 1
        lats = np.linspace(-50, 50, len(labels))
        risk_positions: Dict[str, Tuple[float, float]] = {}
        for i, label in enumerate(labels):
            color = RISK_COLOR_LIST[i % len(RISK_COLOR_LIST)]
            y_pos = lats[i]
            size = MECH_NODE_SIZE * (0.8 + 0.6 * counts[i] / max_count)
            ax.scatter([MECH_NODE_X_LEFT], [y_pos], s=size, marker="H",
                       facecolor="white", edgecolor=color, linewidth=1.0, zorder=11)
            risk_positions[label] = (MECH_NODE_X_LEFT, y_pos, color)
            risk_legend.append(Line2D([0], [0], marker="H", color=color, markerfacecolor="white",
                                      markeredgecolor=color, markersize=6, linestyle="",
                                      label=label))
        for label, country, cnt in risk_edges:
            if country not in big_countries:
                continue
            pt = admin_to_point.get(country)
            if pt is None or label not in risk_positions:
                continue
            x0, y0, color = risk_positions[label]
            lw = max(0.1, 0.66 * cnt / max_count)
            rad = MECH_CURVE_RAD if pt.y >= y0 else -MECH_CURVE_RAD
            arrow = FancyArrowPatch(
                (x0, y0),
                (pt.x, pt.y),
                connectionstyle=f"arc3,rad={rad}",
                arrowstyle=f"Simple,head_length={HEAD_LEN},head_width={HEAD_WID},tail_width={TAIL_WID}",
                linewidth=lw,
                color=color,  # 不再加深
                alpha=0.5,
                zorder=6,
            )
            ax.add_patch(arrow)

    # 障碍节点（按 Cause 分类，Top9）
    barrier_nodes = mech_data.get("barrier_nodes", {})
    barrier_edges = mech_data.get("barrier_edges", [])
    barrier_legend: List[Line2D] = []
    if barrier_nodes:
        labels_b = list(barrier_nodes.keys())
        counts_b = [barrier_nodes[k] for k in labels_b]
        max_count_b = max(counts_b) if counts_b else 1
        lats_b = np.linspace(-50, 50, len(labels_b))
        barrier_positions: Dict[str, Tuple[float, float, str]] = {}
        for i, label in enumerate(labels_b):
            color = BARRIER_COLOR_LIST[i] if i < len(BARRIER_COLOR_LIST) else DEFAULT_MAP_PALETTE[(i + 3) % len(DEFAULT_MAP_PALETTE)]
            y_pos = lats_b[i]
            size = MECH_NODE_SIZE * (0.8 + 0.6 * counts_b[i] / max_count_b)
            ax.scatter([MECH_NODE_X_RIGHT], [y_pos], s=size, marker="D",
                       facecolor="white", edgecolor=color, linewidth=1.0, zorder=11)
            barrier_positions[label] = (MECH_NODE_X_RIGHT, y_pos, color)
            barrier_legend.append(Line2D([0], [0], marker="D", color=color, markerfacecolor="white",
                                         markeredgecolor=color, markersize=6, linestyle="",
                                         label=label))
        for label, country, cnt in barrier_edges:
            if country not in big_countries:
                continue
            pt = admin_to_point.get(country)
            if pt is None or label not in barrier_positions:
                continue
            x0, y0, color = barrier_positions[label]
            lw = max(0.1, 0.66 * cnt / max_count_b)
            rad = MECH_CURVE_RAD if pt.y >= y0 else -MECH_CURVE_RAD
            arrow = FancyArrowPatch(
                (x0, y0),
                (pt.x, pt.y),
                connectionstyle=f"arc3,rad={rad}",
                arrowstyle=f"Simple,head_length={HEAD_LEN},head_width={HEAD_WID},tail_width={TAIL_WID}",
                linewidth=lw,
                color=color,  # 不再加深
                alpha=0.5,
                zorder=6,
            )
            ax.add_patch(arrow)

    return risk_legend, barrier_legend


def draw_chain_map(
    chains: List[Dict],
    admin_to_geom: Dict[str, object],
    admin_to_point: Dict[str, object],
    output_prefix: str,
    resolution: str = "50m",
    mech_data: Dict = None,
):
    config = get_config()
    config.apply()

    # 仅保留面积较大的国家用于连线/标记
    big_countries: set = set()
    for admin, geom in admin_to_geom.items():
        try:
            if geom is not None and hasattr(geom, "area") and geom.area >= AREA_MIN:
                big_countries.add(admin)
        except Exception:
            continue

    fig, ax = plt.subplots(figsize=config.figsize, facecolor="white")
    if config.ocean_color != "none":
        ax.set_facecolor(config.ocean_color)

    base_colors = assign_colors(len(chains), DEFAULT_MAP_PALETTE)
    chain_colors = {c["id"]: base_colors[i] for i, c in enumerate(chains)}  # 国家填色用原色
    chain_line_colors = {cid: darken(col, 0.55) for cid, col in chain_colors.items()}  # 线条/箭头/标记用更深色

    # 国家填色
    country_color: Dict[str, str] = {}
    for chain in chains:
        col = chain_colors[chain["id"]]
        for country in [chain["source"], *chain["targets"]]:
            country_color.setdefault(country, col)

    for admin, geom in admin_to_geom.items():
        face = country_color.get(admin, BASE_FACE)
        if isinstance(geom, (Polygon, MultiPolygon)):
            geoms = geom.geoms if isinstance(geom, MultiPolygon) else [geom]
            for g in geoms:
                xs, ys = g.exterior.xy
                ax.fill(xs, ys, facecolor=face, edgecolor=EDGE_COLOR, linewidth=0.35, zorder=1)
                for interior in g.interiors:
                    xs_h, ys_h = interior.xy
                    ax.fill(xs_h, ys_h, facecolor=config.ocean_color if config.ocean_color != "none" else "white",
                            edgecolor=EDGE_COLOR, linewidth=0.2, zorder=1)

    # 曲线连接
    path_counts: Dict[Tuple[str, str], int] = {}
    for i, chain in enumerate(chains):
        if chain["source"] not in big_countries:
            continue
        src_pt = admin_to_point.get(chain["source"])
        if src_pt is None:
            continue
        color = chain_line_colors[chain["id"]]
        for j, tgt in enumerate(chain["targets"]):
            if tgt not in big_countries:
                continue
            tgt_pt = admin_to_point.get(tgt)
            if tgt_pt is None:
                continue
            # 根据距离放大弧度，交替符号避免重叠，同时对同一对点累计偏移
            dist = ((src_pt.x - tgt_pt.x) ** 2 + (src_pt.y - tgt_pt.y) ** 2) ** 0.5
            mult = max(1.0, MIN_CURVE_DIST / (dist + 1e-6))
            base_rad = min(RAD_MAX, BASE_RAD * mult)
            key = (chain["source"], tgt)
            count = path_counts.get(key, 0)
            sign = 1 if (count % 2 == 0) else -1
            rad = sign * (base_rad + (count // 2) * RAD_JITTER)
            rad = max(-RAD_MAX, min(RAD_MAX, rad))
            path_counts[key] = count + 1
            arrow = FancyArrowPatch(
                (src_pt.x, src_pt.y),
                (tgt_pt.x, tgt_pt.y),
                connectionstyle=f"arc3,rad={rad}",
                arrowstyle=f"Simple,head_length={HEAD_LEN},head_width={HEAD_WID},tail_width={TAIL_WID}",
                linewidth=LINE_WIDTH,
                color=color,
                alpha=min(1.0, ARROW_ALPHA + 0.15),
                zorder=6,
            )
            ax.add_patch(arrow)

    # 来源 / 目标标记
    src_points = []
    tgt_points = []
    for chain in chains:
        if chain["source"] in big_countries:
            src_pt = admin_to_point.get(chain["source"])
        else:
            src_pt = None
        if src_pt is not None:
            src_points.append((src_pt.x, src_pt.y, chain_line_colors[chain["id"]]))
        for tgt in chain["targets"]:
            if tgt not in big_countries:
                continue
            tgt_pt = admin_to_point.get(tgt)
            if tgt_pt is not None:
                tgt_points.append((tgt_pt.x, tgt_pt.y, chain_line_colors[chain["id"]]))

    def _scatter_with_jitter(points: List[Tuple[float, float, str]], base_size: float, marker: str, facewhite: bool = False):
        """逐点放置，确保相互距离>=MIN_SEP，通过逐步旋转/放大偏移实现防贴合。"""
        if not points:
            return
        placed: List[Tuple[float, float, str, float]] = []
        xs, ys, cs, sizes = [], [], [], []
        for idx, (x, y, c) in enumerate(points):
            r = 0.0
            ang = (GOLDEN_ANGLE * idx) % 360
            px, py = x, y
            # 尝试最多 30 次扩散，直到与已放置点距离>=MIN_SEP
            for attempt in range(30):
                collision = False
                for (ox, oy, _, _) in placed:
                    dist = ((px - ox) ** 2 + (py - oy) ** 2) ** 0.5
                    if dist < MIN_SEP:
                        collision = True
                        break
                if not collision:
                    break
                r += JITTER_STEP
                ang = (ang + GOLDEN_ANGLE) % 360
                px = x + r * np.cos(np.deg2rad(ang))
                py = y + r * np.sin(np.deg2rad(ang))

            is_europe = (-15 <= x <= 50) and (35 <= y <= 72)
            size = base_size * (0.5 if is_europe else 1.0)
            xs.append(px)
            ys.append(py)
            cs.append(c)
            sizes.append(size)
            placed.append((px, py, c, size))

        ax.scatter(xs, ys, s=sizes, marker=marker,
                   facecolor="white" if facewhite else cs,
                   edgecolor=cs, linewidth=0.25, alpha=0.98, zorder=8 if facewhite else 9,
                   label="Source" if facewhite else "Target")

    _scatter_with_jitter(src_points, base_size=2.0, marker="s", facewhite=True)
    _scatter_with_jitter(tgt_points, base_size=3.0, marker="o", facewhite=False)

    risk_legend: List[Line2D] = []
    barrier_legend: List[Line2D] = []
    if mech_data:
        r_leg, b_leg = draw_mechanism_links(ax, mech_data, admin_to_point, big_countries)
        risk_legend = r_leg or []
        barrier_legend = b_leg or []

    extent = (-220, 220, -60, 85) if mech_data else (-180, 180, -60, 85)
    _add_graticules(ax, extent)
    _add_coordinate_frame(ax, extent, lon_interval=30, lat_interval=30)
    ax.set_xlabel("")
    ax.set_ylabel("")
    ax.set_aspect("equal")

    # 简要图例
    handles = [
        Line2D([0], [0], marker="s", color="black", markerfacecolor="white", markeredgewidth=0.8,
               markersize=4, linewidth=0, label="Chain source"),
        Line2D([0], [0], marker="o", color=POINT_EDGE, markerfacecolor="gray", markersize=5,
               linewidth=0, label="Chain target"),
        Line2D([0, 1], [0, 0], color="gray", linewidth=0.8, label="Curved link (direction →)"),
    ]
    if risk_legend:
        handles.extend(risk_legend)
    if barrier_legend:
        handles.extend(barrier_legend)
    ax.legend(
        handles=handles,
        loc="upper center",
        bbox_to_anchor=(0.5, -0.1),
        ncol=3,
        frameon=False,
        fontsize=config.legend_size,
        title="Impact chains",
        title_fontsize=config.label_size,
    )

    ax.set_title("跨国影响链条全球图（同链同色，箭头指向目标）", fontsize=config.title_size, pad=8)
    ax.text(
        0.5,
        -0.18,
        "链条编号 (C01...) 与颜色一致；详单见控制台输出",
        transform=ax.transAxes,
        ha="center",
        va="top",
        fontsize=max(6, config.tick_size),
        color="#444444",
    )

    os.makedirs(os.path.dirname(output_prefix) or ".", exist_ok=True)
    png_path = f"{output_prefix}.png"
    svg_path = f"{output_prefix}.svg"
    save_png(fig, png_path, strict_size=False)
    save_svg_editable(fig, svg_path, strict_size=False)
    plt.close(fig)
    print(f"[SUCCESS] 输出: {png_path}, {svg_path}")


def create_map(csv_file: str = "all_l_dimensions.csv", output_prefix: str = "影响链条_全球地图", resolution: str = "50m",
               include_self_links: bool = True, include_domestic: bool = True, show_mechanisms: bool = True):
    config = get_config()
    config.apply()

    df = load_actual_data(csv_file)
    if df is None or df.empty:
        print("[ERROR] 数据为空")
        return

    world = get_natural_earth_countries(resolution)
    name_to_admin, admin_to_geom, admin_to_point = build_country_lookup(world)
    chains, unknown = extract_chains(
        df, name_to_admin,
        skip_self=not include_self_links,
        include_domestic=include_domestic,
    )

    if not chains:
        print("[ERROR] 没有跨国链条记录（仅保留 Impact_Scope != Domestic 且有目标国 的记录）")
        return

    print(f"[INFO] 提取跨国链条 {len(chains)} 条")
    for chain in chains:
        print(f"[CHAIN] {chain['id']}: {chain['source']} -> {', '.join(chain['targets'])} "
              f"(type={chain['chain_type'] or 'N/A'}, scope={chain['scope']})")

    if unknown:
        print(f"[WARN] 未匹配的名称（被跳过）: {', '.join(sorted(list(unknown))[:15])}"
              + (" ..." if len(unknown) > 15 else ""))

    mech_data = compute_mechanism_strengths(df, name_to_admin) if show_mechanisms else None

    draw_chain_map(chains, admin_to_geom, admin_to_point, output_prefix, resolution=resolution, mech_data=mech_data)


def main():
    parser = argparse.ArgumentParser(description="跨国影响链条全球地图")
    parser.add_argument("--csv", default="all_l_dimensions.csv", help="输入CSV路径")
    parser.add_argument("--out_prefix", default="影响链条_全球地图", help="输出前缀（不含扩展名）")
    parser.add_argument("--resolution", default="50m", choices=["110m", "50m", "10m"])
    parser.add_argument("--include_self_links", action="store_true", default=False,
                        help="包含来源=目标的自环链条（默认隐藏以减少拥挤）")
    parser.add_argument("--include_domestic", action="store_true", default=False,
                        help="包含 Impact_Scope=Domestic 的链条（默认仅跨国）")
    parser.add_argument("--show_mechanisms", action="store_true", default=True,
                        help="在左右侧绘制风险/障碍机制节点并按强度连线（默认开启）")
    args = parser.parse_args()
    create_map(csv_file=args.csv, output_prefix=args.out_prefix, resolution=args.resolution,
               include_self_links=args.include_self_links,
               include_domestic=args.include_domestic,
               show_mechanisms=args.show_mechanisms)


if __name__ == "__main__":
    main()
