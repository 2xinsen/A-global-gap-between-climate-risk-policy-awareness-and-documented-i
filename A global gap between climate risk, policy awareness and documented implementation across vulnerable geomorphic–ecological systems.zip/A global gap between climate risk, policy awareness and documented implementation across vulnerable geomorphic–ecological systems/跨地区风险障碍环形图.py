"""
跨地区风险+障碍原因环形图（双层环图，内圈风险级联原因，外圈行动障碍原因）

特性：
- 沿用《跨国影响链条地图》的机制分类/别名；去除左右机制节点，改为在环图之间加入跨国因果链弧线
- 将 Risk_Cascade 与 Barrier_Mechanism 的 Cause 统一到同一张图：每个地区一个双层环形图（内圈风险，外圈障碍）
- 环图缩小 3 倍并加同色描边（环图与区域描边一致），可偏移防碰撞且附指向线指回区域
- 展示所有有数据的地区（无上限），跨区域因果链按地区聚合并以弧线连接

使用示例：
    python 跨地区风险障碍环形图.py --csv all_l_dimensions.csv --out_prefix outputs/地区风险障碍环图
"""

from __future__ import annotations

import argparse
import os
from typing import Dict, List, Optional, Sequence, Set, Tuple

import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import FancyArrowPatch
from mpl_toolkits.axes_grid1.inset_locator import inset_axes
import numpy as np
import pandas as pd

try:
    from shapely.geometry import MultiPolygon, Polygon, Point  # type: ignore
except ImportError:
    raise ImportError("需要安装 shapely/geopandas：pip install geopandas")

from 三元国家地图 import (  # noqa: E402
    _add_coordinate_frame,
    _add_graticules,
    get_config,
    get_natural_earth_countries,
    load_actual_data,
    save_png,
    save_svg_editable,
)
from 跨国影响链条地图 import (  # noqa: E402
    ARROW_ALPHA,
    BASE_RAD,
    BARRIER_COLOR_LIST,
    HEAD_LEN,
    HEAD_WID,
    LINE_WIDTH,
    DEFAULT_MAP_PALETTE,
    MIN_CURVE_DIST,
    RAD_JITTER,
    RAD_MAX,
    RISK_COLOR_LIST,
    TAIL_WID,
    build_country_lookup,
    assign_colors,
    classify_cause,
    extract_chains,
    darken,
    resolve_country,
)

# 颜色与样式
BASE_FACE = "#f1f1f1"            # 国家底色
EDGE_COLOR = "#c0c0c0"           # 国家边界
RISK_OTHER_COLOR = "#c7c7c7"     # 风险“其他”颜色
BARRIER_OTHER_COLOR = "#c4ccd6"  # 障碍“其他”颜色
DONUT_SIZE_BASE = 0.27           # 环图基础尺寸（扩大 1.5x）
DONUT_SIZE_MAX = 0.45            # 环图最大尺寸（扩大 1.5x）
MIN_SEP_DEG = 10.5               # 环图之间的最小间隔（经纬度距离）
JITTER_STEP = 2.0                # 防重叠偏移步长（更大，避免欧洲重叠）
CHAIN_LINE_WIDTH = max(0.14, LINE_WIDTH * 5)  # 因果链与箭头线宽再次减小
NODE_COLOR = "#111111"
NODE_MIN_SEP_DEG = 0.9  # 节点最小间距（经纬度度数），保证点不重叠

# 标准分区：基于 Natural Earth SUBREGION → 自定义标准大区
SUBREGION_TO_STD: Dict[str, str] = {
    # 美洲
    "Northern America": "North America",
    "Central America": "Latin America & Caribbean",
    "Caribbean": "Latin America & Caribbean",
    "South America": "South America",
    # 欧洲
    "Northern Europe": "Europe",
    "Western Europe": "Europe",
    "Southern Europe": "Europe",
    "Eastern Europe": "Europe",
    # 中东/北非
    "Western Asia": "Middle East",
    "Northern Africa": "Middle East & North Africa",
    # 亚洲分区
    "Eastern Asia": "East Asia",
    "South-Eastern Asia": "Southeast Asia",
    "South Asia": "South Asia",
    "Southern Asia": "South Asia",
    "Central Asia": "Central Asia",
    # 大洋洲
    "Australia and New Zealand": "Oceania",
    "Melanesia": "Oceania",
    "Micronesia": "Oceania",
    "Polynesia": "Oceania",
    # 非洲其余
    "Middle Africa": "Sub-Saharan Africa",
    "Eastern Africa": "Sub-Saharan Africa",
    "Western Africa": "Sub-Saharan Africa",
    "Southern Africa": "Sub-Saharan Africa",
}

# 针对个别国家的覆盖（ADMIN 名称）
ADMIN_REGION_OVERRIDE: Dict[str, str] = {
    "Australia": "Oceania",
    "New Zealand": "Oceania",
}

# 预设环图锚点（尽量位于近海空白区）
REGION_ANCHORS: Dict[str, Tuple[float, float]] = {
    "North America": (-150, 35),
    "South America": (-85, -20),
    "Latin America & Caribbean": (-65, 15),
    "Europe": (-25, 52),
    "Middle East": (55, 20),
    "Middle East & North Africa": (15, 33),
    "Sub-Saharan Africa": (5, -10),
    "South Asia": (70, 5),
    "Southeast Asia": (115, 5),
    "East Asia": (150, 25),
    "Central Asia": (90, 25),
    "Oceania": (170, -25),
    "Asia (Other)": (110, 35),
    "Other": (0, 0),
}

# 地区归一化，减少同义标签的重复
REGION_ALIAS: Dict[str, str] = {
    "latin america & caribbean": "Latin America & Caribbean",
    "latin america and caribbean": "Latin America & Caribbean",
    "latin america and the caribbean": "Latin America & Caribbean",
    "latin america & caribbean (oecs)": "Latin America & Caribbean",
    "caribbean (sids)": "Caribbean (SIDS)",
    "caribbean": "Caribbean (SIDS)",
    "south-east asia": "Southeast Asia",
    "south-eastern asia": "Southeast Asia",
    "south asia": "South Asia",
    "east asia": "East Asia",
    "east asia & pacific": "East Asia & Pacific",
    "oceania (melanesia)": "Oceania",
    "melanesia (pacific sids)": "Oceania",
    "asia-oceania": "Asia & Oceania",
    "western and central africa": "Western & Central Africa",
    "middle africa": "Western & Central Africa",
    "middle east and north africa": "Middle East & North Africa",
    "middle east & north africa": "Middle East & North Africa",
    "western asia / eastern europe": "Western Asia / Eastern Europe",
    "eastern europe / western asia": "Western Asia / Eastern Europe",
    "southern europe / western balkans": "Southern Europe / Western Balkans",
    "southern europe / western asia": "Southern Europe / Western Asia",
    "sub-saharan africa (horn of africa)": "Horn of Africa",
    "africa (eastern africa)": "Eastern Africa",
    "africa (west)": "Western Africa",
    "africa (eastern)": "Eastern Africa",
    "central africa (sids)": "Central Africa",
    "pacific islands (micronesia)": "Pacific Islands",
}


def assign_region_colors(regions: Sequence[str]) -> Dict[str, str]:
    return {region: DEFAULT_MAP_PALETTE[i % len(DEFAULT_MAP_PALETTE)] for i, region in enumerate(regions)}


def build_standard_region_lookup(world) -> Dict[str, str]:
    """ADMIN -> 标准大区（基于 Natural Earth SUBREGION + 自定义合并）。"""
    lookup: Dict[str, str] = {}
    for _, row in world.iterrows():
        admin = str(row.get("ADMIN") or "").strip()
        if not admin:
            continue
        if admin in ADMIN_REGION_OVERRIDE:
            lookup[admin] = ADMIN_REGION_OVERRIDE[admin]
            continue
        subregion = str(row.get("SUBREGION") or "").strip()
        std = SUBREGION_TO_STD.get(subregion)
        if not std:
            region_un = str(row.get("REGION_UN") or "").strip()
            if region_un == "Africa":
                std = "Sub-Saharan Africa"
            elif region_un == "Europe":
                std = "Europe"
            elif region_un == "Asia":
                std = "Asia (Other)"
            elif region_un == "Oceania":
                std = "Oceania"
            elif region_un == "Americas":
                std = "Latin America & Caribbean"
            else:
                std = "Other"
        lookup[admin] = std
    return lookup


def lighten(hex_color: str, ratio: float = 0.7) -> str:
    """将颜色与白色混合，使底色更浅。ratio 越大越浅，0-1。"""
    hex_color = hex_color.lstrip("#")
    r, g, b = int(hex_color[0:2], 16), int(hex_color[2:4], 16), int(hex_color[4:6], 16)
    r = int(r + (255 - r) * ratio)
    g = int(g + (255 - g) * ratio)
    b = int(b + (255 - b) * ratio)
    return f"#{r:02x}{g:02x}{b:02x}"


def collect_region_causes(df: pd.DataFrame, name_to_admin: Dict[str, str], admin_to_region: Dict[str, str]) -> Dict[str, Dict]:
    """按标准大区收集风险/障碍原因及所含国家（国家集合始终记录，哪怕无风险/障碍原因）。"""
    data: Dict[str, Dict] = {}
    for _, row in df.iterrows():
        country_admin = resolve_country(row.get("Country", ""), name_to_admin)
        if not country_admin:
            continue
        region = admin_to_region.get(country_admin)
        if not region:
            continue
        info = data.setdefault(region, {"risk": {}, "barrier": {}, "countries": set()})
        info["countries"].add(country_admin)
        for idx in (1, 2):
            chain_type = str(row.get(f"Causal_Chains_{idx}_Chain_Type") or "").strip()
            cause_raw = str(row.get(f"Causal_Chains_{idx}_Cause_Node") or "").strip()
            if not chain_type or not cause_raw:
                continue
            if chain_type not in ("Risk_Cascade", "Barrier_Mechanism"):
                continue
            cause_label = classify_cause(chain_type, cause_raw)
            bucket = "risk" if chain_type == "Risk_Cascade" else "barrier"
            info[bucket][cause_label] = info[bucket].get(cause_label, 0) + 1
    return data


def build_country_region_map(admin_to_region: Dict[str, str]) -> Dict[str, str]:
    """country_admin -> region（直接用标准大区映射）。"""
    return dict(admin_to_region)


def region_palette(regions: Sequence[str]) -> Dict[str, str]:
    """更深一档的区域色，避免太浅。"""
    colors = {}
    for i, r in enumerate(regions):
        base = DEFAULT_MAP_PALETTE[i % len(DEFAULT_MAP_PALETTE)]
        colors[r] = darken(base, 0.78)
    return colors


def compute_region_centers(region_data: Dict[str, Dict], admin_to_point: Dict[str, object]) -> Dict[str, Tuple[float, float]]:
    """以地区内国家代表点的平均值作为地区环图放置位置。"""
    centers: Dict[str, Tuple[float, float]] = {}
    for region, info in region_data.items():
        pts = []
        for admin in info.get("countries", set()):
            pt = admin_to_point.get(admin)
            if pt is not None and hasattr(pt, "x") and hasattr(pt, "y"):
                pts.append(pt)
        if not pts:
            continue
        xs = [float(p.x) for p in pts]
        ys = [float(p.y) for p in pts]
        centers[region] = (float(np.mean(xs)), float(np.mean(ys)))
    return centers


def compute_donut_size(total: int, max_total: int) -> float:
    if total <= 0 or max_total <= 0:
        return DONUT_SIZE_BASE
    return DONUT_SIZE_BASE + (DONUT_SIZE_MAX - DONUT_SIZE_BASE) * (total / max_total) ** 0.58


def size_to_radius_deg(size: float) -> float:
    """估算一个足够保守的“半径”用于碰撞检测（单位：经纬度度数）。"""
    return max(4.5, size * 9.5)


def spread_positions(
    centers: Dict[str, Tuple[float, float]],
    ordered_regions: Sequence[str],
    radii_deg: Dict[str, float],
    extra_gap: float = 2.0,
    step: float = JITTER_STEP,
) -> Dict[str, Tuple[float, float]]:
    """严格防碰撞：按权重顺序放置，必要时沿黄金角偏移，直至圆形安全半径不重叠。"""
    placed: Dict[str, Tuple[float, float]] = {}
    for idx, region in enumerate(ordered_regions):
        if region not in centers:
            continue
        base_x, base_y = centers[region]
        r_self = radii_deg.get(region, 4.0)
        px, py = base_x, base_y
        ang = (137.5 * (idx + 1)) % 360
        rad = 0.0
        for _ in range(80):
            collision = False
            for other, (ox, oy) in placed.items():
                r_other = radii_deg.get(other, 4.0)
                dist = ((px - ox) ** 2 + (py - oy) ** 2) ** 0.5
                if dist < (r_self + r_other + extra_gap):
                    collision = True
                    break
            if not collision:
                break
            rad += step
            ang = (ang + 61) % 360
            px = base_x + rad * np.cos(np.deg2rad(ang))
            py = base_y + rad * np.sin(np.deg2rad(ang))
        placed[region] = (px, py)
    return placed


def move_off_land(
    pos: Tuple[float, float],
    land_geoms: Sequence[Polygon],
    start_angle: float,
    step_deg: float = 3.0,
    max_iter: int = 120,
    clearance_deg: float = 0.0,
) -> Tuple[float, float]:
    """将点从陆地推向海上：若点或其缓冲圆与陆地相交，则沿角度逐步外推直至落海。"""
    x, y = pos
    ang = start_angle
    radius = 0.0
    for _ in range(max_iter):
        p = Point(x, y)
        shape = p.buffer(clearance_deg) if clearance_deg > 0 else p
        on_land = any(g.intersects(shape) for g in land_geoms)
        if not on_land:
            return (x, y)
        radius += 2.0
        ang = (ang + step_deg) % 360
        x = pos[0] + radius * np.cos(np.deg2rad(ang))
        y = pos[1] + radius * np.sin(np.deg2rad(ang))
    return (x, y)


def top_labels(region_data: Dict[str, Dict], bucket: str, top_n: int) -> List[str]:
    """全局计数，获取前 top_n 标签。"""
    counts: Dict[str, int] = {}
    for info in region_data.values():
        for lbl, cnt in info.get(bucket, {}).items():
            counts[lbl] = counts.get(lbl, 0) + cnt
    ordered = sorted(counts.items(), key=lambda kv: kv[1], reverse=True)
    return [lbl for lbl, _ in ordered[:top_n]]


def draw_base_map(ax: plt.Axes, admin_to_geom: Dict[str, object], ocean_color: str,
                  admin_color: Optional[Dict[str, str]] = None) -> None:
    """填充世界底图（按地区上色，所有国家可见）。"""
    for admin, geom in admin_to_geom.items():
        face = BASE_FACE
        if admin_color and admin in admin_color:
            face = admin_color[admin]
        if isinstance(geom, (Polygon, MultiPolygon)):
            geoms = geom.geoms if isinstance(geom, MultiPolygon) else [geom]
            for g in geoms:
                xs, ys = g.exterior.xy
                ax.fill(xs, ys, facecolor=face, edgecolor=EDGE_COLOR, linewidth=0.35, zorder=1)
                for interior in g.interiors:
                    xs_h, ys_h = interior.xy
                    ax.fill(xs_h, ys_h, facecolor=ocean_color if ocean_color != "none" else "white",
                            edgecolor=EDGE_COLOR, linewidth=0.25, zorder=1)


def format_region_label(name: str) -> str:
    """长标签分行，避免遮挡。"""
    if len(name) <= 18:
        return name
    if " / " in name:
        parts = name.split(" / ")
        return "\n".join(parts[:2])
    if " & " in name:
        left, right = name.split(" & ", 1)
        return f"{left}\n& {right}"
    return name


def draw_region_donut(
    ax: plt.Axes,
    region: str,
    pos: Tuple[float, float],
    info: Dict,
    risk_labels: Sequence[str],
    barrier_labels: Sequence[str],
    include_risk_other: bool,
    include_barrier_other: bool,
    risk_palette: Sequence[str],
    barrier_palette: Sequence[str],
    max_total: int,
    region_color: str,
    size: float,
) -> None:
    total = sum(info.get("risk", {}).values()) + sum(info.get("barrier", {}).values())
    if total <= 0 or max_total <= 0:
        return

    inset = inset_axes(
        ax,
        width=size,
        height=size,
        loc="center",
        bbox_to_anchor=pos,
        bbox_transform=ax.transData,
        borderpad=0,
    )

    risk_counts = [info["risk"].get(lbl, 0) for lbl in risk_labels]
    if include_risk_other:
        other = sum(v for lbl, v in info["risk"].items() if lbl not in risk_labels)
        risk_counts.append(other)
    barrier_counts = [info["barrier"].get(lbl, 0) for lbl in barrier_labels]
    if include_barrier_other:
        other_b = sum(v for lbl, v in info["barrier"].items() if lbl not in barrier_labels)
        barrier_counts.append(other_b)

    if sum(barrier_counts) > 0:
        inset.pie(
            barrier_counts,
            radius=1.0,
            startangle=90,
            counterclock=False,
            colors=barrier_palette,
            wedgeprops={"width": 0.33, "edgecolor": region_color, "linewidth": 0.4},
        )
    if sum(risk_counts) > 0:
        inset.pie(
            risk_counts,
            radius=0.7,
            startangle=90,
            counterclock=False,
            colors=risk_palette,
            wedgeprops={"width": 0.33, "edgecolor": region_color, "linewidth": 0.4},
        )

    # 外圈描边保证整体轮廓与区域描边一致
    inset.add_artist(plt.Circle((0, 0), 1.0, facecolor="none", edgecolor=region_color, linewidth=0.55))
    inset.add_artist(plt.Circle((0, 0), 0.37, facecolor="none", edgecolor=region_color, linewidth=0.48))

    inset.text(
        0.5,
        1.08,
        format_region_label(region),
        ha="center",
        va="bottom",
        fontsize=3.5,
        fontweight="bold",
        color=region_color,
        transform=inset.transAxes,
    )
    inset.set_xticks([])
    inset.set_yticks([])
    inset.set_aspect("equal")
    inset.axis("off")


def create_region_ring_map(
    csv_file: str = "all_l_dimensions.csv",
    output_prefix: str = "地区风险障碍环图",
    resolution: str = "50m",
    top_regions: int = 0,
    min_total: int = 1,
    include_domestic_chains: bool = False,
    risk_top_n: int = 6,
    barrier_top_n: int = 6,
) -> None:
    config = get_config()
    config.apply()

    df = load_actual_data(csv_file)
    if df is None or df.empty:
        print("[ERROR] 数据为空或未加载成功")
        return

    world = get_natural_earth_countries(resolution)
    name_to_admin, admin_to_geom, admin_to_point = build_country_lookup(world)

    # 使用更细的标准大区（信息更充分）
    admin_to_region = build_standard_region_lookup(world)
    region_data = collect_region_causes(df, name_to_admin, admin_to_region)
    if not region_data:
        print("[ERROR] 没有可用的地区风险/障碍原因记录")
        return

    country_region_map = build_country_region_map(admin_to_region)
    # 构造跨区域因果链（按地区聚合）
    # 跨国/跨地区因果链条提取：完全沿用《跨国影响链条地图》的口径（默认仅跨国、跳过自环）
    chains, unknown = extract_chains(
        df,
        name_to_admin,
        skip_self=True,
        include_domestic=include_domestic_chains,
    )
    # 因果链颜色（同链同色），并用于“因果国家单独上色”
    chain_colors: Dict[str, str] = {}
    chain_line_colors: Dict[str, str] = {}
    country_chain_color: Dict[str, str] = {}
    if chains:
        base_cols = assign_colors(len(chains), DEFAULT_MAP_PALETTE)
        chain_colors = {c["id"]: base_cols[i] for i, c in enumerate(chains)}
        chain_line_colors = {cid: darken(col, 0.55) for cid, col in chain_colors.items()}
        for chain in chains:
            col = chain_colors.get(chain["id"], "#dddddd")
            for country in [chain["source"], *chain["targets"]]:
                country_chain_color.setdefault(country, col)

    region_centers = compute_region_centers(region_data, admin_to_point)
    totals: Dict[str, int] = {
        region: sum(info.get("risk", {}).values()) + sum(info.get("barrier", {}).values())
        for region, info in region_data.items()
    }

    # 统计链条覆盖到的区域（包含风险/障碍为 0 的区域）
    chain_region_hits: Dict[str, int] = {}
    for chain in chains:
        src_reg = country_region_map.get(chain["source"])
        if src_reg:
            chain_region_hits[src_reg] = chain_region_hits.get(src_reg, 0) + 1
        for tgt in chain["targets"]:
            tr = country_region_map.get(tgt)
            if tr:
                chain_region_hits[tr] = chain_region_hits.get(tr, 0) + 1

    ordered = sorted(totals.items(), key=lambda kv: kv[1], reverse=True)
    selected_regions = [r for r, c in ordered if c >= min_total]
    # 补充只有链条的区域
    for reg, cnt in chain_region_hits.items():
        if reg not in selected_regions:
            selected_regions.append(reg)
            totals.setdefault(reg, 0)
    if top_regions and top_regions > 0:
        selected_regions = selected_regions[:top_regions]
    selected_regions = [r for r in selected_regions if r in region_centers]

    if not selected_regions:
        print("[ERROR] 符合条件的地区为空（检查 min_total/top_regions 或数据覆盖）")
        return

    risk_labels_main = top_labels(region_data, "risk", top_n=risk_top_n)
    barrier_labels_main = top_labels(region_data, "barrier", top_n=barrier_top_n)
    include_risk_other = any(
        any(lbl not in risk_labels_main for lbl in info.get("risk", {}))
        for info in region_data.values()
    )
    include_barrier_other = any(
        any(lbl not in barrier_labels_main for lbl in info.get("barrier", {}))
        for info in region_data.values()
    )

    risk_palette = [darken(RISK_COLOR_LIST[i % len(RISK_COLOR_LIST)], 0.82) for i in range(len(risk_labels_main))]
    barrier_palette = [darken(BARRIER_COLOR_LIST[i % len(BARRIER_COLOR_LIST)], 0.82) for i in range(len(barrier_labels_main))]
    if include_risk_other:
        risk_palette.append(RISK_OTHER_COLOR)
    if include_barrier_other:
        barrier_palette.append(BARRIER_OTHER_COLOR)

    max_total = max(totals[r] for r in selected_regions) if selected_regions else 1
    size_map = {r: compute_donut_size(totals[r], max_total) for r in selected_regions}
    radius_map = {r: size_to_radius_deg(size_map[r]) for r in selected_regions}
    # 使用预设锚点作为初始位置（海上空白区），再进行防重叠
    anchor_centers = {r: REGION_ANCHORS.get(r, region_centers.get(r, (0, 0))) for r in selected_regions}
    positions = spread_positions(anchor_centers, selected_regions, radii_deg=radius_map, extra_gap=2.0, step=JITTER_STEP)
    region_colors = region_palette(selected_regions)

    fig_width = max(11.0, config.figsize[0])
    fig_height = max(6.5, config.figsize[1])
    fig, ax = plt.subplots(figsize=(fig_width, fig_height), facecolor="white")
    if config.ocean_color != "none":
        ax.set_facecolor(config.ocean_color)

    # 全部国家按区域着色（很浅的底色）；若属于某条因果链，则该国家按“链条色”单独上色
    admin_color: Dict[str, str] = {}
    for admin, reg in admin_to_region.items():
        if admin in country_chain_color:
            admin_color[admin] = country_chain_color[admin]
        else:
            admin_color[admin] = lighten(region_colors.get(reg, BASE_FACE), 0.85)
    draw_base_map(ax, admin_to_geom, ocean_color=config.ocean_color, admin_color=admin_color)

    # 本图强调“链条可见”，不按面积过滤国家（避免小国链条被跳过）
    big_countries: Set[str] = set(admin_to_point.keys())

    # 将环图推到海上、记录最终位置
    land_geoms = [geom for geom in admin_to_geom.values() if isinstance(geom, (Polygon, MultiPolygon))]
    final_positions: Dict[str, Tuple[float, float]] = {}
    for idx, region in enumerate(selected_regions):
        pos = positions.get(region)
        if not pos:
            continue
        clearance = radius_map.get(region, 6.0) + 2.0  # 环图与文字整体不遮挡陆地
        pos_sea = move_off_land(pos, land_geoms, start_angle=33 + 37 * idx, clearance_deg=clearance)
        final_positions[region] = pos_sea

    # 区域描边（不再画环图连接线）
    for region in selected_regions:
        color = region_colors.get(region, "#444444")
        center = region_centers.get(region)
        info = region_data.get(region, {})
        for admin in info.get("countries", set()):
            geom = admin_to_geom.get(admin)
            if isinstance(geom, (Polygon, MultiPolygon)):
                geoms = geom.geoms if isinstance(geom, MultiPolygon) else [geom]
                for g in geoms:
                    xs, ys = g.exterior.xy
                    ax.plot(xs, ys, color=color, linewidth=0.45, alpha=0.95, zorder=3)
                    for interior in g.interiors:
                        xs_h, ys_h = interior.xy
                        ax.plot(xs_h, ys_h, color=color, linewidth=0.35, alpha=0.9, zorder=3)

    # 跨区域链条弧线（风格参照跨国影响链条地图，按链条上色）
    if chains:
        print(f"[INFO] 提取跨国链条 {len(chains)} 条")
        for chain in chains:
            print(f"[CHAIN] {chain['id']}: {chain['source']} -> {', '.join(chain['targets'])} "
                  f"(type={chain['chain_type'] or 'N/A'}, scope={chain['scope']})")
        if unknown:
            print(f"[WARN] 未匹配的名称（被跳过）: {', '.join(sorted(list(unknown))[:15])}"
                  + (" ..." if len(unknown) > 15 else ""))

        path_counts: Dict[Tuple[str, str], int] = {}
        src_points: List[Tuple[float, float, str]] = []
        tgt_points: List[Tuple[float, float, str]] = []
        for chain in chains:
            if chain["source"] not in big_countries:
                continue
            src_pt = admin_to_point.get(chain["source"])
            if src_pt is None:
                continue
            color = chain_line_colors.get(chain["id"], "#666666")
            src_points.append((float(src_pt.x), float(src_pt.y), color))
            for tgt in chain["targets"]:
                if tgt not in big_countries:
                    continue
                tgt_pt = admin_to_point.get(tgt)
                if tgt_pt is None:
                    continue
                tgt_points.append((float(tgt_pt.x), float(tgt_pt.y), color))
                dist = ((src_pt.x - tgt_pt.x) ** 2 + (src_pt.y - tgt_pt.y) ** 2) ** 0.5
                mult = max(1.0, MIN_CURVE_DIST / (dist + 1e-6))
                base_rad = min(RAD_MAX, BASE_RAD * mult)
                key = (chain["source"], tgt)
                count = path_counts.get(key, 0)
                sign = 1 if (count % 2 == 0) else -1
                rad = sign * (base_rad + (count // 2) * RAD_JITTER)
                rad = max(-RAD_MAX, min(RAD_MAX, rad))
                path_counts[key] = count + 1
                ax.add_patch(FancyArrowPatch(
                    (src_pt.x, src_pt.y),
                    (tgt_pt.x, tgt_pt.y),
                    connectionstyle=f"arc3,rad={rad}",
                    arrowstyle=f"Simple,head_length={HEAD_LEN},head_width={HEAD_WID},tail_width={TAIL_WID}",
                    linewidth=CHAIN_LINE_WIDTH,
                    color=color,
                    alpha=min(1.0, ARROW_ALPHA + 0.15),
                    zorder=4,
                ))

        def _scatter_with_jitter(points: List[Tuple[float, float, str]], base_size: float, marker: str):
            if not points:
                return
            xs, ys, cs = [], [], []
            for x, y, c in points:
                xs.append(x)
                ys.append(y)
                cs.append(c)
            ax.scatter(
                xs,
                ys,
                s=base_size,
                marker=marker,
                c=cs,
                edgecolors="none",
                linewidths=0.0,
                alpha=0.98,
                zorder=7,
            )

        def _place_points_no_overlap(
            points: List[Tuple[float, float, str, str, float]],
            min_sep: float,
        ) -> List[Tuple[float, float, str, str, float]]:
            """将节点逐个放置，确保任意两点距离>=min_sep（单位：经纬度度数）。"""
            placed: List[Tuple[float, float, str, str, float]] = []
            for idx, (x, y, color, marker, size) in enumerate(points):
                px, py = x, y
                ang = (137.5 * (idx + 1)) % 360
                r = 0.0
                for _ in range(220):
                    if all(((px - ox) ** 2 + (py - oy) ** 2) ** 0.5 >= min_sep for ox, oy, *_ in placed):
                        break
                    r += 0.25
                    ang = (ang + 61.0) % 360
                    px = x + r * np.cos(np.deg2rad(ang))
                    py = y + r * np.sin(np.deg2rad(ang))
                placed.append((px, py, color, marker, size))
            return placed

        # 因果节点：方块=源，圆点=目标（无描边，颜色随链条线色）
        all_nodes: List[Tuple[float, float, str, str, float]] = []
        all_nodes.extend([(x, y, c, "s", 5.5) for (x, y, c) in src_points])
        all_nodes.extend([(x, y, c, "o", 6.5) for (x, y, c) in tgt_points])
        placed_nodes = _place_points_no_overlap(all_nodes, min_sep=NODE_MIN_SEP_DEG)
        placed_src = [(x, y, c) for x, y, c, m, s in placed_nodes if m == "s"]
        placed_tgt = [(x, y, c) for x, y, c, m, s in placed_nodes if m == "o"]
        _scatter_with_jitter(placed_src, base_size=5.5, marker="s")
        _scatter_with_jitter(placed_tgt, base_size=6.5, marker="o")

    for region in selected_regions:
        pos = final_positions.get(region)
        if not pos:
            continue
        draw_region_donut(
            ax,
            region,
            pos,
            region_data[region],
            risk_labels_main,
            barrier_labels_main,
            include_risk_other,
            include_barrier_other,
            risk_palette,
            barrier_palette,
            max_total=max_total,
            region_color=region_colors.get(region, "#444444"),
            size=size_map[region],
        )

    extent = (-220, 220, -60, 85)
    ax.set_xlim(extent[0], extent[1])
    ax.set_ylim(extent[2], extent[3])
    _add_graticules(ax, extent)
    ax.set_aspect("equal")
    ax.axis("off")  # 无刻度/边框

    risk_labels_full = list(risk_labels_main) + (["Other risk"] if include_risk_other else [])
    barrier_labels_full = list(barrier_labels_main) + (["Other barrier"] if include_barrier_other else [])
    handles: List[Line2D] = []
    handles.extend(
        Line2D([0], [0], marker="o", color="white", markerfacecolor=col, markeredgecolor="none",
               markersize=7, linestyle="", label=f"Risk: {lbl}")
        for lbl, col in zip(risk_labels_full, risk_palette)
    )
    handles.extend(
        Line2D([0], [0], marker="o", color="white", markerfacecolor=col, markeredgecolor="none",
               markersize=7, linestyle="", label=f"Barrier: {lbl}")
        for lbl, col in zip(barrier_labels_full, barrier_palette)
    )
    if chains:
        handles.append(Line2D([0, 1], [0, 0], color="#444444", linewidth=1.0, label="Cross-region causal chains (→)"))
        handles.append(Line2D([0], [0], marker="s", color="none", markerfacecolor="#666666",
                              markeredgecolor="none", markersize=2, linewidth=0, label="Chain source"))
        handles.append(Line2D([0], [0], marker="o", color="none", markerfacecolor="#666666",
                              markeredgecolor="none", markersize=2, linewidth=0, label="Chain target"))

    # 环图大小 → 样本量（使用实心圆大小示例）
    sample_counts = [totals.get(r, 0) for r in selected_regions]
    if sample_counts:
        unique_counts = sorted(set(sample_counts))
        size_examples = [unique_counts[0], unique_counts[len(unique_counts) // 2], unique_counts[-1]]
        size_examples = list(dict.fromkeys(size_examples))  # 去重但保持顺序
        size_handles: List[Line2D] = []
        for cnt in size_examples:
            marker_size = compute_donut_size(cnt, max_total) * 75  # 换算为 legend 中的点大小
            size_handles.append(
                Line2D(
                    [0], [0],
                    marker="o",
                    color="white",
                    markerfacecolor="#dddddd",
                    markeredgecolor="#666666",
                    markersize=marker_size,
                    linestyle="",
                    label=f"Ring size ≈ {cnt} samples",
                )
            )
        handles.extend(size_handles)

    ax.legend(
        handles=handles,
        loc="lower center",
        bbox_to_anchor=(0.5, -0.12),
        ncol=4,
        frameon=False,
        fontsize=config.legend_size,
        title="Inner ring: risk cascades | Outer ring: barrier mechanisms",
        title_fontsize=config.label_size,
    )

    os.makedirs(os.path.dirname(output_prefix) or ".", exist_ok=True)
    png_path = f"{output_prefix}.png"
    svg_path = f"{output_prefix}.svg"

    # --------- 数据导出：用于后续分析（地区-原因、地区-国家、跨地区链条等）---------
    try:
        # 1) 地区汇总（位置/大小/样本量）
        region_rows: List[Dict] = []
        for region in selected_regions:
            info = region_data.get(region, {})
            risk_total = int(sum(info.get("risk", {}).values()))
            barrier_total = int(sum(info.get("barrier", {}).values()))
            total = int(risk_total + barrier_total)
            cx, cy = region_centers.get(region, (np.nan, np.nan))
            ax0, ay0 = anchor_centers.get(region, (np.nan, np.nan))
            px, py = final_positions.get(region, (np.nan, np.nan))
            region_rows.append(
                dict(
                    region=region,
                    countries_n=int(len(info.get("countries", set()))),
                    risk_total=risk_total,
                    barrier_total=barrier_total,
                    total=total,
                    donut_size=float(size_map.get(region, np.nan)),
                    donut_radius_deg=float(radius_map.get(region, np.nan)),
                    center_lon=float(cx),
                    center_lat=float(cy),
                    anchor_lon=float(ax0),
                    anchor_lat=float(ay0),
                    donut_lon=float(px),
                    donut_lat=float(py),
                )
            )
        pd.DataFrame(region_rows).to_csv(f"{output_prefix}_region_summary.csv", index=False, encoding="utf-8-sig")

        # 2) 地区原因（长表）：保留原始分类 + 可视化分组（Other 汇总）
        cause_rows: List[Dict] = []
        for region in selected_regions:
            info = region_data.get(region, {})
            for bucket, shown, other_label in [
                ("risk", set(risk_labels_main), "Other risk"),
                ("barrier", set(barrier_labels_main), "Other barrier"),
            ]:
                counts = info.get(bucket, {}) or {}
                denom = float(sum(counts.values())) if counts else 0.0
                for cause_label, count in counts.items():
                    plot_group = cause_label if cause_label in shown else other_label
                    cause_rows.append(
                        dict(
                            region=region,
                            bucket=bucket,
                            cause_label=cause_label,
                            plot_group=plot_group,
                            count=int(count),
                            share=(float(count) / denom) if denom > 0 else np.nan,
                            is_shown=int(cause_label in shown),
                        )
                    )
        pd.DataFrame(cause_rows).to_csv(f"{output_prefix}_region_causes_long.csv", index=False, encoding="utf-8-sig")

        # 3) 地区-国家清单
        country_rows: List[Dict] = []
        for region in selected_regions:
            info = region_data.get(region, {})
            for admin in sorted(info.get("countries", set())):
                country_rows.append(dict(region=region, country_admin=admin))
        pd.DataFrame(country_rows).to_csv(f"{output_prefix}_region_countries.csv", index=False, encoding="utf-8-sig")

        # 4) 跨国链条（国家级边表）
        edge_rows: List[Dict] = []
        for chain in chains:
            src = chain.get("source")
            src_reg = country_region_map.get(src) if src else None
            for tgt in chain.get("targets", []) or []:
                tgt_reg = country_region_map.get(tgt)
                edge_rows.append(
                    dict(
                        chain_id=chain.get("id"),
                        chain_type=chain.get("chain_type") or "",
                        scope=chain.get("scope") or "",
                        source_country=src or "",
                        target_country=tgt or "",
                        source_region=src_reg or "",
                        target_region=tgt_reg or "",
                        is_cross_region=int(bool(src_reg and tgt_reg and src_reg != tgt_reg)),
                    )
                )
        if edge_rows:
            edge_df = pd.DataFrame(edge_rows)
            edge_df.to_csv(f"{output_prefix}_chain_edges_country.csv", index=False, encoding="utf-8-sig")

            # 5) 跨国链条聚合到地区（地区级边表）
            region_edge = (
                edge_df.assign(link=1)
                .groupby(["source_region", "target_region", "chain_type", "scope"], dropna=False)
                .agg(
                    links=("link", "sum"),
                    chains=("chain_id", "nunique"),
                    sources=("source_country", "nunique"),
                    targets=("target_country", "nunique"),
                )
                .reset_index()
                .sort_values(["links", "chains"], ascending=False)
            )
            region_edge.to_csv(f"{output_prefix}_chain_edges_region.csv", index=False, encoding="utf-8-sig")

        # 6) 未匹配名称（来自跨国影响链条解析）
        if unknown:
            pd.DataFrame({"unknown_name": sorted(unknown)}).to_csv(
                f"{output_prefix}_unknown_names.csv", index=False, encoding="utf-8-sig"
            )
    except Exception as e:
        print(f"[WARN] 数据导出失败（不影响出图）: {e}")

    save_png(fig, png_path, strict_size=False)
    save_svg_editable(fig, svg_path, strict_size=False)
    plt.close(fig)

    print(f"[OK] 输出: {png_path}, {svg_path}")
    print(f"[INFO] 地区数量: {len(selected_regions)}, 风险类别: {len(risk_labels_full)}, 障碍类别: {len(barrier_labels_full)}")


def main() -> None:
    parser = argparse.ArgumentParser(description="跨地区风险/障碍原因双层环形图")
    parser.add_argument("--csv", default="all_l_dimensions.csv", help="输入 CSV 路径")
    parser.add_argument("--out_prefix", default="地区风险障碍环图", help="输出前缀（不含扩展名）")
    parser.add_argument("--resolution", default="50m", choices=["110m", "50m", "10m"], help="底图分辨率")
    parser.add_argument("--top_regions", type=int, default=0, help="展示的地区数量上限；0 表示不限制")
    parser.add_argument("--min_total", type=int, default=1, help="地区最小样本量阈值，低于则跳过")
    parser.add_argument("--include_domestic_chains", action="store_true", default=False,
                        help="包含 Impact_Scope=Domestic 的链条（默认仅跨国/跨地区）")
    parser.add_argument("--risk_top_n", type=int, default=6, help="内圈风险类别显示前 N 个，其余合并为 Other")
    parser.add_argument("--barrier_top_n", type=int, default=6, help="外圈障碍类别显示前 N 个，其余合并为 Other")
    args = parser.parse_args()

    create_region_ring_map(
        csv_file=args.csv,
        output_prefix=args.out_prefix,
        resolution=args.resolution,
        top_regions=args.top_regions,
        min_total=args.min_total,
        include_domestic_chains=args.include_domestic_chains,
        risk_top_n=args.risk_top_n,
        barrier_top_n=args.barrier_top_n,
    )


if __name__ == "__main__":
    main()
