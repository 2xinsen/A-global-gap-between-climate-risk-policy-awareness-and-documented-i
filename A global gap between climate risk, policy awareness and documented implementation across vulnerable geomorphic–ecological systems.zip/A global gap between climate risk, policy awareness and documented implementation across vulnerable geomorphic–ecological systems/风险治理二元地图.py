"""风险 × 治理 二元全球地图

变量：
- 风险：Scores_R_total_score（0-15），按国家均值，归一化到 0-1。
- 治理：Metadata_WGI_Gov（混合数值/文字），按国家均值，数值 min-max 归一；文字映射 Low/Weak→低，Medium/Moderate→中，High/Strong→高。

色带：
- 使用 3x3 双变量色板（x=风险，y=治理），色彩取高对比的 RdYlBu 变体。
- 收入区分：用小图标标注（高收入方形实心标记，其他收入空心圆标记）；收入缺失不标记。

输出：
- PNG + 可编辑 SVG（文字保持可编辑），尺寸与 config.py 的双栏默认一致。

运行示例：
    python 风险治理二元地图.py --csv all_l_dimensions.csv --out_prefix 风险_治理_二元地图
"""

from __future__ import annotations

import argparse
import os
from typing import Dict, Optional

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd

try:
    import geopandas as gpd  # type: ignore
    from shapely.geometry import MultiPolygon, Polygon  # type: ignore
except ImportError:
    raise ImportError("需要安装 geopandas: pip install geopandas")

from 三元国家地图 import (  # noqa: E402
    get_config,
    get_natural_earth_countries,
    load_actual_data,
    save_png,
    save_svg_editable,
    _add_coordinate_frame,
    _add_graticules,
)

# ---------- 配置 ----------
# 3x3 色板（行=治理低→高，列=风险低→高），由两个主色线性混合：
#   - (0,0) 仅左下角接近白色
#   - 横轴逐步增加 Risk 色（risk_color），纵轴逐步增加 Governance 色（gov_color）
#   - 中间色为两色线性混合，随两个指标同时加深
# 为避免过于刺眼：选用更柔和的“深色系”锚点，并在构造色板时整体向白色轻微靠拢
RISK_COLOR = "#c44e52"  # muted red
GOV_COLOR = "#4c72b0"   # muted blue
N_LEVELS = 3
ANCHOR_SOFTEN = 0.18  # 0-1，越大越柔和（锚点越接近白色）


def _hex_to_rgb01(h: str) -> np.ndarray:
    h = h.lstrip("#")
    return np.array([int(h[i:i+2], 16)/255.0 for i in (0, 2, 4)], dtype=float)


def build_bivar_colors(n: int = N_LEVELS,
                       risk_hex: str = RISK_COLOR,
                       gov_hex: str = GOV_COLOR) -> list:
    """生成 n×n 颜色矩阵：行=治理，列=风险。"""
    risk_rgb = _hex_to_rgb01(risk_hex)
    gov_rgb = _hex_to_rgb01(gov_hex)
    if ANCHOR_SOFTEN > 0:
        white = np.array([1.0, 1.0, 1.0], dtype=float)
        risk_rgb = (1 - ANCHOR_SOFTEN) * risk_rgb + ANCHOR_SOFTEN * white
        gov_rgb = (1 - ANCHOR_SOFTEN) * gov_rgb + ANCHOR_SOFTEN * white
    mix_rgb = (risk_rgb + gov_rgb) / 2
    colors = []
    for iy in range(n):
        row = []
        gy = iy / (n - 1)  # 0→1
        for ix in range(n):
            gx = ix / (n - 1)
            # 双线性混合：白/风险/治理/混合色
            w_white = (1 - gx) * (1 - gy)
            w_risk = gx * (1 - gy)
            w_gov = gy * (1 - gx)
            w_mix = gx * gy
            rgb = (
                w_white * np.array([1.0, 1.0, 1.0]) +
                w_risk * risk_rgb +
                w_gov * gov_rgb +
                w_mix * mix_rgb
            )
            rgb = np.clip(rgb, 0, 1)
            row.append(mpl.colors.to_hex(rgb))
        colors.append(row)
    return colors


BIVAR_COLORS = build_bivar_colors()

EDGE_COLOR = "#f5f5f5"     # 中性边界
MISSING_FACE = "#f0f0f0"   # 缺失数据填充

ALIAS = {
    "Brunei Darussalam": "Brunei",
    "Democratic People's Republic of Korea": "North Korea",
    "Kyrgyz Republic": "Kyrgyzstan",
    "Lao People's Democratic Republic": "Laos",
    "Republic of Congo": "Republic of the Congo",
    "Republic of Fiji": "Fiji",
    "Republic of San Marino": "San Marino",
    "Republic of the Marshall Islands": "Marshall Islands",
    "Russian Federation": "Russia",
    "State of Palestine": "Palestine",
    "Syrian Arab Republic": "Syria",
    "Türkiye": "Turkey",
    "United States": "United States of America",
    "Vatican City (Holy See)": "Vatican",
}


def norm_income(x: str) -> str:
    if pd.isna(x):
        return ""
    x = str(x).strip().lower().replace("-", " ")
    x = " ".join(x.split())
    if x in {"high income", "high"}:
        return "High income"
    if x in {"upper middle income", "upper middle", "upper middleincome", "upper middle income (in debt distress)", "upper middle income fcv"}:
        return "Upper middle income"
    if x in {"lower middle income", "lower middle", "lower middleincome", "lower middle income (in debt distress)", "lower middle income fcv"}:
        return "Lower middle income"
    if x in {"low income", "low"}:
        return "Low income"
    return x.title()


def parse_wgi(val) -> float:
    """将治理文本/数字转为数值；无法解析返回 NaN。"""
    if pd.isna(val):
        return np.nan
    s = str(val).strip()
    try:
        return float(s)
    except Exception:
        s_low = s.lower()
        if "low" in s_low or "weak" in s_low or "risk" in s_low:
            return -1.0
        if "medium" in s_low or "moderate" in s_low or "med" in s_low:
            return 0.0
        if "high" in s_low or "strong" in s_low:
            return 1.0
        return np.nan


def _bivar_level(v: float) -> int:
    """将归一化值映射到 0..N_LEVELS-1（与图面映射一致）。"""
    if pd.isna(v):
        return -1
    try:
        vv = float(v)
    except Exception:
        return -1
    if not np.isfinite(vv):
        return -1
    vv = float(np.clip(vv, 0.0, 1.0))
    return min(int(vv * N_LEVELS), N_LEVELS - 1)


def load_and_aggregate_frame(csv_path: str) -> pd.DataFrame | None:
    """读取原始数据并按国家聚合风险/治理/收入等，并生成用于绘图与分析的字段。"""
    df = load_actual_data(csv_path)
    if df is None:
        return None

    df["Income_norm"] = df["Metadata_Income_Group"].map(norm_income) if "Metadata_Income_Group" in df.columns else ""
    # 风险
    risk = pd.to_numeric(df["Scores_R_total_score"], errors="coerce") if "Scores_R_total_score" in df.columns else np.nan
    # 治理
    if "Metadata_WGI_Gov" not in df.columns:
        raise ValueError("缺少列 Metadata_WGI_Gov")
    df["WGI_num"] = df["Metadata_WGI_Gov"].map(parse_wgi)

    agg = df.groupby("Country").agg(
        risk_mean=("Scores_R_total_score", "mean"),
        gov_mean=("WGI_num", "mean"),
        income_any=("Income_norm", lambda x: x.dropna().mode().iloc[0] if len(x.dropna()) else ""),
        region_any=("Metadata_Region", lambda x: x.dropna().mode().iloc[0] if len(x.dropna()) else "") if "Metadata_Region" in df.columns else ("Country", "first"),
        record_count=("Unit_ID", "count") if "Unit_ID" in df.columns else ("WGI_num", "size"),
    ).reset_index()

    # 风险归一
    agg["risk_norm"] = (agg["risk_mean"] / 15).clip(0, 1)
    # 治理归一（min-max）
    gov = agg["gov_mean"]
    gov_min, gov_max = gov.min(), gov.max()
    agg["gov_norm"] = (gov - gov_min) / (gov_max - gov_min) if gov_max > gov_min else np.nan

    # 收入分类
    agg["income_class"] = agg["income_any"].fillna("")

    # 3x3 分箱（与地图一致：列=风险，行=治理）
    agg["risk_level"] = agg["risk_norm"].map(_bivar_level)
    agg["gov_level"] = agg["gov_norm"].map(_bivar_level)

    def _color_row(r):
        if r["risk_level"] < 0 or r["gov_level"] < 0:
            return MISSING_FACE
        return BIVAR_COLORS[int(r["gov_level"])][int(r["risk_level"])]

    agg["bivar_color"] = agg.apply(_color_row, axis=1)
    agg["is_high_income"] = agg["income_class"].astype(str).str.lower().str.startswith("high income")

    # 方便复现归一化
    agg["gov_min"] = float(gov_min) if np.isfinite(gov_min) else np.nan
    agg["gov_max"] = float(gov_max) if np.isfinite(gov_max) else np.nan
    return agg


def load_and_aggregate(csv_path: str):
    """返回绘图使用的 dict（含别名扩展）。"""
    agg = load_and_aggregate_frame(csv_path)
    if agg is None or agg.empty:
        return None

    data: Dict[str, Dict[str, object]] = {}
    for _, row in agg.iterrows():
        country = row["Country"]
        data[country] = {
            "risk": row["risk_norm"],
            "gov": row["gov_norm"],
            "income": row["income_class"],
        }
        if country in ALIAS:
            data[ALIAS[country]] = data[country]
    return data


def map_color(risk_norm: float, gov_norm: float) -> str:
    """根据归一化值映射到离散色阶（N_LEVELS×N_LEVELS）。"""
    if np.isnan(risk_norm) or np.isnan(gov_norm):
        return MISSING_FACE

    def idx(v: float) -> int:
        # v ∈ [0,1] -> 0..N_LEVELS-1
        return min(int(v * N_LEVELS), N_LEVELS - 1)

    x = idx(risk_norm)
    y = idx(gov_norm)
    return BIVAR_COLORS[y][x]


def income_class(income_class_raw: str) -> str:
    """规范收入分组文本。"""
    return (income_class_raw or "").strip()


def create_map(
    csv_file: str = "all_l_dimensions.csv",
    output_prefix: str = "风险_治理_二元地图",
    resolution: str = "50m",
):
    config = get_config()
    config.apply()

    agg_df = load_and_aggregate_frame(csv_file)
    data = load_and_aggregate(csv_file)
    if not data:
        print("[ERROR] 数据为空")
        return

    world = get_natural_earth_countries(resolution)

    fig, ax = plt.subplots(figsize=config.figsize, facecolor="white")
    if config.ocean_color != "none":
        ax.set_facecolor(config.ocean_color)

    matched = 0
    high_pts = []
    non_high_pts = []
    for _, row in world.iterrows():
        geom = row.geometry
        if geom is None or geom.is_empty:
            continue
        key = None
        for col in ["iso_a3", "ISO_A3", "ADM0_A3", "SOV_A3", "NAME", "NAME_EN", "ADMIN", "NAME_LONG", "FORMAL_EN", "BRK_NAME"]:
            if col in row and row[col] in data:
                key = row[col]
                break
        if key is None:
            face = MISSING_FACE
        else:
            matched += 1
            entry = data[key]
            face = map_color(entry["risk"], entry["gov"])
            income = income_class(entry["income"]).lower()
            try:
                point = geom.representative_point()
            except Exception:
                point = geom.centroid
            if point and not point.is_empty:
                if income.startswith("high income"):
                    high_pts.append(point)
                elif income:
                    non_high_pts.append(point)

        # 绘制
        if isinstance(geom, (Polygon, MultiPolygon)):
            geoms = geom.geoms if isinstance(geom, MultiPolygon) else [geom]
            for g in geoms:
                xs, ys = g.exterior.xy
                ax.fill(xs, ys, facecolor=face, edgecolor=EDGE_COLOR, linewidth=0.35)
                for interior in g.interiors:
                    xs, ys = interior.xy
                    ax.fill(xs, ys, facecolor=config.ocean_color if config.ocean_color != "none" else "white",
                            edgecolor=EDGE_COLOR, linewidth=0.2)
    print(f"[INFO] 匹配国家数: {matched}")

    # 收入分组标记：高收入为黑色实心方块，其他收入为空心圆
    if high_pts:
        ax.scatter([p.x for p in high_pts], [p.y for p in high_pts],
                   s=2, marker="s", c="black", edgecolors="black", linewidths=0.2, zorder=5, label="High income")
    if non_high_pts:
        ax.scatter([p.x for p in non_high_pts], [p.y for p in non_high_pts],
                   s=3, marker="o", facecolors="white", edgecolors="black", linewidths=0.4, zorder=5, label="Non-high income")

    extent = (-180, 180, -60, 85)
    _add_graticules(ax, extent)
    _add_coordinate_frame(ax, extent, lon_interval=30, lat_interval=30)
    ax.set_xlabel("")
    ax.set_ylabel("")
    ax.set_aspect("equal")

    # 图例：5x5方块，左下为 (Risk 低, Gov 低)，右上为 (Risk 高, Gov 高)
    legend_size = 0.14
    legend_ax = ax.inset_axes([0.02, 0.02, legend_size, legend_size])
    n = N_LEVELS
    for i in range(n):
        for j in range(n):
            legend_ax.add_patch(
                mpl.patches.Rectangle(
                    (j / n, i / n),
                    1 / n,
                    1 / n,
                    facecolor=BIVAR_COLORS[i][j],
                    edgecolor="white",
                    linewidth=0.4,
                )
            )
    legend_ax.set_xlim(0, 1)
    legend_ax.set_ylim(0, 1)
    legend_ax.set_aspect("equal")
    legend_ax.set_xticks([0, 0.5, 1])
    legend_ax.set_yticks([0, 0.5, 1])
    tick_fs = max(4, int(config.tick_size / 2))
    label_fs = max(4, int(config.label_size / 2))
    legend_ax.set_xticklabels(["Low", "Medium", "High"], fontsize=tick_fs)
    legend_ax.set_yticklabels(["Low", "Medium", "High"], fontsize=tick_fs)
    legend_ax.set_xlabel("Risk", fontsize=label_fs)
    legend_ax.set_ylabel("Governance", fontsize=label_fs)
    legend_ax.tick_params(length=0)

    # 收入标记图例
    handles = [
        Line2D([0], [0], marker="s", color="black", markerfacecolor="black", markersize=3, linewidth=0, label="High income"),
        Line2D([0], [0], marker="o", color="black", markerfacecolor="white", markeredgewidth=0.8, markersize=3, linewidth=0, label="Non-high income"),
        mpl.patches.Patch(facecolor=MISSING_FACE, edgecolor="black", linewidth=0.3, label="Income missing"),
    ]
    ax.legend(
        handles=handles,
        loc="upper center",
        bbox_to_anchor=(0.5, -0.1),
        ncol=3,
        frameon=False,
        fontsize=config.legend_size,
    )

    os.makedirs(os.path.dirname(output_prefix) or ".", exist_ok=True)
    png_path = f"{output_prefix}.png"
    svg_path = f"{output_prefix}.svg"
    csv_path = f"{output_prefix}_data.csv"
    save_png(fig, png_path, strict_size=False)
    save_svg_editable(fig, svg_path, strict_size=False)
    plt.close(fig)

    if agg_df is not None and not agg_df.empty:
        agg_df.to_csv(csv_path, index=False, encoding="utf-8-sig")
        print(f"[SUCCESS] 数据已导出: {csv_path}")

    print(f"[SUCCESS] 输出: {png_path}, {svg_path}")


def main():
    parser = argparse.ArgumentParser(description="风险 × 治理 二元全球地图")
    parser.add_argument("--csv", default="all_l_dimensions.csv", help="输入CSV路径")
    parser.add_argument("--out_prefix", default="风险_治理_二元地图", help="输出前缀（不含扩展名）")
    parser.add_argument("--resolution", default="50m", choices=["110m", "50m", "10m"])
    args = parser.parse_args()
    create_map(csv_file=args.csv, output_prefix=args.out_prefix, resolution=args.resolution)


if __name__ == "__main__":
    main()
